param(
    [string]$MinecraftDirectory = 'C:\Users\pasha\AppData\Roaming\.minecraft',
    [string]$ForgeVersionName = 'Forge 1.20.1',
    [switch]$World,
    [switch]$FpsAdaptation,
    [switch]$LowLevel,
    [string]$CombinedWheelJar,
    [string]$ExtraClientMod,
    [switch]$ExpectOptiFine,
    [switch]$MenuOnly
)
$ErrorActionPreference = 'Stop'
$projectDirectory = $PSScriptRoot
$smokeDirectory = Join-Path $projectDirectory 'run-smoke-1.3.2'
if ($CombinedWheelJar) { $smokeDirectory = Join-Path $projectDirectory 'run-smoke-combined-4.5.2' }
if ($ExpectOptiFine) { $smokeDirectory = Join-Path $projectDirectory 'run-smoke-optifine-4.5.2' }
New-Item -ItemType Directory -Force -Path $smokeDirectory, (Join-Path $smokeDirectory 'mods'), (Join-Path $smokeDirectory 'native') | Out-Null
if ($CombinedWheelJar) {
    $releaseJar = Get-Item -LiteralPath $CombinedWheelJar
    $FpsAdaptation = $World = $true
} else {
    $releaseJar = Get-ChildItem -LiteralPath (Join-Path $projectDirectory 'build/libs') -Filter '*-1.3.2.jar' | Select-Object -First 1
}
if (!$releaseJar) { throw 'Build the release first.' }
Copy-Item -LiteralPath $releaseJar.FullName -Destination (Join-Path $smokeDirectory 'mods')
if ($ExtraClientMod) { Copy-Item -LiteralPath $ExtraClientMod -Destination (Join-Path $smokeDirectory 'mods') }
if($FpsAdaptation -and !$CombinedWheelJar) {
    $World=$true
    Copy-Item -LiteralPath 'C:\Users\pasha\OneDrive\Documents\ChatGPT\rsfgd\build\libs\adaptation-wheel-1.20.1-4.4.1.jar' -Destination (Join-Path $smokeDirectory 'mods')
}
if($LowLevel) { $World=$true }
if($MenuOnly) { $World=$false; $FpsAdaptation=$false; $LowLevel=$false }
$versionDirectory = Join-Path $MinecraftDirectory ('versions/' + $ForgeVersionName)
$metadata = Get-Content -Raw -LiteralPath (Join-Path $versionDirectory ($ForgeVersionName + '.json')) | ConvertFrom-Json
function Test-Allowed($rules) {
    if (!$rules -or $rules.Count -eq 0) { return $true }
    $isAllowed = $false
    foreach ($rule in $rules) {
        $matchesRule = $true
        if ($rule.os.name -and $rule.os.name -ne 'windows') { $matchesRule = $false }
        if ($rule.os.arch -and $rule.os.arch -notin @('x86_64','amd64')) { $matchesRule = $false }
        if ($rule.features) { $matchesRule = $false }
        if ($matchesRule) { $isAllowed = $rule.action -eq 'allow' }
    }
    return $isAllowed
}
$classPaths = [System.Collections.Generic.List[string]]::new()
foreach ($library in $metadata.libraries) {
    if (!(Test-Allowed $library.rules)) { continue }
    $relativePath = $library.artifact.path
    if (!$relativePath) { $relativePath = 'libraries/' + $library.downloads.artifact.path }
    if (!$relativePath -or $relativePath -eq 'libraries/') { continue }
    if (!$relativePath.StartsWith('libraries/')) { $relativePath = 'libraries/' + $relativePath }
    $absolutePath = Join-Path $MinecraftDirectory $relativePath
    if (!(Test-Path -LiteralPath $absolutePath)) { throw "Missing installed library: $relativePath" }
    $classPaths.Add($absolutePath)
}
$classPaths.Add((Join-Path $versionDirectory ($ForgeVersionName + '.jar')))
$replacements = @{
    '${natives_directory}' = (Join-Path $smokeDirectory 'native')
    '${launcher_name}' = 'PashaBoostSmoke'
    '${launcher_version}' = '1'
    '${classpath}' = ($classPaths -join ';')
    '${library_directory}' = (Join-Path $MinecraftDirectory 'libraries')
    '${version_name}' = $ForgeVersionName
    '${classpath_separator}' = ';'
    '${auth_player_name}' = 'BoostSmoke'
    '${game_directory}' = $smokeDirectory
    '${assets_root}' = (Join-Path $MinecraftDirectory 'assets')
    '${assets_index_name}' = $metadata.assetIndex.id
    '${auth_uuid}' = '00000000000030008000000000000001'
    '${auth_access_token}' = '0'
    '${clientid}' = '0'
    '${auth_xuid}' = '0'
    '${user_type}' = 'legacy'
    '${version_type}' = 'release'
}
function Expand-LaunchArgument([string]$argument) {
    foreach ($entry in $replacements.GetEnumerator()) { $argument = $argument.Replace($entry.Key,[string]$entry.Value) }
    if ($argument.Contains('${')) { throw "Unresolved launch argument: $argument" }
    return $argument
}
$launchArguments = [System.Collections.Generic.List[string]]::new()
$launchArguments.Add('-Xmx3G')
$launchArguments.Add('-Dpashaboost.smoke=true')
if($World) { $launchArguments.Add('-Dpashaboost.smoke.world=true') }
if($FpsAdaptation) { $launchArguments.Add('-Dadaptationwheel.fps.smoke=true') }
if($LowLevel) { $launchArguments.Add('-Dpashaboost.smoke.lowLevel=true') }
if($ExpectOptiFine) { $launchArguments.Add('-Dpashaboost.smoke.expectOptifine=true') }
foreach ($argumentGroup in $metadata.arguments.jvm) {
    if ($argumentGroup -is [string]) { $launchArguments.Add((Expand-LaunchArgument $argumentGroup)); continue }
    if (Test-Allowed $argumentGroup.rules) { foreach ($argument in $argumentGroup.values) { $launchArguments.Add((Expand-LaunchArgument $argument)) } }
}
# Reuse installed native DLLs read-only; any newly extracted files go to the isolated test directory.
$launchArguments.Add('-Djava.library.path=' + (Join-Path $versionDirectory 'natives'))
$launchArguments.Add($metadata.mainClass)
foreach ($argumentGroup in $metadata.arguments.game) {
    if ($argumentGroup -is [string]) { $launchArguments.Add((Expand-LaunchArgument $argumentGroup)); continue }
    if (Test-Allowed $argumentGroup.rules) { foreach ($argument in $argumentGroup.values) { $launchArguments.Add((Expand-LaunchArgument $argument)) } }
}
$launchArguments.Add('--width'); $launchArguments.Add('960'); $launchArguments.Add('--height'); $launchArguments.Add('640')
$argFile = Join-Path $smokeDirectory 'java-arguments.txt'
$encodedArguments = $launchArguments | ForEach-Object { '"' + $_.Replace('\','/').Replace('"','\"') + '"' }
[IO.File]::WriteAllLines($argFile,$encodedArguments,[Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllLines((Join-Path $smokeDirectory 'options.txt'),@('lang:ru_ru','onboardAccessibility:false','maxFps:60','enableVsync:false','fullscreen:false','pauseOnLostFocus:false','renderDistance:6','simulationDistance:5'),[Text.UTF8Encoding]::new($false))
$javaPath = 'C:\Users\pasha\OneDrive\Documents\ChatGPT\rsfgd\.tools\java\jdk-17.0.20.1+1\bin\java.exe'
$process = Start-Process -FilePath $javaPath -ArgumentList ('@"' + $argFile + '"') -WorkingDirectory $smokeDirectory -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $smokeDirectory 'stdout.log') -RedirectStandardError (Join-Path $smokeDirectory 'stderr.log')
Write-Output "Smoke client PID: $($process.Id)"
$process.WaitForExit()
Write-Output "Smoke client exit: $($process.ExitCode)"
if ($process.ExitCode -ne 0) { throw "Client exited with code $($process.ExitCode). Read the isolated game log." }
$smokeLog = Get-Content -Raw -LiteralPath (Join-Path $smokeDirectory 'logs/latest.log')
if ($smokeLog -notmatch 'PASHABOOST_SMOKE PASS') { throw 'Client smoke assertions did not complete.' }
if ($World -and $smokeLog -notmatch 'PASHABOOST_WORLD PASS') { throw 'World smoke assertions did not complete.' }
if ($FpsAdaptation -and $smokeLog -notmatch 'FPS_ADAPTATION_SMOKE PASS') { throw 'FPS adaptation assertions did not complete.' }
if ($LowLevel -and $smokeLog -notmatch 'LOW_LEVEL_SMOKE PASS') { throw 'Low-level optimization assertions did not complete.' }
if ($ExpectOptiFine -and ($smokeLog -notmatch 'PASHABOOST_VIDEO_CUSTOM_OPTIFINE PASS' -or $smokeLog -notmatch 'PASHABOOST_VIDEO_ADVANCED_ROUNDTRIP PASS')) { throw 'OptiFine video menu assertions did not complete.' }
