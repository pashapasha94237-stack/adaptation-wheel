package twilightforest;

/** Compile-time stand-in for Twilight Forest 4.3.2508; never packaged. */
public final class ASMHooks {
    public static boolean cloud(boolean isRaining, net.minecraft.world.level.Level level, net.minecraft.core.BlockPos pos) {
        throw new AssertionError("compile-time stand-in");
    }
}
