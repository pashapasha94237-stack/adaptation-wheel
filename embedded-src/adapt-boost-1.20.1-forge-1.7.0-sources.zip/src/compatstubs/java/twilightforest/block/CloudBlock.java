package twilightforest.block;

/** Compile-time stand-in for Twilight Forest 4.3.2508; never packaged. */
public class CloudBlock extends net.minecraft.world.level.block.Block {
    public CloudBlock(Properties properties) { super(properties); }
    public net.minecraft.world.level.biome.Biome.Precipitation getPrecipitation() { throw new AssertionError("compile-time stand-in"); }
}
