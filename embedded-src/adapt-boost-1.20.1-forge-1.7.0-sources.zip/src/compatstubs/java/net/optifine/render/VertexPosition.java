package net.optifine.render;

/** Compile-time stand-in for OptiFine 1.20.1 HD U I6's VertexPosition (the 9th parameter of Cube.compile); never packaged. */
public class VertexPosition {
}
