package net.optifine.render;

/** Compile-time stand-in for OptiFine 1.20.1 HD U I6's RenderPositions (getPositionRender is a plain getter); never packaged. */
public class RenderPositions {
    public org.joml.Vector3f getPositionRender() {
        throw new AssertionError("compile-time stand-in");
    }
}
