package com.google.common.collect;

import java.util.Map;

/** Compile-time stand-in only; the shipped class is generated at runtime by ru.pasha.pashaboost.memory.GuavaAccess. */
public abstract class AdaptBoostEntrySetAccess<K, V> extends ImmutableSet<Map.Entry<K, V>> {
    @Override public abstract boolean isPartialView();
}
