package com.google.common.collect;

import java.util.Map;

/** Compile-time stand-in only; the shipped class is generated at runtime by ru.pasha.pashaboost.memory.GuavaAccess. */
public abstract class AdaptBoostImmutableMapAccess<K, V> extends ImmutableMap<K, V> {
    @Override public abstract ImmutableSet<Map.Entry<K, V>> createEntrySet();
    @Override public abstract boolean isPartialView();
    @Override public abstract ImmutableSet<K> createKeySet();
    @Override public abstract ImmutableCollection<V> createValues();
}
