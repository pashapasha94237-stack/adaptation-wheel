package com.google.common.collect;

/** Compile-time stand-in only; the shipped class is generated at runtime by ru.pasha.pashaboost.memory.GuavaAccess. */
public abstract class AdaptBoostImmutableCollectionAccess<T> extends ImmutableCollection<T> {
    @Override public abstract boolean isPartialView();
}
