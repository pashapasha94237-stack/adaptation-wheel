package ru.pasha.pashaboost.client;

import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.chunk.EmptyLevelChunk;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.PalettedContainerRO;
import ru.pasha.pashaboost.OptimizationCounters;
import ru.pasha.pashaboost.RuntimeTuning;

/**
 * ClientLevel.animateTick probes 1334 random blocks per tick and asks each one's biome, which runs
 * BiomeManager's eight "fiddled" distance samples before picking one of the eight surrounding
 * quart cells. When every chunk section those cells can come from holds a single, identical biome,
 * the answer is known in advance. Returning it is bit-for-bit what vanilla would return.
 */
public final class UniformBiomes {
    private static final Object MIXED = new Object();
    /** Keyed by the section's biome container: a resent chunk gets a new container object. */
    private static final Map<Object, Object> UNIFORM = new WeakHashMap<>();
    private UniformBiomes() {}

    public static Holder<Biome> biome(ClientLevel level, BlockPos pos) {
        if (!RuntimeTuning.ACTIVE || !RuntimeTuning.BIOME_SHORTCUT) return level.getBiome(pos);
        Holder<Biome> shared = sharedBiome(level, pos.getX(), pos.getY(), pos.getZ());
        if (shared == null) return level.getBiome(pos);
        OptimizationCounters.biomeLookupsSaved++;
        return shared;
    }

    /** The biome every candidate quart cell agrees on, or null when that is not certain. */
    static Holder<Biome> sharedBiome(ClientLevel level, int x, int y, int z) {
        // BiomeManager.getBiome chooses among quart cells q and q+1 of (coordinate - 2) on each axis.
        int qx = (x - 2) >> 2, qy = (y - 2) >> 2, qz = (z - 2) >> 2;
        int sx0 = qx >> 2, sx1 = (qx + 1) >> 2, sy0 = qy >> 2, sy1 = (qy + 1) >> 2, sz0 = qz >> 2, sz1 = (qz + 1) >> 2;
        Holder<Biome> found = null;
        for (int sx = sx0; sx <= sx1; sx++) for (int sz = sz0; sz <= sz1; sz++) {
            LevelChunk chunk = level.getChunkSource().getChunk(sx, sz, false);
            if (chunk == null || chunk instanceof EmptyLevelChunk) return null;
            for (int sy = sy0; sy <= sy1; sy++) {
                int index = chunk.getSectionIndexFromSectionY(sy);
                // Vanilla clamps out-of-world quart Y; leave those rare cases to vanilla.
                if (index < 0 || index >= chunk.getSectionsCount()) return null;
                Holder<Biome> biome = uniform(chunk.getSection(index).getBiomes());
                if (biome == null || found != null && found != biome) return null;
                found = biome;
            }
        }
        return found;
    }

    @SuppressWarnings("unchecked")
    private static Holder<Biome> uniform(PalettedContainerRO<Holder<Biome>> biomes) {
        Object cached = UNIFORM.get(biomes);
        if (cached == null) {
            // Read all 64 cells rather than the palette: a freshly generated section keeps the plains it was
            // created with in its palette after noise filled it, and the server sends that palette as is.
            Holder<Biome> first = biomes.get(0, 0, 0);
            cached = first;
            for (int i = 1; i < 64 && cached != MIXED; i++) if (biomes.get(i & 3, i >> 4, (i >> 2) & 3) != first) cached = MIXED;
            UNIFORM.put(biomes, cached);
        }
        return cached == MIXED ? null : (Holder<Biome>) cached;
    }

    public static void clear() { UNIFORM.clear(); }
}
