package ru.pasha.pashaboost.memory;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Table;
import net.minecraft.world.level.block.state.properties.Property;

/** What StateHolderFastMapMixin adds to every block and fluid state. Adapted from FerriteCore 6.0.1 (MIT). */
public interface FastMapStateHolder<S> {
    FastMap<S> pashaboost$stateMap();
    void pashaboost$setStateMap(FastMap<S> map);
    int pashaboost$stateIndex();
    void pashaboost$setStateIndex(int index);
    ImmutableMap<Property<?>, Comparable<?>> pashaboost$vanillaValues();
    void pashaboost$replaceValues(ImmutableMap<Property<?>, Comparable<?>> values);
    Table<Property<?>, Comparable<?>, S> pashaboost$neighbours();
    void pashaboost$setNeighbours(Table<Property<?>, Comparable<?>, S> table);
}
