package ru.pasha.pashaboost.memory;

import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenCustomHashMap;
import net.minecraft.Util;
import net.minecraft.core.Direction;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.properties.Property;
import org.jetbrains.annotations.Nullable;

import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Map;

/**
 * Numbers the values of a block-state property 0..n-1, with a fast path for the common property types.
 * Ported from FerriteCore 6.0.1 by malte0811 (MIT, see THIRD-PARTY.md).
 */
public abstract class PropertyIndexer<T extends Comparable<T>> {
    // Properties are compared by identity: two equal-looking properties of different blocks are different keys.
    private static final Map<Property<?>, PropertyIndexer<?>> KNOWN = new Object2ObjectOpenCustomHashMap<>(Util.identityStrategy());
    private final Property<T> property;
    private final int numValues;
    protected final T[] valuesInOrder;

    @SuppressWarnings("unchecked")
    public static <T extends Comparable<T>> PropertyIndexer<T> of(Property<T> property) {
        synchronized (KNOWN) {
            return (PropertyIndexer<T>) KNOWN.computeIfAbsent(property, p -> {
                PropertyIndexer<?> result = null;
                if (p instanceof BooleanProperty bool) result = new BoolIndexer(bool);
                else if (p instanceof IntegerProperty integer) result = new IntIndexer(integer);
                else if (DirectionIndexer.applies(p)) result = new DirectionIndexer((Property<Direction>) p);
                else if (p instanceof EnumProperty<?> enumProperty) result = new EnumIndexer<>(enumProperty);
                return result != null && result.isValid() ? result : new GenericIndexer<>(p);
            });
        }
    }

    protected PropertyIndexer(Property<T> property, T[] valuesInOrder) {
        this.property = property;
        this.numValues = property.getPossibleValues().size();
        this.valuesInOrder = valuesInOrder;
    }

    public Property<T> property() { return property; }
    public int numValues() { return numValues; }
    public final @Nullable T byIndex(int index) { return index >= 0 && index < valuesInOrder.length ? valuesInOrder[index] : null; }
    public abstract int toIndex(T value);

    /** A fast path is only used when it numbers the values exactly in the property's own order. */
    protected boolean isValid() {
        int index = 0;
        for (T value : property.getPossibleValues()) {
            if (toIndex(value) != index || !value.equals(byIndex(index))) return false;
            index++;
        }
        return true;
    }

    private static final class BoolIndexer extends PropertyIndexer<Boolean> {
        private static final Boolean[] VALUES = {true, false};
        BoolIndexer(BooleanProperty property) { super(property, VALUES); }
        @Override public int toIndex(Boolean value) { return value ? 0 : 1; }
    }

    private static final class IntIndexer extends PropertyIndexer<Integer> {
        private final int min;
        IntIndexer(IntegerProperty property) {
            super(property, property.getPossibleValues().toArray(new Integer[0]));
            this.min = property.getPossibleValues().stream().min(Comparator.naturalOrder()).orElse(0);
        }
        @Override public int toIndex(Integer value) { return value - min; }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static final class EnumIndexer<E extends Enum<E> & StringRepresentable> extends PropertyIndexer<E> {
        private final int ordinalOffset;
        EnumIndexer(EnumProperty<E> property) {
            super(property, (E[]) property.getPossibleValues().toArray(new Enum[0]));
            this.ordinalOffset = property.getPossibleValues().stream().mapToInt(Enum::ordinal).min().orElse(0);
        }
        @Override public int toIndex(E value) { return value.ordinal() - ordinalOffset; }
    }

    /** Vanilla's horizontal-then-vertical facing order, which is not the enum order. */
    private static final class DirectionIndexer extends PropertyIndexer<Direction> {
        private static final Direction[] ORDER = {Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST, Direction.UP, Direction.DOWN};
        DirectionIndexer(Property<Direction> property) { super(property, ORDER); Preconditions.checkState(isValid()); }
        static boolean applies(Property<?> property) {
            Collection<?> values = property.getPossibleValues();
            return values.size() == ORDER.length && Arrays.equals(ORDER, values.toArray());
        }
        @Override public int toIndex(Direction value) {
            return switch (value) { case NORTH -> 0; case EAST -> 1; case SOUTH -> 2; case WEST -> 3; case UP -> 4; case DOWN -> 5; };
        }
    }

    @SuppressWarnings("unchecked")
    private static final class GenericIndexer<T extends Comparable<T>> extends PropertyIndexer<T> {
        private final Map<Comparable<?>, Integer> toValueIndex;
        GenericIndexer(Property<T> property) {
            super(property, (T[]) property.getPossibleValues().toArray(new Comparable[0]));
            ImmutableMap.Builder<Comparable<?>, Integer> builder = ImmutableMap.builder();
            for (int i = 0; i < valuesInOrder.length; i++) builder.put(valuesInOrder[i], i);
            this.toValueIndex = builder.build();
        }
        @Override public int toIndex(T value) { return toValueIndex.getOrDefault(value, -1); }
    }
}
