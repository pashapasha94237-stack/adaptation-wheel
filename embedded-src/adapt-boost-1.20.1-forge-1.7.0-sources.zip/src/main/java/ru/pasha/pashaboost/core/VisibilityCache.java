package ru.pasha.pashaboost.core;

/** Fixed-size direct-mapped cache; never retains entities, worlds or chunk objects. */
public final class VisibilityCache {
    private final Entry[] entries;
    public VisibilityCache(int capacity) {
        if (capacity < 1) throw new IllegalArgumentException("capacity");
        entries = new Entry[capacity];
    }
    public Boolean get(int id, long identity, long tick, double cx, double cy, double cz,
                       double ex, double ey, double ez) {
        Entry e = entries[Math.floorMod(id, entries.length)];
        if (e == null || e.id != id || e.identity != identity || tick < e.tick || tick >= e.until
                || squared(cx-e.cx, cy-e.cy, cz-e.cz) > 0.25
                || squared(ex-e.ex, ey-e.ey, ez-e.ez) > 0.0625) return null;
        return e.hidden;
    }
    public void put(int id, long identity, long tick, int lifetime, double cx, double cy, double cz,
                    double ex, double ey, double ez, boolean hidden) {
        int slot = Math.floorMod(id, entries.length);
        Entry e = entries[slot];
        if (e == null) entries[slot] = e = new Entry();
        e.id=id; e.identity=identity; e.tick=tick; e.until=tick+Math.max(1,lifetime);
        e.cx=cx; e.cy=cy; e.cz=cz; e.ex=ex; e.ey=ey; e.ez=ez; e.hidden=hidden;
    }
    public void clear() { java.util.Arrays.fill(entries, null); }
    public int capacity() { return entries.length; }
    private static double squared(double x, double y, double z) { return x*x+y*y+z*z; }
    private static final class Entry {
        int id;
        long identity,tick,until;
        double cx,cy,cz,ex,ey,ez;
        boolean hidden;
    }
}
