package ru.pasha.pashaboost.mixin;

import com.mojang.logging.LogUtils;
import net.minecraft.world.level.block.state.BlockBehaviour;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.pasha.pashaboost.memory.ShapeDedup;

/** Equal cached shapes of block states become one object, see ShapeDedup. Launch-time and earned only: see MemoryGate. */
// Both names; require = 0 so a conflicting mod only disables this.
@Mixin(value = BlockBehaviour.BlockStateBase.class, remap = false)
public abstract class BlockStateCacheMemoryMixin {
    /** One failure (a field renamed by another mod, say) turns the saving off instead of breaking every block. */
    @Unique private static volatile boolean pashaboost$failed;

    @Inject(method = {"initCache()V", "m_60611_()V"}, at = @At("HEAD"), require = 0, remap = false)
    private void pashaboost$rememberCache(CallbackInfo ci) {
        if (pashaboost$failed) return;
        try { ShapeDedup.before((BlockBehaviour.BlockStateBase) (Object) this); } catch (Throwable t) { pashaboost$fail(t); }
    }

    @Inject(method = {"initCache()V", "m_60611_()V"}, at = @At("TAIL"), require = 0, remap = false)
    private void pashaboost$shareShapes(CallbackInfo ci) {
        if (pashaboost$failed) return;
        try { ShapeDedup.after((BlockBehaviour.BlockStateBase) (Object) this); } catch (Throwable t) { pashaboost$fail(t); }
    }

    @Unique
    private static void pashaboost$fail(Throwable t) {
        pashaboost$failed = true;
        LogUtils.getLogger().warn("Adapt Boost stopped sharing block shapes", t);
    }
}
