package ru.pasha.pashaboost.core;

import it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap;
import java.lang.ref.WeakReference;

/**
 * Server thread only. One slot per JVM: AM keeps one AMWorldData per server (always the overworld), and AM's static
 * dataMap never forgets old worlds, so the memo must not live in that instance. The owner is weak, so an old
 * world's RandomState is never pinned.
 */
public final class PupfishColumns {
    public static final int MAX = 1 << 16;                 // 62,500 candidate chunks at AM's default distance
    public static final int MISSING = Integer.MIN_VALUE;   // getWaterHeight returns >= minBuildHeight
    private static WeakReference<Object> owner = new WeakReference<>(null);
    private static Long2IntOpenHashMap heights;

    private static long key(int x, int z) { return ((long) x & 0xFFFFFFFFL) | ((long) z << 32); }

    public static int get(Object randomState, int x, int z) {
        Long2IntOpenHashMap h = heights;
        return h != null && owner.get() == randomState ? h.get(key(x, z)) : MISSING;
    }
    public static void put(Object randomState, int x, int z, int value) {
        if (heights == null || owner.get() != randomState) {
            heights = new Long2IntOpenHashMap();
            heights.defaultReturnValue(MISSING);
            owner = new WeakReference<>(randomState);
        }
        if (heights.size() < MAX) heights.put(key(x, z), value);
    }
    public static void release() { heights = null; owner = new WeakReference<>(null); }
    private PupfishColumns() {}
}
