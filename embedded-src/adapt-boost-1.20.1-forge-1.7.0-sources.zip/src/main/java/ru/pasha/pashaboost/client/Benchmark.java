package ru.pasha.pashaboost.client;

import com.google.gson.GsonBuilder;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.fml.ModList;
import ru.pasha.pashaboost.BoostConfig;
import ru.pasha.pashaboost.PashaBoost;
import ru.pasha.pashaboost.core.FrameStats;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Locale;

/** Measures switchable visual work after the FPS adaptation has been unlocked. */
public final class Benchmark {
    private static final long SECOND=1_000_000_000L;
    private static final FrameStats SAMPLES=new FrameStats(16384);
    private static long started;
    private static int phase=-1;
    private static FrameStats.Snapshot baseline;
    private static double x,y,z;
    private static String status="";
    private static long lastShown=-1;
    /** The last finished A/B result for the settings screen: FPS and 1% low, off then on. */
    private static double[] last;

    public static boolean running() { return phase>=0; }
    static double[] last() { return last; }
    public static String status() { return status; }
    public static void start() {
        Minecraft mc=Minecraft.getInstance();
        if(mc.player==null) return;
        if (!ru.pasha.pashaboost.api.FpsAdaptationBoost.isActive()) {
            mc.player.displayClientMessage(Component.translatable("pashaboost.adaptation_required"),true);
            return;
        }
        x=mc.player.getX(); y=mc.player.getY(); z=mc.player.getZ();
        phase=0; lastShown=-1; started=System.nanoTime(); baseline=null; SAMPLES.clear();
        EntityOptimizer.clear(); BoostConfig.setBenchmarkOverride(false);
        status=Component.translatable("pashaboost.bench.warmup",5).getString();
        mc.player.displayClientMessage(Component.translatable("pashaboost.bench.start"),false);
    }
    public static void cancel() {
        phase=-1; BoostConfig.setBenchmarkOverride(null); SAMPLES.clear(); baseline=null; status="";
        EntityOptimizer.clear();
    }
    public static void frame(long now,long nanos) {
        if(!running()) return;
        long elapsed=(now-started)/SECOND;
        int length=(phase==0 || phase==2)?5:20;
        String key=(phase==0 || phase==2)?"pashaboost.bench.warmup":phase==1?"pashaboost.bench.off":"pashaboost.bench.on";
        if(lastShown!=elapsed) {
            lastShown=elapsed;
            status=Component.translatable(key,Math.max(0,length-elapsed)).getString();
        }
        if(phase==1 || phase==3) SAMPLES.addNanos(nanos);
        if(now-started<length*SECOND) return;
        if(phase==1) baseline=SAMPLES.snapshot();
        if(phase==3) { finish(SAMPLES.snapshot()); return; }
        phase++; started=now; lastShown=-1; SAMPLES.clear();
        if(phase==2) { EntityOptimizer.clear(); BoostConfig.setBenchmarkOverride(true); }
    }
    private static void finish(FrameStats.Snapshot optimized) {
        Minecraft mc=Minecraft.getInstance();
        FrameStats.Snapshot before=baseline;
        phase=-1; BoostConfig.setBenchmarkOverride(null); SAMPLES.clear();
        if(mc.player==null || before==null) return;
        double ratio=before.averageFps()>0?optimized.averageFps()/before.averageFps():0;
        last=new double[]{before.averageFps(),optimized.averageFps(),before.onePercentLowFps(),optimized.onePercentLowFps()};
        mc.player.displayClientMessage(Component.literal(String.format(Locale.ROOT,
                "Adapt Boost A/B: %.1f → %.1f FPS (×%.2f); 1%% low %.1f → %.1f",before.averageFps(),optimized.averageFps(),ratio,
                before.onePercentLowFps(),optimized.onePercentLowFps())),false);
        try {
            var result=new LinkedHashMap<String,Object>();
            result.put("scope","Adapt Boost switchable visual profile OFF/ON after wheel unlock; adaptive scale fixed at 1.0; glyph packing stays unchanged in both phases");
            result.put("baseline",before); result.put("optimized",optimized); result.put("fpsRatio",ratio);
            result.put("movedBlocks",Math.sqrt(mc.player.distanceToSqr(x,y,z)));
            result.put("renderDistance",mc.options.renderDistance().get());
            result.put("fpsCap",mc.options.framerateLimit().get()); result.put("vsync",mc.options.enableVsync().get());
            result.put("dimension",mc.level.dimension().location().toString());
            result.put("mods",ModList.get().getMods().stream().map(m->m.getModId()+":"+m.getVersion()).toList());
            var config=new LinkedHashMap<String,Object>();
            config.put("entityCulling",BoostConfig.ENTITY_CULLING.get());
            config.put("entityDistance",BoostConfig.ENTITY_DISTANCE.get());
            config.put("nearDistance",BoostConfig.NEAR_DISTANCE.get());
            config.put("wallCulling",BoostConfig.WALL_CULLING.get());
            config.put("wallChecksPerTick",BoostConfig.WALL_CHECKS_PER_TICK.get());
            config.put("cacheTicks",BoostConfig.VISIBILITY_CACHE_TICKS.get());
            config.put("particles",BoostConfig.PARTICLES.get());
            config.put("particleDistance",BoostConfig.PARTICLE_DISTANCE.get());
            config.put("particleLimit",BoostConfig.PARTICLE_LIMIT.get());
            config.put("newParticlesPerTick",BoostConfig.PARTICLES_PER_TICK.get());
            config.put("filterModParticles",BoostConfig.FILTER_MOD_PARTICLES.get());
            config.put("fpsAdaptationBoost",ru.pasha.pashaboost.api.FpsAdaptationBoost.isActive());
            config.put("effectiveEntityDistance",BoostConfig.entityDistance());
            config.put("effectiveParticleDistance",BoostConfig.particleDistance());
            config.put("effectiveParticleLimit",BoostConfig.particleLimit());
            config.put("adaptiveScaleDuringBenchmark",1.0);
            result.put("config",config);
            Path directory=mc.gameDirectory.toPath().resolve("pashaboost/benchmarks");
            Files.createDirectories(directory);
            Path path=directory.resolve(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss"))+".json");
            Files.writeString(path,new GsonBuilder().setPrettyPrinting().create().toJson(result),StandardCharsets.UTF_8);
            mc.player.displayClientMessage(Component.translatable("pashaboost.bench.saved",path.toString()),false);
        } catch(Exception ex) { PashaBoost.LOGGER.warn("Could not save benchmark",ex); }
        EntityOptimizer.clear();
    }
    private Benchmark() {}
}
