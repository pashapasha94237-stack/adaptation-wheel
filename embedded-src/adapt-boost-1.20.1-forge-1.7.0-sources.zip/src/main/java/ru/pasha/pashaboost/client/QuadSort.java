package ru.pasha.pashaboost.client;

import com.mojang.blaze3d.vertex.BufferBuilder;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import org.joml.Vector3f;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodType;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.util.Arrays;

/**
 * Quad sorting of BufferBuilder (setQuadSorting -> putSortedQuadIndices) for the two built-in sortings, with the same
 * result as vanilla. Vanilla allocates a Vector3f per quad, a float[] of keys, an int[] permutation and a comparator, runs
 * fastutil's IntArrays.mergeSort (stable, comparator Floats.compare(key[b], key[a])) and writes the indices through an
 * IntConsumer lambda. Here the centroids stay in a float[] and each quad becomes one long: the sortable bits of its key,
 * inverted, over the quad index. Float.compare is a total preorder, so a stable descending sort has exactly one result:
 * keys descending, equal keys by ascending index; the packed longs are all distinct and have that same order, so any
 * ascending long sort gives the vanilla permutation. Everything here is JDK-only except the Vector3f receiver (JOML), so
 * the logic is unit-tested against the real VertexSorting classes. Idea from Sodium 0.5's sorting rework (LGPL-3.0); own code.
 */
public final class QuadSort {
    /** Arrays kept per builder up to this many quads; a bigger batch frees them right after use. */
    public static final int RETAIN_QUADS = 1 << 16;

    /** JOML types in static fields, kept out of QuadSort's own initialiser. */
    public static final class Refs {
        /** Stands in for vanilla's sortingPoints between setQuadSorting and the end of the batch; nobody else can own it. */
        public static final Vector3f[] PENDING = new Vector3f[0];
        /** The receiver of VertexSorting.DISTANCE_TO_ORIGIN's distanceSquared, which is byDistance(0, 0, 0). Never modified. */
        static final Vector3f ORIGIN = new Vector3f(0.0F, 0.0F, 0.0F);
        private Refs() {}
    }

    /**
     * OptiFine's BufferBuilder.quadSprites (multi-texture shaders). Its putSortedQuadIndices ends with quadOrdering = order,
     * which the fast path does not produce, so a builder that has sprites always takes the vanilla sort. Read through the
     * loaded class, not through the plugin's OptiFine flag. The field is private: a VarHandle from unreflectVarHandle checks
     * access against the lookup class whatever the accessible flag says (so it always fails here), while the getter form
     * from unreflectGetter honours setAccessible. Initialised on first use, when BufferBuilder is already loaded.
     */
    public static final class Sprites {
        private static final Getter BUILDER = Getter.resolve(BufferBuilder.class);
        /** False only when the field exists and cannot be read: then the feature stays off. */
        public static final boolean OK = BUILDER.ok;
        /** True when this builder has OptiFine quad sprites; true (take vanilla) when it cannot be read. */
        public static boolean present(BufferBuilder builder) { return BUILDER.present(builder); }

        /** A reader of {@code quadSprites} on one class; {@code handle} is null when the class has no such field. */
        public static final class Getter {
            final boolean ok;
            private final MethodHandle handle;
            private Getter(boolean ok, MethodHandle handle) { this.ok = ok; this.handle = handle; }

            /** Plain Forge has no field (ok, nothing to read); a field of another type or one that cannot be opened is not ok. */
            public static Getter resolve(Class<?> owner) {
                try {
                    Field field = owner.getDeclaredField("quadSprites");
                    if (field.getType() != TextureAtlasSprite[].class || Modifier.isStatic(field.getModifiers())) return new Getter(false, null);
                    field.setAccessible(true);
                    MethodHandle getter = MethodHandles.lookup().unreflectGetter(field)
                            .asType(MethodType.methodType(TextureAtlasSprite[].class, Object.class));
                    return new Getter(true, getter);
                } catch (NoSuchFieldException e) {
                    return new Getter(true, null);
                } catch (Exception | LinkageError e) {
                    return new Getter(false, null);
                }
            }

            public boolean ok() { return ok; }

            /** True when the field is non-null on {@code builder}; true as well when it cannot be read (the caller falls back). */
            public boolean present(Object builder) {
                MethodHandle h = handle;
                if (h == null) return !ok;
                try {
                    return (TextureAtlasSprite[]) h.invokeExact(builder) != null;
                } catch (Throwable t) {
                    return true;
                }
            }
        }
        private Sprites() {}
    }

    /**
     * makeQuadSortingPoints without the Vector3f array: the same FloatBuffer reads at the same indices and the same
     * (a + b) / 2.0F in float, stored as x, y, z per quad. {@code base} is renderedBufferPointer / 4, {@code vertexInts}
     * the format's integer size and {@code primitiveStride} the mode's vertex count per quad.
     */
    public static void centroids(FloatBuffer fb, int base, int vertexInts, int primitiveStride, int quads, float[] out) {
        int quadInts = vertexInts * primitiveStride;
        for (int q = 0; q < quads; q++) {
            int p = base + q * quadInts;
            float x0 = fb.get(p), y0 = fb.get(p + 1), z0 = fb.get(p + 2);
            float x1 = fb.get(p + vertexInts * 2), y1 = fb.get(p + vertexInts * 2 + 1), z1 = fb.get(p + vertexInts * 2 + 2);
            int o = q * 3;
            out[o] = (x0 + x1) / 2.0F;
            out[o + 1] = (y0 + y1) / 2.0F;
            out[o + 2] = (z0 + z1) / 2.0F;
        }
    }

    /** What vanilla would have stored in sortingPoints: a fresh Vector3f per quad with the same three floats. */
    public static Vector3f[] materialize(float[] centroids, int quads) {
        Vector3f[] points = new Vector3f[quads];
        for (int q = 0; q < quads; q++) points[q] = new Vector3f(centroids[q * 3], centroids[q * 3 + 1], centroids[q * 3 + 2]);
        return points;
    }

    /**
     * The sort key of each quad packed with its index. Distance: Vector3f.distanceSquared(Vector3fc) of an all-zero
     * receiver, the method VertexSorting.byDistance binds for DISTANCE_TO_ORIGIN. Orthographic: the negated z of lambda
     * m_277160_. {@code tmp} is a scratch Vector3f owned by the caller.
     */
    public static void keys(float[] centroids, int quads, boolean distance, long[] out, Vector3f tmp) {
        if (distance) {
            Vector3f origin = Refs.ORIGIN;
            for (int q = 0; q < quads; q++) {
                int o = q * 3;
                out[q] = pack(origin.distanceSquared(tmp.set(centroids[o], centroids[o + 1], centroids[o + 2])), q);
            }
        } else {
            for (int q = 0; q < quads; q++) out[q] = pack(-centroids[q * 3 + 2], q);
        }
    }

    /**
     * Ascending order of the result is: key descending under Float.compare, then index ascending. The bits are
     * canonical for NaN (floatToIntBits, as in Float.compare); the xor makes negative floats order like their magnitudes
     * reversed, so -0.0 maps to -1 and +0.0 to 0 and NaN ends above +Infinity. The bitwise complement reverses the order.
     */
    public static long pack(float key, int index) {
        int bits = Float.floatToIntBits(key);
        int sortable = bits ^ ((bits >> 31) & 0x7fffffff);
        return ((long) ~sortable << 32) | index;
    }

    /** Sorts the first {@code quads} packed keys; they are all distinct, so stability does not matter. */
    public static void sort(long[] keys, int quads) { Arrays.sort(keys, 0, quads); }

    /**
     * Sorted indices exactly as vanilla's IntConsumer lambdas write them: per quad, absolute puts at {@code offset} of
     * {@code (short) (index * primitiveStride + c)} (or int) for c in 0, 1, 2, 2, 3, 0.
     */
    public static void write(ByteBuffer buffer, int offset, long[] keys, int quads, int primitiveStride, boolean shortIndices) {
        int off = offset;
        if (shortIndices) {
            for (int t = 0; t < quads; t++) {
                int v = (int) keys[t] * primitiveStride;
                buffer.putShort(off, (short) v);
                buffer.putShort(off + 2, (short) (v + 1));
                buffer.putShort(off + 4, (short) (v + 2));
                buffer.putShort(off + 6, (short) (v + 2));
                buffer.putShort(off + 8, (short) (v + 3));
                buffer.putShort(off + 10, (short) v);
                off += 12;
            }
        } else {
            for (int t = 0; t < quads; t++) {
                int v = (int) keys[t] * primitiveStride;
                buffer.putInt(off, v);
                buffer.putInt(off + 4, v + 1);
                buffer.putInt(off + 8, v + 2);
                buffer.putInt(off + 12, v + 2);
                buffer.putInt(off + 16, v + 3);
                buffer.putInt(off + 20, v);
                off += 24;
            }
        }
    }

    private QuadSort() {}
}
