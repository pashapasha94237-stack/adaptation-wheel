package ru.pasha.pashaboost.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.objectweb.asm.tree.AnnotationNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.MethodNode;
import org.spongepowered.asm.mixin.Mixins;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

/**
 * Reads the mixins other mods applied to a class and lists the members that hook any of the given method names.
 * Used once, on the render thread, before the shared particle light table may skip code those mods hook.
 */
final class ForeignLightHooks {
    private static final String OWN_CONFIG = "pashaboost.mixins.json";

    /**
     * "mixinClass.member" for every foreign mixin member that targets one of the tokens. allValues: also look at
     * every string of an annotation (an @At target, say), not only its method selector.
     */
    static List<String> find(String className, boolean allValues, String... tokens) {
        List<String> found = new ArrayList<>();
        Set<IMixinInfo> infos = Mixins.getMixinsForClass(className);
        if (infos == null) return found;
        for (IMixinInfo info : infos) {
            if (info.getConfig() != null && OWN_CONFIG.equals(info.getConfig().getName())) continue;
            ClassNode node = info.getClassNode(0);
            for (MethodNode method : node.methods) {
                if (hooks(method, allValues, tokens)) found.add(info.getClassName() + "." + method.name);
            }
        }
        return found;
    }

    private static boolean hooks(MethodNode method, boolean allValues, String[] tokens) {
        boolean shadowOrUnique = false, annotated = false;
        for (List<AnnotationNode> list : List.of(nonNull(method.visibleAnnotations), nonNull(method.invisibleAnnotations))) {
            for (AnnotationNode annotation : list) {
                annotated = true;
                if (annotation.desc.endsWith("/Shadow;") || annotation.desc.endsWith("/Unique;")) shadowOrUnique = true;
                if (mentions(annotation.values, allValues, false, tokens)) return true;
                // @Overwrite of the hooked method itself.
                if (annotation.desc.endsWith("/Overwrite;") && isOneOf(method.name, tokens)) return true;
            }
        }
        // A plain member with the hooked name is merged over the target method.
        return !shadowOrUnique && !annotated && (method.access & 0x1400) == 0 && isOneOf(method.name, tokens);
    }

    private static boolean mentions(List<Object> values, boolean allValues, boolean selector, String[] tokens) {
        if (values == null) return false;
        for (int i = 0; i + 1 < values.size(); i += 2) {
            boolean isSelector = selector || "method".equals(values.get(i));
            if (value(values.get(i + 1), allValues, isSelector, tokens)) return true;
        }
        return false;
    }

    private static boolean value(Object value, boolean allValues, boolean selector, String[] tokens) {
        if (value instanceof String text) return (selector || allValues) && (wildcard(text) || named(text, tokens));
        if (value instanceof AnnotationNode nested) return mentions(nested.values, allValues, false, tokens);
        if (value instanceof List<?> list) {
            for (Object item : list) if (value(item, allValues, selector, tokens)) return true;
        }
        return false;
    }

    // "*" and regex selectors ("/.../") can match any method.
    private static boolean wildcard(String text) { return text.equals("*") || text.startsWith("/") || text.startsWith("*"); }

    private static boolean named(String text, String[] tokens) {
        for (String token : tokens) if (text.contains(token)) return true;
        return false;
    }

    // Method names compare exactly: a helper called getBlockStateCached is not an overwrite of getBlockState.
    private static boolean isOneOf(String name, String[] tokens) {
        for (String token : tokens) if (name.equals(token)) return true;
        return false;
    }

    private static List<AnnotationNode> nonNull(List<AnnotationNode> list) { return list == null ? List.of() : list; }

    private ForeignLightHooks() {}
}
