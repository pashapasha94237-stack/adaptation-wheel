package ru.pasha.pashaboost.memory;

import com.google.common.collect.Table;
import com.google.common.collect.Tables;
import net.minecraft.world.level.block.state.properties.Property;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Read-only view of one state's neighbours, answered from the block's FastMap; it takes the place of vanilla's
 * per-state table. Ported from FerriteCore 6.0.1 by malte0811 (MIT, see THIRD-PARTY.md).
 */
final class NeighbourTableView<S> implements Table<Property<?>, Comparable<?>, S> {
    private final FastMapStateHolder<S> owner;

    NeighbourTableView(FastMapStateHolder<S> owner) { this.owner = owner; }

    private FastMap<S> map() { return owner.pashaboost$stateMap(); }
    private int index() { return owner.pashaboost$stateIndex(); }

    @Override public @Nullable S get(@Nullable Object row, @Nullable Object column) {
        return row instanceof Property<?> property ? map().withUnsafe(index(), property, column) : null;
    }

    @Override public boolean contains(@Nullable Object row, @Nullable Object column) {
        if (!(row instanceof Property<?> property) || !(column instanceof Comparable)) return false;
        Comparable<?> current = map().getValue(index(), property);
        return current != null && !current.equals(column) && property.getPossibleValues().contains(column);
    }

    @Override public boolean containsRow(@Nullable Object row) { return row instanceof Property<?> property && map().getValue(index(), property) != null; }

    @Override public boolean containsColumn(@Nullable Object column) {
        for (int i = 0; i < map().numProperties(); i++) {
            Map.Entry<Property<?>, Comparable<?>> entry = map().entry(i, index());
            if (!entry.getValue().equals(column) && entry.getKey().getPossibleValues().contains(column)) return true;
        }
        return false;
    }

    @Override public boolean containsValue(@Nullable Object value) { return value != null && values().contains(value); }
    @Override public boolean isEmpty() { return map().isSingleState(); }

    @Override public int size() {
        int size = 0;
        for (int i = 0; i < map().numProperties(); i++) size += map().key(i).numValues() - 1;
        return size;
    }

    @Override public Map<Comparable<?>, S> row(Property<?> row) {
        Map<Comparable<?>, S> result = new HashMap<>();
        Comparable<?> current = map().getValue(index(), row);
        // A property of another block has no row, as in vanilla's table.
        if (current == null) return result;
        for (Comparable<?> value : row.getPossibleValues()) if (!value.equals(current)) result.put(value, map().withUnsafe(index(), row, value));
        return result;
    }

    @Override public Map<Property<?>, S> column(Comparable<?> column) {
        Map<Property<?>, S> result = new HashMap<>();
        for (Cell<Property<?>, Comparable<?>, S> cell : cellSet()) if (cell.getColumnKey().equals(column)) result.put(cell.getRowKey(), cell.getValue());
        return result;
    }

    @Override public Set<Cell<Property<?>, Comparable<?>, S>> cellSet() {
        Set<Cell<Property<?>, Comparable<?>, S>> cells = new HashSet<>();
        for (int i = 0; i < map().numProperties(); i++) {
            Property<?> property = map().key(i).property();
            Comparable<?> current = map().getValue(index(), property);
            for (Comparable<?> value : property.getPossibleValues())
                if (!value.equals(current)) cells.add(Tables.immutableCell(property, value, map().withUnsafe(index(), property, value)));
        }
        return cells;
    }

    @Override public Set<Property<?>> rowKeySet() { return owner.pashaboost$vanillaValues().keySet(); }

    @Override public Set<Comparable<?>> columnKeySet() {
        Set<Comparable<?>> columns = new HashSet<>();
        for (Cell<Property<?>, Comparable<?>, S> cell : cellSet()) columns.add(cell.getColumnKey());
        return columns;
    }

    @Override public Collection<S> values() {
        Set<S> values = new HashSet<>();
        for (Cell<Property<?>, Comparable<?>, S> cell : cellSet()) values.add(cell.getValue());
        return values;
    }

    @Override public Map<Property<?>, Map<Comparable<?>, S>> rowMap() {
        Map<Property<?>, Map<Comparable<?>, S>> rows = new HashMap<>();
        for (int i = 0; i < map().numProperties(); i++) { Property<?> property = map().key(i).property(); rows.put(property, row(property)); }
        return rows;
    }

    @Override public Map<Comparable<?>, Map<Property<?>, S>> columnMap() {
        Map<Comparable<?>, Map<Property<?>, S>> columns = new HashMap<>();
        for (Cell<Property<?>, Comparable<?>, S> cell : cellSet())
            columns.computeIfAbsent(cell.getColumnKey(), c -> new HashMap<>()).put(cell.getRowKey(), cell.getValue());
        return columns;
    }

    @Override public void clear() { throw readOnly(); }
    @Override public S put(Property<?> row, Comparable<?> column, S value) { throw readOnly(); }
    @Override public void putAll(Table<? extends Property<?>, ? extends Comparable<?>, ? extends S> table) { throw readOnly(); }
    @Override public S remove(@Nullable Object row, @Nullable Object column) { throw readOnly(); }
    private static UnsupportedOperationException readOnly() {
        return new UnsupportedOperationException("Block-state neighbour tables are read-only (Adapt Boost memory saving)");
    }
}
