package ru.pasha.pashaboost.client;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;

/** Added to SpriteCoordinateExpander under OptiFine I6 by OfSpriteExpanderMixin. */
public interface OfSpriteExpander {
    VertexConsumer pashaboost$delegate();
    TextureAtlasSprite pashaboost$sprite();
}
