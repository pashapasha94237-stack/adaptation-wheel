package ru.pasha.pashaboost.core;

/** Reusable allowance for a short extra write burst; does not allocate or own pending writes. */
public final class WriteDrainBudget {
    public static final int MAX_EXTRA_WRITES = 4;
    public static final long MAX_BUDGET_NANOS = 2_000_000L;

    private int threshold;
    private int limit;
    private int acquired;
    private long budgetNanos;
    private long startedNanos;

    /** Captures a burst's tuning so a configuration reload cannot extend an ongoing burst. */
    public void begin(int threshold, int requestedWrites, long requestedNanos, long nowNanos) {
        this.threshold = Math.max(0, threshold);
        limit = Math.max(0, Math.min(MAX_EXTRA_WRITES, requestedWrites));
        budgetNanos = Math.max(0, Math.min(MAX_BUDGET_NANOS, requestedNanos));
        startedNanos = nowNanos;
        acquired = 0;
    }

    /**
     * Reserves one extra write only while the backlog remains above the threshold.
     * Time is checked before each operation; a disk operation already running is not interrupted.
     */
    public boolean tryAcquire(int pendingWrites, long nowNanos) {
        long elapsed = nowNanos - startedNanos;
        if (pendingWrites <= threshold || acquired >= limit || budgetNanos == 0
                || elapsed < 0 || elapsed >= budgetNanos) {
            return false;
        }
        acquired++;
        return true;
    }

    public int acquired() { return acquired; }
}
