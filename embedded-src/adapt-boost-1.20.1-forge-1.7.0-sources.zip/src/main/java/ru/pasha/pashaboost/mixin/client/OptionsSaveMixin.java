package ru.pasha.pashaboost.mixin.client;

import net.minecraft.client.Options;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Group;
import org.spongepowered.asm.mixin.injection.Redirect;
import ru.pasha.pashaboost.client.SavedOptionsAccess;

/** Changes serialization only; never changes the live options during a save. */
@Mixin(value = Options.class, remap = false)
public abstract class OptionsSaveMixin {
    @Shadow(aliases = {"m_168427_"}, remap = false)
    private void processOptions(Options.FieldAccess visitor) { throw new AssertionError("Mixin shadow"); }

    @Group(name = "pashaboost$save", min = 1, max = 1)
    @Redirect(method = {"save()V", "m_92169_()V"},
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Options;processOptions(Lnet/minecraft/client/Options$FieldAccess;)V", remap = false),
            require = 0, remap = false)
    private void pashaboost$saveNamed(Options self, Options.FieldAccess visitor) {
        processOptions(new SavedOptionsAccess(visitor));
    }

    @Group(name = "pashaboost$save", min = 1, max = 1)
    @Redirect(method = {"save()V", "m_92169_()V"},
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Options;m_168427_(Lnet/minecraft/client/Options$FieldAccess;)V", remap = false),
            require = 0, remap = false)
    private void pashaboost$saveSrg(Options self, Options.FieldAccess visitor) {
        processOptions(new SavedOptionsAccess(visitor));
    }
}
