package ru.pasha.pashaboost.mixin.client;

import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexSorting;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.pasha.pashaboost.OptimizationCounters;
import ru.pasha.pashaboost.RuntimeTuning;
import ru.pasha.pashaboost.client.QuadSort;
import ru.pasha.pashaboost.client.QuadSortGate;

import java.nio.ByteBuffer;
import java.nio.FloatBuffer;

/**
 * Sorted render types (translucent entities, banners, beacon beams, eyes, GUI) sort their quads when the batch ends.
 * JFR with OptiFine, render thread: makeQuadSortingPoints, VertexSorting's key arrays and IntArrays.mergeSort allocate
 * about 12 % of everything the thread allocates, and the sort plus the index lambdas cost about 2 % of its time. The
 * two constant sortings (DISTANCE_TO_ORIGIN, ORTHOGRAPHIC_Z) are done on primitive arrays with vanilla's exact permutation
 * and bytes; chunk resorts use a fresh byDistance sorting and stay vanilla. Idea from Sodium 0.5's sorting rework
 * (LGPL-3.0); own code.
 */
// All three handlers must be present (QuadSortGate.READY, checked by the plugin after the merge): setQuadSorting stores the
// centroids and leaves the PENDING marker in sortingPoints, getSortState and putSortedQuadIndices resolve it. Resolving
// never looks at a runtime flag, so switching the flag off mid-batch cannot strand a marker. Every injector has require = 0.
// Shadows are SRG-named; the same field is identical in OptiFine's and Forge's BufferBuilder (private, same types).
@Mixin(value = BufferBuilder.class, remap = false)
public abstract class QuadSortMixin {
    @Shadow(aliases = {"buffer"}, remap = false) private ByteBuffer f_85648_;
    @Shadow(aliases = {"renderedBufferPointer"}, remap = false) private int f_231157_;
    @Shadow(aliases = {"nextElementByte"}, remap = false) private int f_85652_;
    @Shadow(aliases = {"vertices"}, remap = false) private int f_85654_;
    @Shadow(aliases = {"format"}, remap = false) private VertexFormat f_85658_;
    @Shadow(aliases = {"mode"}, remap = false) private VertexFormat.Mode f_85657_;
    @Shadow(aliases = {"sortingPoints"}, remap = false) private Vector3f[] f_166766_;
    @Shadow(aliases = {"sorting"}, remap = false) private VertexSorting f_276463_;

    // One builder is filled and flushed by one thread at a time. Centroids are x, y, z per quad.
    @Unique private float[] pashaboost$centroids;
    @Unique private long[] pashaboost$keys;
    @Unique private int pashaboost$quads;
    @Unique private Vector3f pashaboost$tmp;

    @Inject(method = {"setQuadSorting(Lcom/mojang/blaze3d/vertex/VertexSorting;)V", "m_277127_(Lcom/mojang/blaze3d/vertex/VertexSorting;)V"},
            at = @At("HEAD"), cancellable = true, require = 0, remap = false)
    private void pashaboost$quadSortBegin(VertexSorting sorting, CallbackInfo ci) {
        if (!RuntimeTuning.ACTIVE || !RuntimeTuning.QUAD_SORT || !QuadSortGate.READY) return;
        if (this.f_85657_ != VertexFormat.Mode.QUADS || this.f_166766_ != null) return;
        if (sorting != VertexSorting.DISTANCE_TO_ORIGIN && sorting != VertexSorting.ORTHOGRAPHIC_Z) return;
        if (!QuadSort.Sprites.OK || QuadSort.Sprites.present((BufferBuilder) (Object) this)) return;
        try {
            int stride = this.f_85657_.primitiveStride;
            int quads = this.f_85654_ / stride;
            float[] centroids = this.pashaboost$centroids;
            if (centroids == null || centroids.length < quads * 3) {
                centroids = new float[Math.max(quads * 3, centroids == null ? 0 : centroids.length + (centroids.length >> 1))];
                this.pashaboost$centroids = null; // the old array is garbage, and a failure below must not leave a short one
            }
            QuadSort.centroids(this.f_85648_.asFloatBuffer(), this.f_231157_ / 4, this.f_85658_.getIntegerSize(), stride, quads, centroids);
            this.pashaboost$centroids = centroids;
            this.pashaboost$quads = quads;
            this.f_276463_ = sorting;
            this.f_166766_ = QuadSort.Refs.PENDING;
            ci.cancel();
        } catch (RuntimeException e) {
            // Vanilla runs next and fails, or succeeds, the way it always did.
            OptimizationCounters.quadSortsFallback.incrementAndGet();
        }
    }

    @Inject(method = {"getSortState()Lcom/mojang/blaze3d/vertex/BufferBuilder$SortState;", "m_166770_()Lcom/mojang/blaze3d/vertex/BufferBuilder$SortState;"},
            at = @At("HEAD"), require = 0, remap = false)
    private void pashaboost$quadSortState(CallbackInfoReturnable<BufferBuilder.SortState> cir) {
        if (this.f_166766_ == QuadSort.Refs.PENDING) pashaboost$materialize();
    }

    @Inject(method = {"putSortedQuadIndices(Lcom/mojang/blaze3d/vertex/VertexFormat$IndexType;)V", "m_166786_(Lcom/mojang/blaze3d/vertex/VertexFormat$IndexType;)V"},
            at = @At("HEAD"), cancellable = true, require = 0, remap = false)
    private void pashaboost$quadSortWrite(VertexFormat.IndexType type, CallbackInfo ci) {
        if (this.f_166766_ != QuadSort.Refs.PENDING) return;
        VertexSorting sorting = this.f_276463_;
        boolean distance = sorting == VertexSorting.DISTANCE_TO_ORIGIN;
        boolean shortIndices = type == VertexFormat.IndexType.SHORT;
        // A second setQuadSorting may have replaced the sorting, OptiFine may have switched to multi-texture, and anything
        // but SHORT or INT is vanilla's to reject: vanilla then sorts the real points.
        if ((!distance && sorting != VertexSorting.ORTHOGRAPHIC_Z) || (!shortIndices && type != VertexFormat.IndexType.INT)
                || this.f_85657_ != VertexFormat.Mode.QUADS || !QuadSort.Sprites.OK || QuadSort.Sprites.present((BufferBuilder) (Object) this)) {
            OptimizationCounters.quadSortsFallback.incrementAndGet();
            pashaboost$materialize();
            return;
        }
        try {
            int quads = this.pashaboost$quads;
            long[] keys = this.pashaboost$keys;
            if (keys == null || keys.length < quads) this.pashaboost$keys = keys = new long[Math.max(quads, keys == null ? 0 : keys.length + (keys.length >> 1))];
            Vector3f tmp = this.pashaboost$tmp;
            if (tmp == null) this.pashaboost$tmp = tmp = new Vector3f();
            QuadSort.keys(this.pashaboost$centroids, quads, distance, keys, tmp);
            QuadSort.sort(keys, quads);
            QuadSort.write(this.f_85648_, this.f_85652_, keys, quads, this.f_85657_.primitiveStride, shortIndices);
            OptimizationCounters.quadSortsFast.incrementAndGet();
            // The marker stays; reset nulls it right after, as it nulls vanilla's array.
            if (quads > QuadSort.RETAIN_QUADS) { this.pashaboost$centroids = null; this.pashaboost$keys = null; }
            ci.cancel();
        } catch (RuntimeException e) {
            // Vanilla redoes all writes from the same offset with the real points, and fails or succeeds as it always did.
            OptimizationCounters.quadSortsFallback.incrementAndGet();
            pashaboost$materialize();
        }
    }

    /** Replaces the marker by the Vector3f array vanilla would have stored; the original code then proceeds on real points. */
    @Unique
    private void pashaboost$materialize() {
        float[] centroids = this.pashaboost$centroids;
        int quads = centroids == null ? 0 : Math.min(this.pashaboost$quads, centroids.length / 3);
        this.f_166766_ = QuadSort.materialize(centroids, quads);
        if (quads > QuadSort.RETAIN_QUADS) this.pashaboost$centroids = null;
    }
}
