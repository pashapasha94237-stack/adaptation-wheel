package ru.pasha.pashaboost.core;

/** Client-thread allocation budget. Important particles are observed but never rejected here. */
public final class ParticleBudget {
    private int observedActive;
    private int allocated;
    private int decorativeAllocated;
    private int activeLimit;
    private int perTickLimit;
    private long rejected;

    public void beginTick(int active, int activeLimit, int perTickLimit) {
        observedActive = Math.max(0, active);
        this.activeLimit = Math.max(0, activeLimit);
        this.perTickLimit = Math.max(0, perTickLimit);
        allocated = 0;
        decorativeAllocated = 0;
    }

    public boolean tryAcquire(double distanceSquared, double maxDistanceSquared) {
        if (!Double.isFinite(distanceSquared) || distanceSquared < 0
                || !Double.isFinite(maxDistanceSquared) || maxDistanceSquared < 0
                || distanceSquared > maxDistanceSquared || estimatedActive() >= activeLimit
                || decorativeAllocated >= perTickLimit) {
            rejected++;
            return false;
        }
        allocated++;
        decorativeAllocated++;
        return true;
    }

    /** A provider may legitimately return null; its unused reservation must be returned. */
    public void releaseReservation() {
        if (decorativeAllocated > 0) {
            decorativeAllocated--;
            allocated--;
        }
    }

    public void observeUnfilteredAllocation() {
        if (allocated < Integer.MAX_VALUE) allocated++;
    }

    public int estimatedActive() {
        return (int) Math.min(Integer.MAX_VALUE, (long) observedActive + allocated);
    }

    public long rejectedCount() { return rejected; }

    public void clear() {
        observedActive = allocated = decorativeAllocated = activeLimit = perTickLimit = 0;
        rejected = 0;
    }
}
