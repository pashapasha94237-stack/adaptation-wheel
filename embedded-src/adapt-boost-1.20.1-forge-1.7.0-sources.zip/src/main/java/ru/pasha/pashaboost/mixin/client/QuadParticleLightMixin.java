package ru.pasha.pashaboost.mixin.client;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.SingleQuadParticle;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import ru.pasha.pashaboost.OptimizationCounters;
import ru.pasha.pashaboost.RuntimeTuning;
import ru.pasha.pashaboost.client.ParticleLight;
import ru.pasha.pashaboost.client.SharedParticleLight;

/**
 * Every particle asked the world for its light on every frame. For particles whose light depends only on their block,
 * a particle that stays in the same block within the same client tick reuses its own last light (1.4). Only when it
 * moved or a tick passed does it ask SharedParticleLight's call-site table, keyed by block, client world revision and
 * ParticleEngine pass, for the light another particle in that block already got. JFR on OptiFine with the table alone
 * in front: 9.1 % of the render thread under this redirect, against 4.4 % with only the per-particle check: the probe
 * ran for every particle on every frame, while the check answers most frames by itself.
 */
// Each call site has a development and a production name; require = 0 so a conflicting mod only disables this.
// PARTICLE_LIGHT_CACHE (1.4) switches this redirect, PARTICLE_LIGHT_SHARE the table behind it.
@Mixin(value = SingleQuadParticle.class, remap = false)
public abstract class QuadParticleLightMixin extends Particle {
    @Unique private long pashaboost$lightPos = Long.MIN_VALUE, pashaboost$lightTick = Long.MIN_VALUE;
    @Unique private int pashaboost$lastLight;
    /** 0 not checked yet, 1 light depends on the block only, 2 the class computes its own light. */
    @Unique private byte pashaboost$positional;

    private QuadParticleLightMixin(ClientLevel level, double x, double y, double z) { super(level, x, y, z); }

    @Redirect(method = {"render(Lcom/mojang/blaze3d/vertex/VertexConsumer;Lnet/minecraft/client/Camera;F)V",
            "m_5744_(Lcom/mojang/blaze3d/vertex/VertexConsumer;Lnet/minecraft/client/Camera;F)V"},
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/particle/SingleQuadParticle;getLightColor(F)I", remap = false),
            require = 0, remap = false)
    private int pashaboost$namedLight(SingleQuadParticle self, float partialTick) { return pashaboost$light(partialTick); }

    @Redirect(method = {"render(Lcom/mojang/blaze3d/vertex/VertexConsumer;Lnet/minecraft/client/Camera;F)V",
            "m_5744_(Lcom/mojang/blaze3d/vertex/VertexConsumer;Lnet/minecraft/client/Camera;F)V"},
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/particle/SingleQuadParticle;m_6355_(F)I", remap = false),
            require = 0, remap = false)
    private int pashaboost$srgLight(SingleQuadParticle self, float partialTick) { return pashaboost$light(partialTick); }

    @Unique
    private int pashaboost$light(float partialTick) {
        if (!RuntimeTuning.ACTIVE || !RuntimeTuning.PARTICLE_LIGHT_CACHE) return getLightColor(partialTick);
        // The class check was a ClassValue lookup on every frame; a particle's class never changes, so ask once.
        byte kind = pashaboost$positional;
        if (kind == 0) pashaboost$positional = kind = ParticleLight.positional(getClass()) ? (byte) 1 : (byte) 2;
        if (kind != 1) return getLightColor(partialTick);
        // The very coordinates BlockPos.containing takes in Particle.getLightColor.
        int blockX = Mth.floor(x), blockY = Mth.floor(y), blockZ = Mth.floor(z);
        // The same block within the same client tick.
        long pos = BlockPos.asLong(blockX, blockY, blockZ);
        long tick = level.getGameTime();
        if (pos == pashaboost$lightPos && tick == pashaboost$lightTick) { OptimizationCounters.particleLightReused++; return pashaboost$lastLight; }
        long cached = SharedParticleLight.running() ? SharedParticleLight.probeFull(level, blockX, blockY, blockZ) : SharedParticleLight.SKIP;
        int light;
        if (cached >= 0) {
            OptimizationCounters.particleLightShared++;
            light = (int) cached;
        } else {
            light = getLightColor(partialTick);
            if (cached == SharedParticleLight.MISS) SharedParticleLight.storeFull(light);
        }
        pashaboost$lightPos = pos; pashaboost$lightTick = tick; pashaboost$lastLight = light;
        return light;
    }
}
