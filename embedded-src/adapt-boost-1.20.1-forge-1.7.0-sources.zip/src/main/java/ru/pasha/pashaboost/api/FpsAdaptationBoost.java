package ru.pasha.pashaboost.api;

/**
 * Optional runtime integration point for adaptation mods.
 * This flag never changes saved presets or loads optimization engines at runtime.
 * The client resets it on disconnect; integrations should release it when unequipped.
 */
public final class FpsAdaptationBoost {
    private static volatile boolean active;

    public static void setActive(boolean enabled) {
        active = enabled;
        if (!enabled) {
            ru.pasha.pashaboost.RuntimeTuning.ACTIVE = false;
            ru.pasha.pashaboost.RuntimeTuning.GLYPH_ACTIVE = false;
        }
    }
    public static boolean isActive() { return active; }

    private FpsAdaptationBoost() {}
}
