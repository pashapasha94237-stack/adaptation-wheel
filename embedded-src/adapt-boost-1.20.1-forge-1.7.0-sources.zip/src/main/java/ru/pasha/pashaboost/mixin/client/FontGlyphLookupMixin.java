package ru.pasha.pashaboost.mixin.client;

import com.mojang.blaze3d.font.GlyphInfo;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.font.FontSet;
import net.minecraft.client.gui.font.glyphs.BakedGlyph;
import net.minecraft.resources.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import ru.pasha.pashaboost.OptimizationCounters;
import ru.pasha.pashaboost.RuntimeTuning;
import ru.pasha.pashaboost.client.font.FontLookup;

/**
 * Per character, vanilla asks the Font for its FontSet (Function into FontManager's HashMap, plus any mod hooks on
 * getFontSet, each allocating a CallbackInfoReturnable) and asks FontSet for the glyph (allocating a lambda each time).
 * One StringRenderOutput is made per draw call (renderText, drawInBatch8xOutline), so it remembers the last font id.
 * Local slots and call order that other mods capture (Jade, Malum, Goety Revelation, chat_heads) are unchanged.
 * Idea from ImmediatelyFast's fast_text_lookup (LGPL-3.0), reimplemented; no code taken.
 */
// Each call has a development and a production name; require = 0 so a conflicting mod only disables this.
@Mixin(targets = "net.minecraft.client.gui.Font$StringRenderOutput", remap = false)
public abstract class FontGlyphLookupMixin {
    @Unique private ResourceLocation pashaboost$lastFontId;
    @Unique private FontSet pashaboost$lastFontSet;

    @Redirect(method = {"accept(ILnet/minecraft/network/chat/Style;I)Z", "m_6411_(ILnet/minecraft/network/chat/Style;I)Z"},
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/Font;getFontSet(Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/client/gui/font/FontSet;", remap = false),
            require = 0, remap = false)
    private FontSet pashaboost$namedFontSet(Font font, ResourceLocation id) { return pashaboost$memoFontSet(font, id); }

    @Redirect(method = {"accept(ILnet/minecraft/network/chat/Style;I)Z", "m_6411_(ILnet/minecraft/network/chat/Style;I)Z"},
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/Font;m_92863_(Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/client/gui/font/FontSet;", remap = false),
            require = 0, remap = false)
    private FontSet pashaboost$srgFontSet(Font font, ResourceLocation id) { return pashaboost$memoFontSet(font, id); }

    @Redirect(method = {"accept(ILnet/minecraft/network/chat/Style;I)Z", "m_6411_(ILnet/minecraft/network/chat/Style;I)Z"},
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/font/FontSet;getGlyphInfo(IZ)Lcom/mojang/blaze3d/font/GlyphInfo;", remap = false),
            require = 0, remap = false)
    private GlyphInfo pashaboost$namedGlyphInfo(FontSet set, int codepoint, boolean notFishy) { return FontLookup.glyphInfo(set, codepoint, notFishy); }

    @Redirect(method = {"accept(ILnet/minecraft/network/chat/Style;I)Z", "m_6411_(ILnet/minecraft/network/chat/Style;I)Z"},
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/font/FontSet;m_243128_(IZ)Lcom/mojang/blaze3d/font/GlyphInfo;", remap = false),
            require = 0, remap = false)
    private GlyphInfo pashaboost$srgGlyphInfo(FontSet set, int codepoint, boolean notFishy) { return FontLookup.glyphInfo(set, codepoint, notFishy); }

    @Redirect(method = {"accept(ILnet/minecraft/network/chat/Style;I)Z", "m_6411_(ILnet/minecraft/network/chat/Style;I)Z"},
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/font/FontSet;getGlyph(I)Lnet/minecraft/client/gui/font/glyphs/BakedGlyph;", remap = false),
            require = 0, remap = false)
    private BakedGlyph pashaboost$namedGlyph(FontSet set, int codepoint) { return FontLookup.glyph(set, codepoint); }

    @Redirect(method = {"accept(ILnet/minecraft/network/chat/Style;I)Z", "m_6411_(ILnet/minecraft/network/chat/Style;I)Z"},
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/font/FontSet;m_95078_(I)Lnet/minecraft/client/gui/font/glyphs/BakedGlyph;", remap = false),
            require = 0, remap = false)
    private BakedGlyph pashaboost$srgGlyph(FontSet set, int codepoint) { return FontLookup.glyph(set, codepoint); }

    /** this$0 is fixed per StringRenderOutput, so the id (identity) is the whole key; a miss runs the real getFontSet with all hooks. */
    @Unique
    private FontSet pashaboost$memoFontSet(Font font, ResourceLocation id) {
        FontSet set = pashaboost$lastFontSet;
        if (set != null && id == pashaboost$lastFontId && RuntimeTuning.ACTIVE && RuntimeTuning.GLYPH_LOOKUP_CACHE) {
            if (RenderSystem.isOnRenderThread()) OptimizationCounters.fontSetLookupsSaved++;
            return set;
        }
        set = FontLookup.fontSet(font, id);
        pashaboost$lastFontId = id;
        pashaboost$lastFontSet = set;
        return set;
    }
}
