package ru.pasha.pashaboost.client;

import java.lang.reflect.Field;
import java.util.Collection;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.NoRenderParticle;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleEngine;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.fml.util.ObfuscationReflectionHelper;
import ru.pasha.pashaboost.BoostConfig;
import ru.pasha.pashaboost.PashaBoost;
import ru.pasha.pashaboost.core.ParticleBudget;

/** Wraps existing factories without replacing the renderer or particle engine. */
public final class ParticleOptimizer {
    private static final Set<String> DECORATIVE = Set.of(
            "smoke", "large_smoke", "campfire_cosy_smoke", "campfire_signal_smoke",
            "ash", "white_ash", "spore_blossom_air", "falling_spore_blossom", "mycelium",
            "crimson_spore", "warped_spore", "dripping_water", "falling_water",
            "dripping_lava", "falling_lava", "landing_lava", "dripping_honey",
            "falling_honey", "landing_honey", "dripping_obsidian_tear", "falling_obsidian_tear",
            "landing_obsidian_tear", "snowflake", "enchant", "underwater", "splash", "rain");
    private static final ParticleBudget BUDGET = new ParticleBudget();
    private static Field providersField;
    private static Field particlesField;
    private static Field pendingField;
    private static boolean disabled;
    private static int installedCount;
    /** Stand-ins for rejected particles since the last tick: the engine still holds them, but they are not drawn. */
    private static int standIns;

    public static void install() {
        Minecraft mc = Minecraft.getInstance();
        if (!mc.isSameThread()) { mc.execute(ParticleOptimizer::install); return; }
        if (disabled || mc.particleEngine == null) return;
        try {
            if (providersField == null) {
                providersField = ObfuscationReflectionHelper.findField(ParticleEngine.class, "f_107293_");
                particlesField = ObfuscationReflectionHelper.findField(ParticleEngine.class, "f_107289_");
                pendingField = ObfuscationReflectionHelper.findField(ParticleEngine.class, "f_107294_");
            }
            @SuppressWarnings("unchecked")
            Map<ResourceLocation, ParticleProvider<?>> providers =
                    (Map<ResourceLocation, ParticleProvider<?>>) providersField.get(mc.particleEngine);
            installedCount = 0;
            for (Map.Entry<ResourceLocation, ParticleProvider<?>> entry : providers.entrySet()) {
                // Weather and other mods may retain a provider for an unregistered particle type.
                // Leave that factory native instead of disabling the whole particle component.
                if(entry.getKey()==null || entry.getValue()==null)continue;
                if (!(entry.getValue() instanceof BudgetedProvider<?>))
                    entry.setValue(wrap(entry.getKey(), entry.getValue()));
                installedCount++;
            }
        } catch (ReflectiveOperationException | RuntimeException error) {
            disable(error);
        }
    }

    private static <T extends ParticleOptions> ParticleProvider<T> wrap(ResourceLocation id, ParticleProvider<T> provider) {
        return new BudgetedProvider<>(id, provider);
    }

    public static void tick() {
        int handedOut = standIns;
        standIns = 0;
        if (!RenderSettings.active()) return;
        Minecraft mc = Minecraft.getInstance();
        if (!mc.isSameThread() || disabled || particlesField == null || mc.particleEngine == null) return;
        try {
            Object layers = particlesField.get(mc.particleEngine);
            Object pending = pendingField.get(mc.particleEngine);
            if (!(layers instanceof Map<?, ?> map) || !(pending instanceof Collection<?> queue))
                throw new IllegalStateException("Unexpected particle engine collections");
            // Counting the stand-ins would make a burst of rejections reject the next tick's particles too.
            long count = (long) queue.size() - handedOut;
            for (Object value : map.values()) {
                if (!(value instanceof Collection<?> collection))
                    throw new IllegalStateException("Unexpected particle layer collection");
                count += collection.size();
            }
            double scale = BoostClient.particleScale();
            var settings=RenderSettings.current();
            BUDGET.beginTick((int) Math.max(0, Math.min(Integer.MAX_VALUE, count)),
                    Math.max(1, (int) (settings.particleLimit() * scale)),
                    Math.max(1, (int) (settings.particlesPerTick() * scale)));
        } catch (ReflectiveOperationException | RuntimeException error) {
            disable(error);
        }
    }

    private static void disable(Exception error) {
        if (!disabled) PashaBoost.LOGGER.warn("Particle filtering disabled: incompatible particle engine access. Other optimizations remain active.", error);
        disabled = true;
        installedCount = 0;
    }

    public static void clear() {
        if (Minecraft.getInstance().isSameThread()) { BUDGET.clear(); standIns = 0; }
    }
    public static long rejectedCount() { return BUDGET.rejectedCount(); }
    public static int activeCount() { return BUDGET.estimatedActive(); }
    public static int installedCount() { return installedCount; }
    public static boolean isInstalled() { return !disabled && installedCount > 0; }

    private static final class BudgetedProvider<T extends ParticleOptions> implements ParticleProvider<T> {
        private final ParticleProvider<T> original;
        private final boolean vanilla;
        private final boolean decorative;

        private BudgetedProvider(ResourceLocation id, ParticleProvider<T> original) {
            this.original = original;
            vanilla = id.getNamespace().equals("minecraft");
            decorative = vanilla && DECORATIVE.contains(id.getPath());
        }

        @Override
        public Particle createParticle(T options, ClientLevel level, double x, double y, double z,
                                       double xSpeed, double ySpeed, double zSpeed) {
            if(disabled||!RenderSettings.active())return original.createParticle(options, level, x, y, z, xSpeed, ySpeed, zSpeed);
            Minecraft mc = Minecraft.getInstance();
            // Misbehaving asynchronous callers retain their original provider behavior.
            if (!mc.isSameThread()) return original.createParticle(options, level, x, y, z, xSpeed, ySpeed, zSpeed);
            var settings=RenderSettings.current();
            boolean filter = mc.level != null && mc.getCameraEntity() != null
                    && settings.particles()
                    && !options.getType().getOverrideLimiter()
                    && (decorative || (!vanilla && settings.modParticles()));
            if (!filter) {
                Particle particle = original.createParticle(options, level, x, y, z, xSpeed, ySpeed, zSpeed);
                if (particle != null) BUDGET.observeUnfilteredAllocation();
                return particle;
            }
            Vec3 camera = mc.gameRenderer.getMainCamera().getPosition();
            double dx = x - camera.x, dy = y - camera.y, dz = z - camera.z;
            if (!BUDGET.tryAcquire(dx * dx + dy * dy + dz * dz, settings.particleDistanceSquared()))
                return vanilla ? new Rejected(level, x, y, z) : null;
            Particle particle;
            try {
                particle = original.createParticle(options, level, x, y, z, xSpeed, ySpeed, zSpeed);
            } catch (RuntimeException | Error failure) {
                BUDGET.releaseReservation();
                throw failure;
            }
            if (particle == null) BUDGET.releaseReservation();
            return particle;
        }
    }

    /**
     * Stands in for a rejected vanilla particle. OptiFine recolours splash, rain and bubble particles right after
     * creating them without a null check, so a null result crashed the game in water. It is never drawn and leaves
     * the engine on its first tick. Mod particles keep the null result: a mod may cast what it gets.
     */
    private static final class Rejected extends NoRenderParticle {
        Rejected(ClientLevel level, double x, double y, double z) { super(level, x, y, z); remove(); standIns++; }
        @Override public void tick() {}
    }

    private ParticleOptimizer() {}
}
