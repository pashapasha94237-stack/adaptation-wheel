package ru.pasha.pashaboost;

import java.util.concurrent.atomic.AtomicLong;

/** Counts actual operations; estimated bytes are not a measured reduction in total heap. */
public final class OptimizationCounters {
    public static final AtomicLong GLYPHS_COMPACTED = new AtomicLong();
    public static final AtomicLong ESTIMATED_GLYPH_BYTES_SAVED = new AtomicLong();
    public static final AtomicLong EXTRA_NBT_WRITES = new AtomicLong();
    // Render-thread counters: plain fields are enough, they are only read for the HUD and tests.
    public static long shaderLookupsSaved, biomeLookupsSaved, particleLightReused, blockEntitiesCulled, distantLightmapUploadsSkipped,
            entityTicksSkipped, particleVectorsReused, particleRotationsReused, idleFramesCapped,
            // 1.7
            brandonsBoundsSkipped, brandonsSectionWalksSkipped, mahouEntitySetsAvoided, signTextSidesCulled, signTextEmptySidesSkipped,
            glyphLookupsFast, fontSetLookupsSaved, cloudRainWalksSkippedClient, entityVerdictsReused, samplerNamesReused;
    // 1.7, OptiFine scene. OptiFine I6 model cubes written in one call, plain and through a SpriteCoordinateExpander, and fallbacks after a throw;
    // shared particle light table hits and computed lookups; OptiFine entity-section memo hits; reused model quaternions.
    public static long modelCubesDirect, modelSpriteCubesDirect, modelCubeFallbacks, particleLightShared, particleLightComputed,
            entitySectionMemoHits, modelQuaternionsReused;
    /** Once per vertex format, ever (builders on chunk threads too). */
    public static final AtomicLong VERTEX_ELEMENT_ARRAYS_BUILT = new AtomicLong();
    /** Sorted batches done on primitive arrays / batches that went to vanilla's sort after the fast path had started or been offered (any thread). */
    public static final AtomicLong quadSortsFast = new AtomicLong(), quadSortsFallback = new AtomicLong();
    /** Set once; entity data is read on two threads, so nothing is counted per call. */
    public static volatile boolean entityDataUnlockedSeen;
    // Server thread.
    public static long xpOrbsMerged, cloudRainWalksSkipped, pupfishTriesDeferred, pupfishColumnsReused, pupfishResultsMarkedDirty;
    private OptimizationCounters() {}
}
