package ru.pasha.pashaboost.mixin.client;

import com.mojang.blaze3d.font.GlyphInfo;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.font.FontSet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import ru.pasha.pashaboost.client.font.FontLookup;

/**
 * The width provider (Font constructor lambda, used by every Font.width/split) and the glow-outline lambda
 * (8 passes per glowing line within 16 blocks) do the same allocating getGlyphInfo per character.
 */
@Mixin(value = Font.class, remap = false)
public abstract class FontWidthLookupMixin {
    @Redirect(method = {"lambda$new$0(ILnet/minecraft/network/chat/Style;)F", "m_243025_(ILnet/minecraft/network/chat/Style;)F",
            "lambda$drawInBatch8xOutline$1(Lnet/minecraft/client/gui/Font$StringRenderOutput;[FIFIIILnet/minecraft/network/chat/Style;I)Z",
            "m_168654_(Lnet/minecraft/client/gui/Font$StringRenderOutput;[FIFIIILnet/minecraft/network/chat/Style;I)Z"},
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/font/FontSet;getGlyphInfo(IZ)Lcom/mojang/blaze3d/font/GlyphInfo;", remap = false),
            require = 0, remap = false)
    private GlyphInfo pashaboost$namedGlyphInfo(FontSet set, int codepoint, boolean notFishy) { return FontLookup.glyphInfo(set, codepoint, notFishy); }

    @Redirect(method = {"lambda$new$0(ILnet/minecraft/network/chat/Style;)F", "m_243025_(ILnet/minecraft/network/chat/Style;)F",
            "lambda$drawInBatch8xOutline$1(Lnet/minecraft/client/gui/Font$StringRenderOutput;[FIFIIILnet/minecraft/network/chat/Style;I)Z",
            "m_168654_(Lnet/minecraft/client/gui/Font$StringRenderOutput;[FIFIIILnet/minecraft/network/chat/Style;I)Z"},
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/font/FontSet;m_243128_(IZ)Lcom/mojang/blaze3d/font/GlyphInfo;", remap = false),
            require = 0, remap = false)
    private GlyphInfo pashaboost$srgGlyphInfo(FontSet set, int codepoint, boolean notFishy) { return FontLookup.glyphInfo(set, codepoint, notFishy); }
}
