package ru.pasha.pashaboost.mixin.client;

import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.culling.Frustum;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.pasha.pashaboost.OptimizationCounters;
import ru.pasha.pashaboost.RuntimeTuning;
import ru.pasha.pashaboost.client.EntitySectionMemo;

/**
 * OptiFine's shouldRenderEntity(Entity,int,int) asks renderInfosEntities.contains(section key) once per entity per frame
 * (3.04 % self of the render thread in JFR, a random probe into a large table). Entities come in insertion order, so
 * the previous answer is usually the one needed. The set changes only in applyFrustumEntities and clearRenderInfosEntities
 * and is swapped in setShadowRenderInfos (javap of the patched LevelRenderer); those three bump an epoch first.
 * The method exists only under OptiFine, so the plugin applies this mixin only there. No shadows: only a redirect and
 * three HEAD injects, all require = 0.
 */
@Mixin(value = LevelRenderer.class, remap = false)
public abstract class EntitySectionMemoMixin {
    @Unique private final EntitySectionMemo pashaboost$memo = new EntitySectionMemo();

    // Epoch bumps are bookkeeping and never gated by flags: otherwise switching off, letting the set change and switching
    // on could return a stale answer for the same set object.
    @Inject(method = "applyFrustumEntities(Lnet/minecraft/client/renderer/culling/Frustum;I)V", at = @At("HEAD"), require = 0, remap = false)
    private void pashaboost$epochApply(Frustum frustum, int frame, CallbackInfo ci) { pashaboost$memo.bump(); }

    @Inject(method = "clearRenderInfosEntities()V", at = @At("HEAD"), require = 0, remap = false)
    private void pashaboost$epochClear(CallbackInfo ci) { pashaboost$memo.bump(); }

    @Inject(method = "setShadowRenderInfos(Z)V", at = @At("HEAD"), require = 0, remap = false)
    private void pashaboost$epochShadow(boolean shadow, CallbackInfo ci) { pashaboost$memo.bump(); }

    @Redirect(method = "shouldRenderEntity(Lnet/minecraft/world/entity/Entity;II)Z",
            at = @At(value = "INVOKE", target = "Lit/unimi/dsi/fastutil/longs/LongOpenHashSet;contains(J)Z", remap = false),
            require = 0, remap = false)
    private boolean pashaboost$memoContains(LongOpenHashSet set, long key) {
        if (!RuntimeTuning.ACTIVE || !RuntimeTuning.ENTITY_SECTION_MEMO) return set.contains(key);
        int hit = pashaboost$memo.peek(set, key);
        if (hit >= 0) {
            OptimizationCounters.entitySectionMemoHits++;
            return hit == 1;
        }
        boolean value = set.contains(key);
        pashaboost$memo.store(set, key, value);
        return value;
    }
}
