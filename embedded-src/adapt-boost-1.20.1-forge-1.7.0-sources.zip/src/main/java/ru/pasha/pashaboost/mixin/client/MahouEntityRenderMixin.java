package ru.pasha.pashaboost.mixin.client;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import ru.pasha.pashaboost.client.MahouEntityScan;

import java.util.HashSet;

/** Mahou Tsukai copied every client entity into two HashSets each frame only to draw its own spell entities; see MahouEntityScan. */
// Mahou's own names are the same in development and production (javap, mahoutsukai-1.20.1-v1.34.81.jar); require = 0 so a
// conflicting mod only disables this. Applied only next to a checked Mahou version (BoostMixinPlugin). RenderUtils is not
// patched by OptiFine.
@Pseudo
@Mixin(targets = "stepsword.mahoutsukai.render.RenderUtils", remap = false)
public abstract class MahouEntityRenderMixin {
    @Redirect(method = "entityRenders(Lnet/minecraft/world/entity/Entity;Lcom/mojang/blaze3d/vertex/PoseStack;F)V",
            at = @At(value = "INVOKE",
                    target = "Lstepsword/mahoutsukai/proxy/ClientProxy;getAllEntities(Lnet/minecraft/client/multiplayer/ClientLevel;)Ljava/util/HashSet;",
                    remap = false),
            require = 0, remap = false)
    private static HashSet<Entity> pashaboost$drawnOnly(ClientLevel level) {
        return MahouEntityScan.drawnEntities(level);
    }
}
