package ru.pasha.pashaboost.mixin;

import net.minecraftforge.fml.loading.FMLLoader;
import net.minecraftforge.fml.loading.FMLPaths;
import ru.pasha.pashaboost.memory.MemoryGate;
import org.objectweb.asm.tree.ClassNode;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Decide before touching target bytecode; do not stack replacements of the same engine. */
public final class BoostMixinPlugin implements IMixinConfigPlugin {
    private final Set<String> mods=new HashSet<>();
    private final Map<String,String> versions=new HashMap<>();
    private boolean memoryEarned, optiFine;
    /** Strictly OptiFine 1.20.1 HD U I6 pre6: the only build whose members the Of* mixins were checked against. */
    private boolean optiFineI6;
    @Override public void onLoad(String mixinPackage) {
        var list=FMLLoader.getLoadingModList();
        if(list!=null) for(var mod:list.getMods()) { mods.add(mod.getModId()); versions.put(mod.getModId(),mod.getVersion().toString()); }
        try { memoryEarned=MemoryGate.earned(FMLPaths.CONFIGDIR.get().resolve("pashaboost-client.toml")); }
        catch(RuntimeException e) { memoryEarned=false; }
        optiFine=optiFineService();
        optiFineI6=optiFineI6();
    }
    /**
     * Mixins that shadow OptiFine-only members crash the game when a shadow is missing, whatever require says, so they take
     * no heuristics: the service class, an I6 class, and the exact version string inside Config.class. Another build only
     * switches them off until its bytecode is checked.
     */
    private static boolean optiFineI6() {
        for(ClassLoader loader:new ClassLoader[]{BoostMixinPlugin.class.getClassLoader(),Thread.currentThread().getContextClassLoader()}) {
            if(loader==null) continue;
            try {
                if(loader.getResource("optifine/OptiFineTransformationService.class")==null || loader.getResource("net/optifine/render/VertexPosition.class")==null) continue;
                try(java.io.InputStream in=loader.getResourceAsStream("net/optifine/Config.class")) {
                    if(in!=null && ru.pasha.pashaboost.client.ModelDirectGate.containsAscii(in.readAllBytes(),"1.20.1_HD_U_I6_pre6")) return true;
                }
            } catch(java.io.IOException|RuntimeException ignored) {}
        }
        return false;
    }
    /** OptiFine is a ModLauncher transformation service, not a Forge mod, and its classes are not loaded yet. */
    private static boolean optiFineService() {
        // A resource lookup defines no class at all.
        for(ClassLoader loader:new ClassLoader[]{BoostMixinPlugin.class.getClassLoader(),Thread.currentThread().getContextClassLoader()}) {
            try { if(loader!=null && loader.getResource("optifine/OptiFineTransformationService.class")!=null) return true; }
            catch(RuntimeException ignored) {}
        }
        try {
            var list=cpw.mods.modlauncher.Launcher.INSTANCE.environment().getProperty(cpw.mods.modlauncher.api.IEnvironment.Keys.MODLIST.get());
            if(list.isPresent()) for(Map<String,String> entry:list.get()) if("OptiFine".equalsIgnoreCase(entry.get("name"))) return true;
        } catch(RuntimeException|LinkageError ignored) {}
        for(String name:new String[]{"optifine.OptiFineTransformationService","net.optifine.Config"}) {
            try { Class.forName(name,false,BoostMixinPlugin.class.getClassLoader()); return true; }
            catch(ClassNotFoundException|LinkageError absent) {}
        }
        // An OptiFine jar in mods/: a false positive only switches features off.
        try(java.util.stream.Stream<java.nio.file.Path> files=java.nio.file.Files.list(FMLPaths.MODSDIR.get())) {
            return files.anyMatch(p -> { String n=p.getFileName().toString().toLowerCase(java.util.Locale.ROOT); return n.contains("optifine") && n.endsWith(".jar"); });
        } catch(java.io.IOException|RuntimeException e) { return false; }
    }
    private boolean hasAny(String... ids) {
        for(String id:ids) if(mods.contains(id)) return true;
        return false;
    }
    private String version(String id) { return versions.getOrDefault(id,""); }
    @Override public boolean shouldApplyMixin(String targetClassName,String mixinClassName) {
        if(mixinClassName.endsWith("LightChunkLookupMixin"))
            return !Boolean.getBoolean("pashaboost.disableLightCache") && !hasAny("starlight","radon","phosphor","c2me","c2meforge");
        if(mixinClassName.endsWith("IOWorkerDrainMixin"))
            return !Boolean.getBoolean("pashaboost.disableWriteDrain") && !hasAny("c2me","c2meforge","modernfix");
        if(mixinClassName.endsWith("DistantLightmapMixin"))
            return hasAny("distanthorizons");
        if(mixinClassName.endsWith("XpOrbMergeMixin"))
            return !hasAny("clumps");
        // Launch-time memory savings ported from FerriteCore: earned only, and never next to FerriteCore itself.
        if(mixinClassName.endsWith("MemoryMixin") || mixinClassName.endsWith("MultiPartSelectorSyncMixin")) {
            boolean apply=memoryEarned && !Boolean.getBoolean("pashaboost.disableMemorySavings") && !hasAny("ferritecore");
            // Lithium-family mods replace the state neighbour tables themselves.
            if(mixinClassName.endsWith("StateHolderMemoryMixin")) MemoryGate.applied=apply&=!hasAny("canary","lithium","radium");
            return apply;
        }
        if(mixinClassName.endsWith("UnihexGlyphMixin"))
            return !Boolean.getBoolean("pashaboost.disableGlyphCompaction") && !hasAny("modernfix");
        // 1.7: mod hotspots, each only next to the versions whose bytecode was checked.
        if(mixinClassName.endsWith("PupfishSearchMixin"))
            return !Boolean.getBoolean("pashaboost.disablePupfishSearch") && Set.of("1.22.8","1.22.9").contains(version("alexsmobs"));
        // Serene Seasons cancels Level.isRainingAt before the cloud walk, so there would be nothing to save.
        if(mixinClassName.endsWith("TwilightCloudRainMixin"))
            return !Boolean.getBoolean("pashaboost.disableCloudRainShortcut") && version("twilightforest").equals("4.3.2508") && !hasAny("sereneseasons");
        if(mixinClassName.endsWith("BrandonsTransparentPassMixin"))
            return !Boolean.getBoolean("pashaboost.disableBrandonsPass") && version("brandonscore").startsWith("3.2.");
        // The Sodium family rebuilds sections its own way. OptiFine keeps vanilla's RebuildTask -> CompiledChunk funnel for
        // block entities (handleBlockEntity and the compiled list are byte-for-byte vanilla in I6), so the proof holds there.
        if(mixinClassName.endsWith("SectionListRecorderMixin"))
            return !Boolean.getBoolean("pashaboost.disableBrandonsSectionSkip") && version("brandonscore").startsWith("3.2.")
                    && !hasAny("embeddium","rubidium","magnesium","sodium","xenon","celeritas");
        if(mixinClassName.endsWith("MahouEntityRenderMixin"))
            return !Boolean.getBoolean("pashaboost.disableMahouEntityScan")
                    && (version("mahoutsukai").equals("1.20.1-v1.34.81") || Boolean.getBoolean("pashaboost.mahouEntityScanAnyVersion"));
        // These mods draw signs their own way. OptiFine's renderSignText only adds a distance gate before the first pushPose,
        // which is where the cull runs.
        if(mixinClassName.endsWith("SignTextCullMixin"))
            return !Boolean.getBoolean("pashaboost.disableSignTextCulling") && !hasAny("oculus","vivecraft");
        // OptiFine's FontSet and StringRenderOutput already do both lookups this way, so there is nothing left to save.
        if(mixinClassName.endsWith("FontGlyphLookupMixin") || mixinClassName.endsWith("FontWidthLookupMixin"))
            return !Boolean.getBoolean("pashaboost.disableGlyphLookupCache") && !optiFine && !hasAny("immediatelyfast","modernui","emojiful");
        // OptiFine sets samplers through its own setSampler(int) path and patches SynchedEntityData; the others replace the
        // same code themselves. OptiFine's BufferBuilder.nextElement is instruction for instruction vanilla's, so the
        // element array applies there too (about 6 % of its render thread, mostly particles).
        if(mixinClassName.endsWith("SamplerNameMixin"))
            return !Boolean.getBoolean("pashaboost.disableSamplerNames") && !optiFine
                    && !hasAny("embeddium","rubidium","sodium","oculus","iris","immediatelyfast");
        if(mixinClassName.endsWith("VertexElementMixin"))
            return !Boolean.getBoolean("pashaboost.disableVertexElementArray")
                    && !hasAny("embeddium","rubidium","sodium","oculus","iris","immediatelyfast");
        if(mixinClassName.endsWith("EntityDataLockMixin"))
            return !Boolean.getBoolean("pashaboost.disableEntityDataLockElision") && !optiFine && !hasAny("lithium","canary","radium");
        // 1.7, OptiFine scene. OptiFine I6 model cubes: they shadow OptiFine-only members, so only the strict check (never the mods-folder guess).
        if(mixinClassName.endsWith("OfCubeDirectMixin") || mixinClassName.endsWith("OfCubeWriterMixin") || mixinClassName.endsWith("OfModelVertexMixin"))
            return optiFineI6 && !Boolean.getBoolean("pashaboost.disableModelDirect") && !hasAny("embeddium","rubidium","sodium","oculus","iris","immediatelyfast");
        if(mixinClassName.endsWith("OfSpriteExpanderMixin"))
            return optiFineI6 && !Boolean.getBoolean("pashaboost.disableModelDirect") && !Boolean.getBoolean("pashaboost.disableModelDirectSprite")
                    && !hasAny("embeddium","rubidium","sodium","oculus","iris","immediatelyfast");
        // Shared particle light (the six ParticleLight*Mixin). Light-engine replacements own the visible light maps that the
        // revision watches; dynamic-light mods add light inside LevelRenderer.getLightColor that no revision sees.
        if(mixinClassName.contains(".client.ParticleLight")) {
            ru.pasha.pashaboost.core.ParticleLightShare.optiFine=optiFine;
            return !Boolean.getBoolean("pashaboost.disableParticleLightShare") && !hasAny("starlight","scalablelux","moonrise","radon","phosphor",
                    "lambdynlights","dynamiclightsreforged","ryoamiclights","sodiumdynamiclights","lucent","embeddiumplus");
        }
        // The Sodium family and ImmediatelyFast replace BufferBuilder's quad sort. OptiFine's is vanilla's apart from the
        // quadSprites tail, which the mixin hands back to vanilla.
        if(mixinClassName.endsWith("QuadSortMixin"))
            return !Boolean.getBoolean("pashaboost.disableQuadSort")
                    && !hasAny("embeddium","rubidium","sodium","magnesium","xenon","celeritas","immediatelyfast","oculus","iris");
        // shouldRenderEntity exists only in OptiFine. The memo is exact only while renderInfosEntities changes in exactly the
        // three methods it hooks, which was checked on I6_pre6 bytecode, so only the strict check (never the mods-folder guess).
        if(mixinClassName.endsWith("EntitySectionMemoMixin"))
            return !Boolean.getBoolean("pashaboost.disableEntitySectionMemo") && optiFineI6;
        if(mixinClassName.endsWith("ModelPartQuaternionMixin"))
            return !Boolean.getBoolean("pashaboost.disableModelQuaternionReuse");
        return true;
    }
    @Override public String getRefMapperConfig() { return null; }
    @Override public void acceptTargets(Set<String> myTargets,Set<String> otherTargets) {
        // The glyph fast path reads FontSet's tables directly, which would skip another mod's FontSet hooks.
        if(otherTargets.contains("net.minecraft.client.gui.font.FontSet") || otherTargets.contains("net/minecraft/client/gui/font/FontSet"))
            ru.pasha.pashaboost.client.font.FontCompat.foreignFontSetMixins=true;
    }
    @Override public List<String> getMixins() { return null; }
    @Override public void preApply(String targetClassName,ClassNode targetClass,String mixinClassName,IMixinInfo info) {}
    // Runs after every config's mixins for the class. The helpers it calls use only ASM and the JDK, because the target
    // class is still being transformed.
    @Override public void postApply(String targetClassName,ClassNode targetClass,String mixinClassName,IMixinInfo info) {
        // The model fast path stays off if another mod changed what it bypasses.
        if(mixinClassName.contains(".client.Of")) ru.pasha.pashaboost.client.ModelDirectGate.audit(mixinClassName,targetClass);
        // Shared particle light: record which hooks really landed (require = 0 may skip one); reuse needs all of them.
        if(mixinClassName.contains(".client.ParticleLight")) {
            int bits=0;
            for(org.objectweb.asm.tree.MethodNode method:targetClass.methods)
                for(org.objectweb.asm.tree.AbstractInsnNode insn:method.instructions)
                    if(insn instanceof org.objectweb.asm.tree.MethodInsnNode call && call.owner.equals(targetClass.name))
                        bits|=ru.pasha.pashaboost.core.ParticleLightShare.hookBit(call.name);
            ru.pasha.pashaboost.core.ParticleLightShare.recordHooks(bits);
        }
        // The quad-sort handlers resolve each other's state, so its fast path opens only when all three were merged.
        if(mixinClassName.endsWith("QuadSortMixin")) {
            try { ru.pasha.pashaboost.client.QuadSortGate.READY=ru.pasha.pashaboost.client.QuadSortGate.installed(targetClass); }
            catch(RuntimeException|LinkageError e) {}
        }
    }
}
