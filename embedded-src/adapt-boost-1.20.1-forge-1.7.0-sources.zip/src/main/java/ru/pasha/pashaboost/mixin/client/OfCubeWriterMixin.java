package ru.pasha.pashaboost.mixin.client;

import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferVertexConsumer;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import org.joml.Matrix3f;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import ru.pasha.pashaboost.client.CubeShape;
import ru.pasha.pashaboost.client.OfCubeWriter;
import ru.pasha.pashaboost.client.OfModelVertex;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;

/**
 * The write half of the OptiFine cube fast path (OfCubeDirectMixin): one call per cube runs, for each of its vertices, the
 * body of OptiFine I6's BufferBuilder.addVertexFast. JFR on the OptiFine scene: Cube.compile about 14 % of the render thread,
 * with addVertexFast a separate compiled frame behind an interface call per vertex.
 */
// OptiFine I6 only: floatBuffer, intBuffer and canAddVertexFast exist only in OptiFine's BufferBuilder. Fields by production
// name with the development name as alias (all private; an exact match is never checked).
@Mixin(value = BufferBuilder.class, remap = false)
public abstract class OfCubeWriterMixin implements OfCubeWriter {
    @Shadow(aliases = {"nextElementByte"}, remap = false) private int f_85652_;
    @Shadow(aliases = {"vertices"}, remap = false) private int f_85654_;
    @Shadow(aliases = {"format"}, remap = false) private VertexFormat f_85658_;
    @Shadow(remap = false) private FloatBuffer floatBuffer;
    @Shadow(remap = false) private IntBuffer intBuffer;

    @Shadow(aliases = {"ensureCapacity"}, remap = false)
    private void m_85722_(int size) { throw new AssertionError(); }

    @Shadow(remap = false)
    public abstract boolean canAddVertexFast();

    @Override
    public boolean pashaboost$canAddVertexFast() { return this.canAddVertexFast(); }

    @Override
    public boolean pashaboost$emitCube(CubeShape shape, Matrix3f n, int color, int overlay, int light, TextureAtlasSprite sprite) {
        int startByte = this.f_85652_, startVertices = this.f_85654_;
        try {
            Object[][] polygons = shape.vertices;
            Vector3f[] normals = shape.normals;
            for (int i = 0; i < polygons.length; i++) {
                Object[] vertices = polygons[i];
                if (vertices == null) continue; // an empty slot, skipped by compile at bytecode 95-100
                Vector3f nv = normals[i];
                float nx = CubeShape.transform(n.m00, n.m10, n.m20, nv.x, nv.y, nv.z);
                float ny = CubeShape.transform(n.m01, n.m11, n.m21, nv.x, nv.y, nv.z);
                float nz = CubeShape.transform(n.m02, n.m12, n.m22, nv.x, nv.y, nv.z);
                int normal = CubeShape.packNormal(BufferVertexConsumer.normalIntValue(nx), BufferVertexConsumer.normalIntValue(ny),
                        BufferVertexConsumer.normalIntValue(nz));
                for (Object element : vertices) {
                    OfModelVertex vertex = (OfModelVertex) element;
                    Vector3f pos = vertex.pashaboost$renderPositions().getPositionRender();
                    float u = vertex.pashaboost$u(), v = vertex.pashaboost$v();
                    if (sprite != null) {
                        // SpriteCoordinateExpander.addVertexFast: getU, then getV, each of (double) (uv * 16).
                        u = sprite.getU((double) (u * 16.0F));
                        v = sprite.getV((double) (v * 16.0F));
                    }
                    // addVertexFast: the stores, position and count, then ensureCapacity, which re-creates both views when it
                    // grows the buffer, so they are read again for every vertex.
                    CubeShape.putVertex(this.floatBuffer, this.intBuffer, this.f_85652_ / 4, pos.x, pos.y, pos.z, color, u, v,
                            overlay, light, normal);
                    this.f_85652_ += this.f_85658_.getVertexSize();
                    this.f_85654_++;
                    this.m_85722_(this.f_85658_.getVertexSize());
                    // Its last step, SVertexBuilder.endAddVertex, runs only with shaders, which the caller has ruled out.
                }
            }
            return true;
        } catch (RuntimeException unexpected) {
            // OptiFine's own code then writes the cube from the same position and meets the same problem itself.
            this.f_85652_ = startByte;
            this.f_85654_ = startVertices;
            return false;
        }
    }
}
