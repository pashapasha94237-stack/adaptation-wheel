package ru.pasha.pashaboost.client;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.event.RenderLivingEvent;
import ru.pasha.pashaboost.BoostConfig;
import ru.pasha.pashaboost.core.VisibilityCache;

public final class EntityOptimizer {
    private static final VisibilityCache CACHE = new VisibilityCache(2048);
    private static int wallChecks;
    private static long tested, culled,earlyCulled;

    public static void tick() { wallChecks = 0; pruneVerdicts(); }
    public static void clear() { CACHE.clear(); VERDICTS.clear(); wallChecks=0; tested=culled=earlyCulled=0; }
    public static long culledCount() { return culled; }
    public static long testedCount() { return tested; }
    public static long earlyCulledCount(){return earlyCulled;}

    /** Called only after the native frustum says visible, before model/layer setup. */
    public static boolean cullBeforeRender(Entity entity,double cameraX,double cameraY,double cameraZ){
        if(!RenderSettings.active()||!RenderSettings.current().entities()||!(entity instanceof LivingEntity living))return false;
        if(entity.distanceToSqr(cameraX,cameraY,cameraZ)<=RenderSettings.current().entityDistanceSquared())return false;
        Minecraft mc=Minecraft.getInstance();
        if(mc.level==null||mc.player==null||!ordinary(mc,living))return false;
        tested++;culled++;earlyCulled++;return true;
    }
    /**
     * Ordinary mobs too far away to be drawn tick on the client only every fourth game tick (the server is untouched).
     * The margin past the drawing distance lets a mob return to full rate before it becomes visible again.
     */
    public static boolean skipClientTick(Entity entity){
        if(!ru.pasha.pashaboost.RuntimeTuning.ENTITY_TICK_THROTTLE||!RenderSettings.active()||!RenderSettings.current().entities()
                ||!(entity instanceof LivingEntity living)||((entity.level().getGameTime()+entity.getId())&3)==0)return false;
        Minecraft mc=Minecraft.getInstance();
        Entity viewer=mc.getCameraEntity();
        if(viewer==null||entity.distanceToSqr(viewer)<=RenderSettings.current().entityDistanceSquared()*1.5625)return false;
        if(living.hurtTime>0||living.deathTime>0||!ordinary(mc,living))return false;
        ru.pasha.pashaboost.OptimizationCounters.entityTicksSkipped++;
        return true;
    }
    private static boolean ordinary(Minecraft mc,LivingEntity entity){
        if(mc.getEntityRenderDispatcher().shouldRenderHitBoxes()||entity instanceof Player||entity.isPassenger()||entity.isVehicle()
                ||entity.getBbWidth()>3||entity.getBbHeight()>5)return false;
        // 1.7: name, max health (an attribute map lookup), glow and leash change rarely; reuse the answer for a second.
        // A hurt or glowing mob (bell, spectral arrow) or the crosshair target is always checked fresh.
        if(!ru.pasha.pashaboost.RuntimeTuning.ENTITY_VERDICT_CACHE||entity.hurtTime>0||entity.isCurrentlyGlowing()||mc.crosshairPickEntity==entity)
            return rareChecks(mc,entity);
        long now=entity.level().getGameTime();
        long cached=VERDICTS.get(entity.getId());
        if(cached!=Long.MIN_VALUE&&now-(cached>>1)<VERDICT_TICKS&&now>=(cached>>1)){
            ru.pasha.pashaboost.OptimizationCounters.entityVerdictsReused++;
            return (cached&1)!=0;
        }
        boolean ordinary=rareChecks(mc,entity);
        VERDICTS.put(entity.getId(),now<<1|(ordinary?1:0));
        return ordinary;
    }
    private static boolean rareChecks(Minecraft mc,LivingEntity entity){
        return !entity.hasCustomName()&&entity.getMaxHealth()<100
                &&!mc.shouldEntityAppearGlowing(entity)&&(!(entity instanceof Mob mob)||mob.getLeashHolder()==null);
    }
    private static final int VERDICT_TICKS=20;
    /** Entity id -> (game time << 1) | ordinary. Render thread only (client ticks run there too). */
    private static final it.unimi.dsi.fastutil.ints.Int2LongOpenHashMap VERDICTS=new it.unimi.dsi.fastutil.ints.Int2LongOpenHashMap();
    static { VERDICTS.defaultReturnValue(Long.MIN_VALUE); }
    private static int ticksSincePrune;
    /** Ids of entities that are gone would otherwise pile up. */
    private static void pruneVerdicts(){
        if(++ticksSincePrune<1200)return;
        ticksSincePrune=0;
        Minecraft mc=Minecraft.getInstance();
        long now=mc.level==null?0:mc.level.getGameTime();
        VERDICTS.int2LongEntrySet().removeIf(e->now-(e.getLongValue()>>1)>=VERDICT_TICKS||now<(e.getLongValue()>>1));
    }

    /** Vanilla decorative block entities only; beacons, portals, pistons and mod machines keep their own distance. */
    private static final java.util.Set<net.minecraft.world.level.block.entity.BlockEntityType<?>> DECORATIVE_BLOCK_ENTITIES;
    static {
        var types=java.util.Collections.newSetFromMap(new java.util.IdentityHashMap<net.minecraft.world.level.block.entity.BlockEntityType<?>,Boolean>());
        java.util.Collections.addAll(types,net.minecraft.world.level.block.entity.BlockEntityType.CHEST,net.minecraft.world.level.block.entity.BlockEntityType.TRAPPED_CHEST,
                net.minecraft.world.level.block.entity.BlockEntityType.ENDER_CHEST,net.minecraft.world.level.block.entity.BlockEntityType.SIGN,
                net.minecraft.world.level.block.entity.BlockEntityType.HANGING_SIGN,net.minecraft.world.level.block.entity.BlockEntityType.BANNER,
                net.minecraft.world.level.block.entity.BlockEntityType.SKULL,net.minecraft.world.level.block.entity.BlockEntityType.BED,
                net.minecraft.world.level.block.entity.BlockEntityType.SHULKER_BOX,net.minecraft.world.level.block.entity.BlockEntityType.DECORATED_POT,
                net.minecraft.world.level.block.entity.BlockEntityType.LECTERN,net.minecraft.world.level.block.entity.BlockEntityType.ENCHANTING_TABLE,
                net.minecraft.world.level.block.entity.BlockEntityType.CAMPFIRE,net.minecraft.world.level.block.entity.BlockEntityType.BELL,
                net.minecraft.world.level.block.entity.BlockEntityType.BRUSHABLE_BLOCK,net.minecraft.world.level.block.entity.BlockEntityType.MOB_SPAWNER);
        DECORATIVE_BLOCK_ENTITIES=types;
    }
    /** Called after the renderer's own shouldRender said yes. */
    public static boolean cullBlockEntity(net.minecraft.world.level.block.entity.BlockEntity blockEntity,Vec3 camera){
        if(!RenderSettings.active()||!ru.pasha.pashaboost.RuntimeTuning.BLOCK_ENTITY_CULLING||!RenderSettings.current().entities()
                ||!DECORATIVE_BLOCK_ENTITIES.contains(blockEntity.getType()))return false;
        BlockPos pos=blockEntity.getBlockPos();
        double dx=pos.getX()+.5-camera.x,dy=pos.getY()+.5-camera.y,dz=pos.getZ()+.5-camera.z;
        if(dx*dx+dy*dy+dz*dz<=RenderSettings.current().blockEntityDistanceSquared())return false;
        ru.pasha.pashaboost.OptimizationCounters.blockEntitiesCulled++;return true;
    }

    public static void render(RenderLivingEvent.Pre<?, ?> event) {
        if (!RenderSettings.active() || !RenderSettings.current().entities()) return;
        Minecraft mc = Minecraft.getInstance();
        LivingEntity entity = event.getEntity();
        if (mc.level == null || mc.player == null) return;
        Vec3 camera = mc.gameRenderer.getMainCamera().getPosition();
        double distance = entity.distanceToSqr(camera);
        tested++;
        var settings=RenderSettings.current();
        if (distance > settings.entityDistanceSquared()) {
            if(ordinary(mc,entity)){event.setCanceled(true);culled++;}return;
        }
        if(!settings.walls()||distance<settings.nearDistanceSquared()||!ordinary(mc,entity))return;
        long identity = entity.getUUID().getLeastSignificantBits() ^ entity.getUUID().getMostSignificantBits();
        long tick = mc.level.getGameTime();
        Boolean hidden = CACHE.get(entity.getId(),identity,tick,camera.x,camera.y,camera.z,
                entity.getX(),entity.getY(),entity.getZ());
        if (hidden == null) {
            if (wallChecks >= settings.wallChecks()) return;
            wallChecks++;
            hidden = behindOpaqueBlocks(mc, camera, entity.getBoundingBox().inflate(0.1));
            CACHE.put(entity.getId(),identity,tick,settings.cacheTicks(),
                    camera.x,camera.y,camera.z,entity.getX(),entity.getY(),entity.getZ(),hidden);
        }
        if (hidden) { event.setCanceled(true); culled++; }
    }

    private static boolean behindOpaqueBlocks(Minecraft mc, Vec3 start, AABB box) {
        // A visible corner keeps the whole model visible. Never use collision shapes:
        // glass blocks collision, but must not occlude the view.
        if(!opaqueOnRay(mc,start,(box.minX+box.maxX)/2,(box.minY+box.maxY)/2,(box.minZ+box.maxZ)/2)) return false;
        for (int i=0; i<8; i++) {
            double x=(i&1)==0?box.minX:box.maxX;
            double y=(i&2)==0?box.minY:box.maxY;
            double z=(i&4)==0?box.minZ:box.maxZ;
            if (!opaqueOnRay(mc,start,x,y,z)) return false;
        }
        return true;
    }

    private static boolean opaqueOnRay(Minecraft mc, Vec3 start, double x, double y, double z) {
        double dx=x-start.x,dy=y-start.y,dz=z-start.z;
        int bx=Mth.floor(start.x),by=Mth.floor(start.y),bz=Mth.floor(start.z);
        int sx=dx>0?1:dx<0?-1:0, sy=dy>0?1:dy<0?-1:0, sz=dz>0?1:dz<0?-1:0;
        double tx=sx==0?Double.POSITIVE_INFINITY:((sx>0?bx+1:bx)-start.x)/dx;
        double ty=sy==0?Double.POSITIVE_INFINITY:((sy>0?by+1:by)-start.y)/dy;
        double tz=sz==0?Double.POSITIVE_INFINITY:((sz>0?bz+1:bz)-start.z)/dz;
        double stepx=sx==0?Double.POSITIVE_INFINITY:Math.abs(1/dx);
        double stepy=sy==0?Double.POSITIVE_INFINITY:Math.abs(1/dy);
        double stepz=sz==0?Double.POSITIVE_INFINITY:Math.abs(1/dz);
        BlockPos.MutableBlockPos pos=new BlockPos.MutableBlockPos();
        // A hard bound prevents a distant or malicious mod entity from creating unbounded work.
        for (int steps=0; steps<384; steps++) {
            double t;
            if (tx<=ty && tx<=tz) { t=tx; tx+=stepx; bx+=sx; }
            else if (ty<=tz) { t=ty; ty+=stepy; by+=sy; }
            else { t=tz; tz+=stepz; bz+=sz; }
            if (t>=0.98 || !Double.isFinite(t)) return false;
            pos.set(bx,by,bz);
            if (!mc.level.hasChunkAt(pos)) return false;
            BlockState state=mc.level.getBlockState(pos);
            if (state.canOcclude() && state.isSolidRender(mc.level,pos)) return true;
        }
        return false;
    }
    private EntityOptimizer() {}
}
