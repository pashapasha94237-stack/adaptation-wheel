package ru.pasha.pashaboost.mixin.client;

import net.optifine.render.RenderPositions;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import ru.pasha.pashaboost.client.OfModelVertex;

/** Live reads of a model vertex for the OptiFine cube fast path (OfCubeDirectMixin); the class is package-private. */
// OptiFine I6 only (renderPositions is OptiFine's field, written by Cube.collectRenderPositions), so it is never applied in
// development. The three fields are public, and Mixin cannot alias a non-private field: production names only.
@Mixin(targets = "net.minecraft.client.model.geom.ModelPart$Vertex", remap = false)
public abstract class OfModelVertexMixin implements OfModelVertex {
    @Shadow(remap = false) @Final public float f_104372_;
    @Shadow(remap = false) @Final public float f_104373_;
    @Shadow(remap = false) public RenderPositions renderPositions;

    @Override public float pashaboost$u() { return this.f_104372_; }
    @Override public float pashaboost$v() { return this.f_104373_; }
    @Override public RenderPositions pashaboost$renderPositions() { return this.renderPositions; }
}
