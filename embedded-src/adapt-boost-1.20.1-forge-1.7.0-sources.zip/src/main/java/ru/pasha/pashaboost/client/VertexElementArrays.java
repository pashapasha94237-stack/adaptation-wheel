package ru.pasha.pashaboost.client;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.MapMaker;
import com.mojang.blaze3d.vertex.VertexFormatElement;
import ru.pasha.pashaboost.OptimizationCounters;
import java.util.concurrent.ConcurrentMap;

/** One element array per vertex-format element list, shared by all BufferBuilders and threads. */
public final class VertexElementArrays {
    // Weak identity keys: a list maps only to an array copied from that very list. The ConcurrentMap publishes safely.
    private static final ConcurrentMap<ImmutableList<VertexFormatElement>, VertexFormatElement[]> ARRAYS =
            new MapMaker().weakKeys().concurrencyLevel(4).makeMap();

    public static VertexFormatElement[] of(ImmutableList<VertexFormatElement> list) {
        VertexFormatElement[] elements = ARRAYS.get(list);
        if (elements == null) {
            elements = list.toArray(new VertexFormatElement[0]); // same objects, same order
            VertexFormatElement[] raced = ARRAYS.putIfAbsent(list, elements);
            if (raced != null) elements = raced;
            else OptimizationCounters.VERTEX_ELEMENT_ARRAYS_BUILT.incrementAndGet(); // once per format, ever
        }
        return elements;
    }
    private VertexElementArrays() {}
}
