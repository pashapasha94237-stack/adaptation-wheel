package ru.pasha.pashaboost.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.client.CloudStatus;
import net.minecraft.client.GraphicsStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import ru.pasha.pashaboost.BoostConfig;
import ru.pasha.pashaboost.PashaBoost;

/** Temporary vanilla rendering settings; never changes simulation, frame caps or saved presets. */
public final class RuntimeGraphicsProfile {
    private static final List<Change<?>> CHANGES = new ArrayList<>(4);
    private static boolean applied;
    /** graphicsMode changed since the renderer was last rebuilt. */
    private static boolean rendererStale;
    private static boolean fabulousRepairLogged, fabulousRepairFailed;

    /** Run on every client tick, including the inactive state so restoration can happen. */
    public static void tick(Minecraft mc) {
        if (!mc.isSameThread()) { mc.execute(() -> tick(mc)); return; }
        boolean enabled = mc.level != null && BoostConfig.active();
        if (enabled == applied) return;
        if (!enabled) {
            restore();
            rebuildRenderer();
            return;
        }
        // Apply once per activation. Video-setting changes made by the player while active stay theirs.
        set(mc.options.graphicsMode(), GraphicsStatus.FAST);
        // OptiFine derives native cloud quality from its own settings during reload.
        // Use its compatible fast mode and never turn already-disabled clouds back on.
        if (mc.options.cloudStatus().get() != CloudStatus.OFF)
            set(mc.options.cloudStatus(), VideoCompatibility.isOptiFinePresent() ? CloudStatus.FAST : CloudStatus.OFF);
        set(mc.options.entityShadows(), false);
        set(mc.options.renderDistance(), Math.min(mc.options.renderDistance().get(), 8));
        applied = true;
        rebuildRenderer();
    }

    /** Call during disconnect while the Minecraft options and renderer are still available. */
    public static void reset(Minecraft mc) {
        if (!mc.isSameThread()) { mc.execute(() -> reset(mc)); return; }
        restore();
        // The world is closing; the next one rebuilds the renderer when it is set.
        rendererStale = false;
    }

    public static boolean isApplied() { return applied; }

    /**
     * Before every frame: Fabulous without its transparency buffers crashes the frame. Any mod that sets graphicsMode
     * in code (Distant Horizons does) can leave it so after a dimension change; the buffers are recreated instead.
     */
    static void repairFabulous(Minecraft mc) {
        if (mc.level == null || !Minecraft.useShaderTransparency() || mc.levelRenderer.getTranslucentTarget() != null) {
            fabulousRepairFailed = false;
            return;
        }
        if (fabulousRepairFailed) return;
        if (!fabulousRepairLogged) PashaBoost.LOGGER.warn("Fabulous graphics had no transparency buffers; recreating them");
        fabulousRepairLogged = true;
        mc.levelRenderer.graphicsChanged();
        // A renderer that keeps Fabulous without buffers on purpose (a shader pack, say) is left alone after one try.
        fabulousRepairFailed = mc.levelRenderer.getTranslucentTarget() == null;
    }

    /** Some render mods reload options.txt during resource loading. Retain only our
     * still-active temporary choices, without overriding earlier manual edits. */
    public static Runnable protectResourceReload() {
        List<Change<?>> snapshot = CHANGES.stream()
                .filter(change -> Objects.equals(change.option().get(), change.applied())).toList();
        return () -> {
            if (!applied || !BoostConfig.active()) return;
            for (Change<?> change : snapshot) {
                if (CHANGES.stream().anyMatch(current -> current == change)) change.reapplyAfterReload();
            }
            rebuildRenderer();
        };
    }

    /** Serialize the player's choice, without toggling live settings or rebuilding the renderer. */
    @SuppressWarnings("unchecked")
    public static <T> OptionInstance<T> forSaving(OptionInstance<T> option) {
        for (Change<?> change : CHANGES) {
            if (change.option() == option && Objects.equals(option.get(), change.applied())) {
                return new OptionInstance<>("pashaboost.savedOption", OptionInstance.noTooltip(),
                        (caption, value) -> caption, option.values(), option.codec(),
                        (T) change.original(), value -> {});
            }
        }
        return option;
    }

    private static <T> void set(OptionInstance<T> option, T desired) {
        T original = option.get();
        if (Objects.equals(original, desired)) return;
        option.set(desired);
        // Track the actual accepted value, respecting validators supplied by other mods.
        T accepted = option.get();
        if (!Objects.equals(original, accepted)) {
            CHANGES.add(new Change<>(option, original, accepted));
            changed(option);
        }
    }

    private static void restore() {
        for (Change<?> change : CHANGES) change.restore();
        CHANGES.clear();
        applied = false;
    }

    /**
     * Unlike the video settings button, graphicsMode().set() does not rebuild the renderer. Fabulous restored that
     * way had no transparency buffers when a dimension change had dropped them meanwhile, and the next frame
     * crashed, typically on death, which takes the wheel off and releases Boost.
     */
    private static void changed(OptionInstance<?> option) {
        if (option == Minecraft.getInstance().options.graphicsMode()) rendererStale = true;
    }

    /** Once after all settings changed, so the new render distance is rebuilt together with the graphics mode. */
    private static void rebuildRenderer() {
        if (!rendererStale) return;
        rendererStale = false;
        Minecraft.getInstance().levelRenderer.allChanged();
    }

    private record Change<T>(OptionInstance<T> option, T original, T applied) {
        private void reapplyAfterReload() {
            // Only choices that matched our applied value before the reload were
            // captured. Native renderers may derive a third value (e.g. FAST clouds).
            if (Objects.equals(option.get(), applied)) return;
            option.set(applied);
            changed(option);
        }
        private void restore() {
            if (!Objects.equals(option.get(), applied)) return;
            option.set(original);
            changed(option);
        }
    }

    private RuntimeGraphicsProfile() {}
}
