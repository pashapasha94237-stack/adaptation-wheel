package ru.pasha.pashaboost.memory;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableTable;
import net.minecraft.world.level.block.state.properties.Property;

import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Replaces each state's neighbour table and property map with views of one FastMap per block.
 * Adapted from FerriteCore 6.0.1 by malte0811 (MIT, see THIRD-PARTY.md). Unlike FerriteCore's default, the vanilla
 * neighbour table field always holds a working view instead of a table that crashes on access, so a mod reading the
 * field directly still works.
 */
public final class StateMemory {
    public static final AtomicLong STATES_COMPACTED = new AtomicLong();
    // Vanilla populates all states of one block in a row with the same map, so one FastMap is shared by them.
    private static final ThreadLocal<Map<?, ?>> LAST_STATES = new ThreadLocal<>();
    private static final ThreadLocal<FastMap<?>> LAST_MAP = new ThreadLocal<>();

    @SuppressWarnings("unchecked")
    public static <S> void populateNeighbours(Map<Map<Property<?>, Comparable<?>>, S> states, FastMapStateHolder<S> holder) {
        if (states.size() == 1) { holder.pashaboost$setNeighbours(ImmutableTable.of()); return; }
        if (holder.pashaboost$neighbours() != null) throw new IllegalStateException("Neighbours populated twice");
        if (states == LAST_STATES.get()) holder.pashaboost$setStateMap((FastMap<S>) LAST_MAP.get());
        else {
            FastMap<S> map = new FastMap<>(holder.pashaboost$vanillaValues().keySet(), states);
            LAST_STATES.set(states);
            LAST_MAP.set(map);
            holder.pashaboost$setStateMap(map);
        }
        holder.pashaboost$setStateIndex(holder.pashaboost$stateMap().indexOf(holder.pashaboost$vanillaValues()));
        ImmutableMap<Property<?>, Comparable<?>> values = GuavaAccess.propertyMap(holder);
        if (values != null) holder.pashaboost$replaceValues(values);
        holder.pashaboost$setNeighbours(new NeighbourTableView<>(holder));
        STATES_COMPACTED.incrementAndGet();
    }

    private StateMemory() {}
}
