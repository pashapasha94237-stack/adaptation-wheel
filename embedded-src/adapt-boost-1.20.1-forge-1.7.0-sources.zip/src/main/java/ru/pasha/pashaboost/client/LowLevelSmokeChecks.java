package ru.pasha.pashaboost.client;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.chunk.storage.IOWorker;
import ru.pasha.pashaboost.OptimizationCounters;
import ru.pasha.pashaboost.PashaBoost;
import ru.pasha.pashaboost.RuntimeTuning;
import ru.pasha.pashaboost.api.LightCacheMetrics;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

/** Explicit opt-in functional checks against the transformed production game. */
final class LowLevelSmokeChecks {
    private static BlockPos torch;
    private static CompletableFuture<Void> litCheck, darkCheck;
    static boolean enabled() { return Boolean.getBoolean("pashaboost.smoke.lowLevel"); }

    static void fontsAndStorage(Minecraft mc) {
        if(!enabled()) return;
        // Packed glyphs are produced by the first resource load after they were earned (see OptimizationLifecycle).
        if(RuntimeTuning.GLYPH_ACTIVE&&OptimizationCounters.GLYPHS_COMPACTED.get()==0) throw new IllegalStateException("Unicode glyph mixin did not create packed rows");
        int threshold=RuntimeTuning.WRITE_THRESHOLD;
        RuntimeTuning.WRITE_THRESHOLD=2;
        long before=OptimizationCounters.EXTRA_NBT_WRITES.get();
        Path path=mc.gameDirectory.toPath().resolve("io-roundtrip-"+System.nanoTime());
        try {
            Files.createDirectories(path);
            try(var worker=new TestWorker(path)) {
                var writes=new ArrayList<CompletableFuture<Void>>();
                byte[] payload=new byte[8192];
                for(int i=0;i<192;i++) {
                    var tag=new CompoundTag(); tag.putInt("index",i); tag.putByteArray("payload",payload);
                    writes.add(worker.store(new ChunkPos(i-96,-1),tag));
                }
                var finalValue=new CompoundTag(); finalValue.putInt("index",9999);
                writes.add(worker.store(new ChunkPos(-96,-1),finalValue));
                writes.add(worker.store(new ChunkPos(-95,-1),null));
                CompletableFuture.allOf(writes.toArray(CompletableFuture[]::new)).get(30,TimeUnit.SECONDS);
                worker.synchronize(true).get(30,TimeUnit.SECONDS);
            }
            try(var worker=new TestWorker(path)) {
                if(worker.loadAsync(new ChunkPos(-96,-1)).get(10,TimeUnit.SECONDS).orElseThrow().getInt("index")!=9999)
                    throw new IllegalStateException("Overwritten NBT did not survive reopening storage");
                if(worker.loadAsync(new ChunkPos(-95,-1)).get(10,TimeUnit.SECONDS).isPresent())
                    throw new IllegalStateException("Deleted NBT reappeared after reopening storage");
                for(int i=2;i<192;i++) {
                    var tag=worker.loadAsync(new ChunkPos(i-96,-1)).get(10,TimeUnit.SECONDS).orElseThrow();
                    if(tag.getInt("index")!=i || tag.getByteArray("payload").length!=8192)
                        throw new IllegalStateException("Chunk NBT was corrupted at "+i);
                }
            }
            long writes=OptimizationCounters.EXTRA_NBT_WRITES.get()-before;
            if(writes<=0) throw new IllegalStateException("The write-pressure mixin did not drain a burst");
            PashaBoost.LOGGER.info("LOW_LEVEL_STORAGE PASS: 192 chunk tags, overwrite, delete, flush, close/reopen; extraWrites={}",writes);
            PashaBoost.LOGGER.info("LOW_LEVEL_GLYPHS PASS: packedGlyphs={}, cumulativeEstimatedBytes={}",
                    OptimizationCounters.GLYPHS_COMPACTED.get(),OptimizationCounters.ESTIMATED_GLYPH_BYTES_SAVED.get());
        } catch(Exception error) { throw new IllegalStateException("Storage round-trip failed",error); }
        finally { RuntimeTuning.WRITE_THRESHOLD=threshold; }
    }
    static void worldTick(Minecraft mc,int tick) {
        if(!enabled()) return;
        if(tick==25) {
            torch=new BlockPos(15,(int)mc.player.getY()+1,15);
            mc.getSingleplayerServer().execute(()->{
                ServerLevel level=mc.getSingleplayerServer().overworld();
                level.setBlockAndUpdate(torch.below(),Blocks.STONE.defaultBlockState());
                level.setBlockAndUpdate(torch,Blocks.TORCH.defaultBlockState());
            });
        }
        if(tick==85) litCheck=mc.getSingleplayerServer().submit(()->{
            ServerLevel level=mc.getSingleplayerServer().overworld();
            if(level.getBrightness(LightLayer.BLOCK,torch)!=14 || level.getBrightness(LightLayer.BLOCK,torch.east())!=13)
                throw new IllegalStateException("Block light did not cross the chunk border correctly");
            if(!(level.getLightEngine().getLayerListener(LightLayer.BLOCK) instanceof LightCacheMetrics metrics)
                    || metrics.pashaboost$lightHits()==0) throw new IllegalStateException("Lighting cache did not intercept chunk lookups");
            PashaBoost.LOGGER.info("LOW_LEVEL_LIGHT lit: hits={}, misses={}",metrics.pashaboost$lightHits(),metrics.pashaboost$lightMisses());
            level.setBlockAndUpdate(torch,Blocks.AIR.defaultBlockState());
        });
        if(tick==125) darkCheck=mc.getSingleplayerServer().submit(()->{
            if(mc.getSingleplayerServer().overworld().getBrightness(LightLayer.BLOCK,torch)!=0)
                throw new IllegalStateException("Stale light remained after torch removal");
            PashaBoost.LOGGER.info("LOW_LEVEL_LIGHT PASS: border propagation and removal preserved");
        });
        if(tick==139) {
            if(litCheck==null || darkCheck==null) throw new IllegalStateException("Lighting checks were not scheduled");
            litCheck.join(); darkCheck.join();
            PashaBoost.LOGGER.info("LOW_LEVEL_SMOKE PASS: glyph, storage and lighting hooks active in production");
        }
    }
    private static final class TestWorker extends IOWorker {
        TestWorker(Path path) { super(path,false,"PashaBoostSmoke"); }
    }
    private LowLevelSmokeChecks() {}
}
