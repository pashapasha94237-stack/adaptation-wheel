package ru.pasha.pashaboost.mixin.client;

import net.minecraft.client.renderer.blockentity.BlockEntityRenderDispatcher;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import ru.pasha.pashaboost.client.EntityOptimizer;

/** Adds a distance limit for decorative vanilla block entities to the renderer's own check. */
// Each call site has a development and a production name; require = 0 so a conflicting mod only disables this.
@Mixin(value = BlockEntityRenderDispatcher.class, remap = false)
public abstract class BlockEntityDistanceMixin {
    @Redirect(method = {"render(Lnet/minecraft/world/level/block/entity/BlockEntity;FLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;)V",
            "m_112267_(Lnet/minecraft/world/level/block/entity/BlockEntity;FLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;)V"},
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/blockentity/BlockEntityRenderer;shouldRender(Lnet/minecraft/world/level/block/entity/BlockEntity;Lnet/minecraft/world/phys/Vec3;)Z", remap = false),
            require = 0, remap = false)
    private <E extends BlockEntity> boolean pashaboost$named(BlockEntityRenderer<E> renderer, E blockEntity, Vec3 camera) {
        return renderer.shouldRender(blockEntity, camera) && !EntityOptimizer.cullBlockEntity(blockEntity, camera);
    }

    @Redirect(method = {"render(Lnet/minecraft/world/level/block/entity/BlockEntity;FLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;)V",
            "m_112267_(Lnet/minecraft/world/level/block/entity/BlockEntity;FLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;)V"},
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/blockentity/BlockEntityRenderer;m_142756_(Lnet/minecraft/world/level/block/entity/BlockEntity;Lnet/minecraft/world/phys/Vec3;)Z", remap = false),
            require = 0, remap = false)
    private <E extends BlockEntity> boolean pashaboost$srg(BlockEntityRenderer<E> renderer, E blockEntity, Vec3 camera) {
        return renderer.shouldRender(blockEntity, camera) && !EntityOptimizer.cullBlockEntity(blockEntity, camera);
    }
}
