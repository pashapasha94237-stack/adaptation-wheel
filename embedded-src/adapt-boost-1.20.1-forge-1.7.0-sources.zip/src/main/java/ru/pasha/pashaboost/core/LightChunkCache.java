package ru.pasha.pashaboost.core;

import java.util.Arrays;

/** Four-way, thread-confined second-level cache for one lighting batch. */
public final class LightChunkCache<T> {
    public static final int CAPACITY = 16;
    private final long[] keys = new long[CAPACITY];
    private final Object[] values = new Object[CAPACITY];
    private final byte[] victims = new byte[4];
    private int occupied;
    private long hits;
    private long misses;

    /** Presence is independent of coordinate values, including coordinate zero. */
    public boolean contains(int chunkX, int chunkZ) {
        boolean present = find(chunkX,chunkZ) >= 0;
        if (present) hits++; else misses++;
        return present;
    }

    @SuppressWarnings("unchecked")
    public T get(int chunkX, int chunkZ) {
        int slot = find(chunkX,chunkZ);
        return slot>=0 ? (T) values[slot] : null;
    }

    /** One lookup and one metric update on the actual lighting hot path. Null is never cached. */
    @SuppressWarnings("unchecked")
    public T getIfPresent(int chunkX,int chunkZ) {
        int slot=find(chunkX,chunkZ);
        if(slot<0){misses++;return null;}
        hits++;return (T)values[slot];
    }

    public void put(int chunkX, int chunkZ, T value) {
        // A chunk-source future can become ready before this batch ends.
        // Retaining an absence would hide that newly available chunk.
        if (value == null) return;
        int slot=find(chunkX,chunkZ),set=set(chunkX,chunkZ);
        if(slot<0){
            int start=set*4;
            for(int i=0;i<4;i++)if((occupied&(1<<(start+i)))==0){slot=start+i;break;}
            if(slot<0){slot=start+victims[set];victims[set]=(byte)((victims[set]+1)&3);}
        }
        keys[slot] = key(chunkX, chunkZ);
        values[slot] = value;
        occupied |= 1 << slot;
    }

    /** Release every chunk reference, including entries evicted by later coordinates. */
    public void clear() {
        Arrays.fill(values, null);
        occupied = 0;
        Arrays.fill(victims,(byte)0);
    }

    public int size() { return Integer.bitCount(occupied); }
    public long hits() { return hits; }
    public long misses() { return misses; }

    private int find(int x,int z) {
        int start=set(x,z)*4;long key=key(x,z);
        for(int i=0;i<4;i++){int slot=start+i;if((occupied&(1<<slot))!=0 && keys[slot]==key)return slot;}
        return -1;
    }
    // Each parity set holds the four cells of a 4x4 local neighborhood. Four-way
    // storage also keeps common stride-four accesses from evicting one another.
    private static int set(int x,int z){return (x&1)|((z&1)<<1);}
    private static long key(int x, int z) { return (x & 0xffffffffL) | ((z & 0xffffffffL) << 32); }
}
