package ru.pasha.pashaboost.mixin;

import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.SynchedEntityData;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import ru.pasha.pashaboost.OptimizationCounters;
import ru.pasha.pashaboost.RuntimeTuning;

/**
 * SynchedEntityData.get takes and releases a ReentrantReadWriteLock read lock around one Int2ObjectOpenHashMap lookup
 * (JFR: getItem 2.9-5.5 % of the render thread, 4 % of the server thread with 24 mods). itemsById is filled by define()
 * while the entity is built and never changes shape afterwards; values are read and written outside the lock in vanilla
 * too. Each get decides once, so a lock/unlock pair never mixes paths, the real lock stays for every other user
 * (packDirty, assignValues, mods' accessors), and turning Boost off returns to vanilla at once for every entity.
 * Residual risk, the same as Lithium's no_locks (LGPL-3.0, idea only): a mod calling define() on a live entity while
 * another thread reads it.
 */
// Each call site has a development and a production name; require = 0 so a conflicting mod only disables this.
// The plugin skips it with OptiFine (it patches SynchedEntityData) and next to Lithium ports.
@Mixin(value = SynchedEntityData.class, remap = false)
public abstract class EntityDataLockMixin {
    // Production name first, development name as the alias: Mahou Tsukai's access transformer makes itemsById public, and
    // Mixin refuses to alias a non-private field (a FATAL load error even with require = 0). An exact match is never checked.
    @Shadow(aliases = {"itemsById"}, remap = false) @Final private Int2ObjectMap<SynchedEntityData.DataItem<?>> f_135345_;

    // A shadow method may be aliased even when it is not private (First Aid makes getItem public); only @Overwrite may not.
    @Shadow(aliases = {"m_135379_"}, remap = false)
    private <T> SynchedEntityData.DataItem<T> getItem(EntityDataAccessor<T> key) { throw new AssertionError(); }

    @Redirect(method = {"get(Lnet/minecraft/network/syncher/EntityDataAccessor;)Ljava/lang/Object;",
            "m_135370_(Lnet/minecraft/network/syncher/EntityDataAccessor;)Ljava/lang/Object;"},
            at = @At(value = "INVOKE", target = "Lnet/minecraft/network/syncher/SynchedEntityData;getItem(Lnet/minecraft/network/syncher/EntityDataAccessor;)Lnet/minecraft/network/syncher/SynchedEntityData$DataItem;", remap = false),
            require = 0, remap = false)
    private SynchedEntityData.DataItem<?> pashaboost$namedItem(SynchedEntityData self, EntityDataAccessor<?> key) { return pashaboost$item(key); }

    @Redirect(method = {"get(Lnet/minecraft/network/syncher/EntityDataAccessor;)Ljava/lang/Object;",
            "m_135370_(Lnet/minecraft/network/syncher/EntityDataAccessor;)Ljava/lang/Object;"},
            at = @At(value = "INVOKE", target = "Lnet/minecraft/network/syncher/SynchedEntityData;m_135379_(Lnet/minecraft/network/syncher/EntityDataAccessor;)Lnet/minecraft/network/syncher/SynchedEntityData$DataItem;", remap = false),
            require = 0, remap = false)
    private SynchedEntityData.DataItem<?> pashaboost$srgItem(SynchedEntityData self, EntityDataAccessor<?> key) { return pashaboost$item(key); }

    @Unique
    private SynchedEntityData.DataItem<?> pashaboost$item(EntityDataAccessor<?> key) {
        if (RuntimeTuning.ACTIVE && RuntimeTuning.ENTITY_DATA_LOCK_ELISION) {
            SynchedEntityData.DataItem<?> item = this.f_135345_.get(key.getId());
            if (item != null) {
                if (!OptimizationCounters.entityDataUnlockedSeen) OptimizationCounters.entityDataUnlockedSeen = true;
                return item;
            }
        }
        return this.getItem(key); // vanilla: read lock, lookup, crash report for an unknown id
    }
}
