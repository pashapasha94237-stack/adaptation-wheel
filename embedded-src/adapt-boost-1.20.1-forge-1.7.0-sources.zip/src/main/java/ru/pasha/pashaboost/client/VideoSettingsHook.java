package ru.pasha.pashaboost.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.VideoSettingsScreen;
import net.minecraft.client.gui.screens.Screen;
import java.lang.ref.WeakReference;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import ru.pasha.pashaboost.PashaBoost;

/** Replaces the standard video-settings destination while preserving its parent screen. */
@Mod.EventBusSubscriber(modid = PashaBoost.ID, value = Dist.CLIENT)
public final class VideoSettingsHook {
    private static WeakReference<Screen> explicitNative = new WeakReference<>(null);
    private VideoSettingsHook() {}

    @SubscribeEvent
    public static void opening(ScreenEvent.Opening event) {
        // Permit the exact advanced screen opened from our own menu, including all
        // subsequent returns from its shader/quality child pages. No strong UI retention.
        if (event.getNewScreen() == explicitNative.get()) return;
        if (event.getNewScreen() != null && event.getCurrentScreen() != null
                && event.getNewScreen().getClass() == VideoSettingsScreen.class) {
            event.setNewScreen(new OwnVideoScreen(event.getCurrentScreen(), Minecraft.getInstance().options));
        }
    }

    public static void openNative(Screen parent) {
        Minecraft mc = Minecraft.getInstance();
        Screen nativeScreen = new VideoSettingsScreen(parent, mc.options);
        explicitNative = new WeakReference<>(nativeScreen);
        mc.setScreen(nativeScreen);
    }
}
