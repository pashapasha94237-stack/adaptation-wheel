package ru.pasha.pashaboost.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.OptionsSubScreen;
import net.minecraft.client.gui.screens.VideoSettingsScreen;

/** OptiFine is a transformation service and need not appear in Forge's mod list. */
public final class VideoCompatibility {
    private static final boolean OPTIFINE = available("net.optifine.Config")
            || available("net.optifine.gui.GuiScreenOF")
            || !OptionsSubScreen.class.isAssignableFrom(VideoSettingsScreen.class);

    public static boolean isOptiFinePresent() { return OPTIFINE; }

    private static boolean available(String name) {
        try {
            Class.forName(name, false, Minecraft.class.getClassLoader());
            return true;
        } catch (ClassNotFoundException | LinkageError absent) {
            return false;
        }
    }
    private VideoCompatibility() {}
}
