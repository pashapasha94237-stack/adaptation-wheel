package ru.pasha.pashaboost.client;

import ru.pasha.pashaboost.BoostConfig;
import ru.pasha.pashaboost.RuntimeTuning;
import ru.pasha.pashaboost.api.FpsAdaptationBoost;
import ru.pasha.pashaboost.core.AdaptiveBudget;

/** Read Forge settings once per client tick, not for every particle or rendered mob. */
final class RenderSettings {
    record Values(boolean entities,boolean walls,boolean particles,boolean modParticles,
                  double entityDistanceSquared,double nearDistanceSquared,double particleDistanceSquared,
                  int wallChecks,int cacheTicks,int particleLimit,int particlesPerTick,double blockEntityDistanceSquared) {}
    private static Values current=new Values(false,false,false,false,0,0,0,0,1,1,1,0);
    static boolean active(){return RuntimeTuning.ACTIVE&&FpsAdaptationBoost.isActive();}
    static Values current(){return current;}
    static void refresh(){
        if(!RuntimeTuning.ACTIVE)return;
        int near=BoostConfig.NEAR_DISTANCE.get(),particle=BoostConfig.particleDistance();
        // The frame-time controller that scales particle budgets also pulls the mob distance in
        // (never below the protected radius) and lets it back out once frames recover.
        int entity=AdaptiveBudget.distance(BoostConfig.entityDistance(),near,BoostClient.particleScale());
        int blockEntity=Math.max(32,entity);
        current=new Values(BoostConfig.entityCullingEnabled(),BoostConfig.WALL_CULLING.get(),BoostConfig.particlesEnabled(),
                BoostConfig.filterModParticles(),(double)entity*entity,(double)near*near,(double)particle*particle,
                BoostConfig.WALL_CHECKS_PER_TICK.get(),BoostConfig.VISIBILITY_CACHE_TICKS.get(),
                BoostConfig.particleLimit(),BoostConfig.particlesPerTick(),(double)blockEntity*blockEntity);
    }
    private RenderSettings(){}
}
