package ru.pasha.pashaboost.mixin.client;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectListIterator;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.AABB;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import ru.pasha.pashaboost.client.BrandonsTransparency;

/**
 * BrandonsCore's after-particles pass draws only block entities whose renderer is a BlockEntityRendererTransparent
 * (Draconic Evolution's reactor core), yet built a render box and ran a frustum test for every block entity of every
 * visible section first. The box is now built only where BrandonsCore's own renderer test will pass, and the walk over
 * visible sections is skipped while no compiled section list can hold such a block entity (SectionListRecorderMixin).
 */
// The pass is BrandonsCore's own method (one name); the Frustum call has a development and a production name.
// require = 0 so a changed BrandonsCore or a conflicting mod only disables this. The plugin applies it with BrandonsCore 3.2 only.
@Pseudo
@Mixin(targets = "com.brandon3055.brandonscore.client.BCClientEventHandler", remap = false)
public abstract class BrandonsTransparentPassMixin {
    @Redirect(method = "renderLevelStage(Lnet/minecraftforge/client/event/RenderLevelStageEvent;)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/entity/BlockEntity;getRenderBoundingBox()Lnet/minecraft/world/phys/AABB;", remap = false),
            require = 0, remap = false)
    private AABB pashaboost$boundsIfTransparent(BlockEntity blockEntity) {
        return BrandonsTransparency.boundsOrSkip(blockEntity);
    }

    @Redirect(method = "renderLevelStage(Lnet/minecraftforge/client/event/RenderLevelStageEvent;)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/culling/Frustum;isVisible(Lnet/minecraft/world/phys/AABB;)Z", remap = false),
            require = 0, remap = false)
    private boolean pashaboost$named(Frustum frustum, AABB box) {
        return box != BrandonsTransparency.SKIP && frustum.isVisible(box);
    }

    @Redirect(method = "renderLevelStage(Lnet/minecraftforge/client/event/RenderLevelStageEvent;)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/culling/Frustum;m_113029_(Lnet/minecraft/world/phys/AABB;)Z", remap = false),
            require = 0, remap = false)
    private boolean pashaboost$srg(Frustum frustum, AABB box) {
        return box != BrandonsTransparency.SKIP && frustum.isVisible(box);
    }

    @Redirect(method = "renderLevelStage(Lnet/minecraftforge/client/event/RenderLevelStageEvent;)V",
            at = @At(value = "INVOKE", target = "Lit/unimi/dsi/fastutil/objects/ObjectArrayList;iterator()Lit/unimi/dsi/fastutil/objects/ObjectListIterator;", remap = false),
            require = 0, remap = false)
    private ObjectListIterator<?> pashaboost$visibleSections(ObjectArrayList<?> renderChunksInFrustum) {
        return BrandonsTransparency.visibleSections(renderChunksInFrustum);
    }
}
