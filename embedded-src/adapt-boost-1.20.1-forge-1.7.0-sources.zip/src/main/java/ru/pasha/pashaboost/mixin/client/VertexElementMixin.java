package ru.pasha.pashaboost.mixin.client;

import com.google.common.collect.ImmutableList;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferVertexConsumer;
import com.mojang.blaze3d.vertex.DefaultedVertexConsumer;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormatElement;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import ru.pasha.pashaboost.RuntimeTuning;
import ru.pasha.pashaboost.client.VertexElementArrays;

/**
 * BufferBuilder.nextElement runs once per vertex attribute, and each call depends on the one before: index -> (index + 1)
 * % list.size() (an integer division) -> list.get (Guava RegularImmutableMap$Values walk) -> byte size -> next write offset.
 * JFR without OptiFine: 13.8 % inclusive of the render thread with 24 mods. Vanilla's method with two exact substitutions:
 * the element comes from an array holding the very same objects in the same order, and the modulo becomes a comparison
 * while the index is in range. PADDING recursion, field-write order and the default colour stay vanilla. Only text,
 * particles, GUI, fluids and per-element renderers get here: BLOCK and NEW_ENTITY vertices take the fastFormat path.
 * Same goal as Embeddium's BufferBuilderMixin (LGPL-3.0); own code.
 */
// No aliases: an @Overwrite that resolves through an alias to a public method throws InvalidMixinException. Production
// finds m_5751_ because reobf renames this override (checked in the built jar). The plugin skips it with OptiFine and
// next to Embeddium, Oculus and ImmediatelyFast.
@Mixin(value = BufferBuilder.class, remap = false)
public abstract class VertexElementMixin extends DefaultedVertexConsumer implements BufferVertexConsumer {
    // Fields by production name, development name as the alias: CodeChickenLib and Re-Avaritia make format public by
    // access transformer, and Mixin refuses to alias a non-private field (FATAL even with require = 0). An exact match
    // is never checked.
    @Shadow(aliases = {"format"}, remap = false) private VertexFormat f_85658_;
    @Shadow(aliases = {"currentElement"}, remap = false) private VertexFormatElement f_85655_;
    @Shadow(aliases = {"elementIndex"}, remap = false) private int f_85656_;
    @Shadow(aliases = {"nextElementByte"}, remap = false) private int f_85652_;

    // One builder is filled by one thread at a time, so these are plain fields. Two slots, because the shared Tesselator
    // builder alternates formats every few vertices in GUIs.
    @Unique private ImmutableList<VertexFormatElement> pashaboost$list, pashaboost$otherList;
    @Unique private VertexFormatElement[] pashaboost$elements, pashaboost$otherElements;

    /**
     * @author pasha
     * @reason Same result without the integer division and the Guava list walk on every vertex attribute.
     */
    @Overwrite(remap = false)
    public void nextElement() {
        ImmutableList<VertexFormatElement> list = this.f_85658_.getElements();
        if (!RuntimeTuning.ACTIVE || !RuntimeTuning.VERTEX_ELEMENT_ARRAY) {
            // Vanilla, statement for statement.
            this.f_85656_ = (this.f_85656_ + 1) % list.size();
            this.f_85652_ += this.f_85655_.getByteSize();
            VertexFormatElement element = list.get(this.f_85656_);
            this.f_85655_ = element;
            if (element.getUsage() == VertexFormatElement.Usage.PADDING) this.nextElement();
            if (this.defaultColorSet && this.f_85655_.getUsage() == VertexFormatElement.Usage.COLOR)
                BufferVertexConsumer.super.color(this.defaultR, this.defaultG, this.defaultB, this.defaultA);
            return;
        }
        VertexFormatElement[] elements = this.pashaboost$elements;
        if (list != this.pashaboost$list) {
            ImmutableList<VertexFormatElement> previous = this.pashaboost$list;
            VertexFormatElement[] previousElements = elements;
            elements = list == this.pashaboost$otherList ? this.pashaboost$otherElements : VertexElementArrays.of(list);
            this.pashaboost$otherList = previous;
            this.pashaboost$otherElements = previousElements;
            this.pashaboost$list = list;
            this.pashaboost$elements = elements;
        }
        int size = elements.length, next = this.f_85656_ + 1;
        // == (elementIndex + 1) % size for every int; size 0 still throws ArithmeticException.
        this.f_85656_ = next < size && next >= 0 ? next : next == size && size != 0 ? 0 : next % size;
        this.f_85652_ += this.f_85655_.getByteSize();
        VertexFormatElement element = elements[this.f_85656_];
        this.f_85655_ = element;
        if (element.getUsage() == VertexFormatElement.Usage.PADDING) this.nextElement();
        if (this.defaultColorSet && this.f_85655_.getUsage() == VertexFormatElement.Usage.COLOR)
            BufferVertexConsumer.super.color(this.defaultR, this.defaultG, this.defaultB, this.defaultA);
    }
}
