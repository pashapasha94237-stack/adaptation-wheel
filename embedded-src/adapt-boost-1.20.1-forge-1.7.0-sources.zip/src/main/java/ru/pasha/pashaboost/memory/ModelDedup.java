package ru.pasha.pashaboost.memory;

import com.google.common.base.Splitter;
import net.minecraft.client.renderer.block.model.multipart.Condition;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.MultiPartBakedModel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.Property;
import org.apache.commons.lang3.tuple.Pair;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Predicate;

/**
 * Multipart block models (fences, walls, redstone, glass panes...) built a predicate tree and a MultiPartBakedModel,
 * with its own selector cache, for every block state. Equal predicates are now one object, so equal selector lists
 * compare equal and all states of a block share one model. Adapted from FerriteCore 6.0.1 by malte0811 (MIT, see
 * THIRD-PARTY.md). The caches only live during model loading and are dropped after each resource reload.
 */
public final class ModelDedup {
    public static final AtomicLong MODELS_SHARED = new AtomicLong();
    private static final Splitter PIPE = Splitter.on('|').omitEmptyStrings();
    private static final Map<Pair<Property<?>, Comparable<?>>, Predicate<BlockState>> HAS_VALUE = new ConcurrentHashMap<>();
    private static final Map<List<Predicate<BlockState>>, Predicate<BlockState>> ANY = new ConcurrentHashMap<>(), ALL = new ConcurrentHashMap<>();
    private static final Map<List<Pair<Predicate<BlockState>, BakedModel>>, MultiPartBakedModel> MULTIPART = new ConcurrentHashMap<>();

    public static Predicate<BlockState> and(Iterable<? extends Condition> conditions, StateDefinition<Block, BlockState> definition) {
        return ALL.computeIfAbsent(canonical(conditions, definition), ModelDedup::allOf);
    }

    public static Predicate<BlockState> or(Iterable<? extends Condition> conditions, StateDefinition<Block, BlockState> definition) {
        return ANY.computeIfAbsent(canonical(conditions, definition), ModelDedup::anyOf);
    }

    /** Vanilla's KeyValueCondition.getPredicate with the same errors, returning shared predicates. */
    public static Predicate<BlockState> keyValue(StateDefinition<Block, BlockState> definition, String key, String value) {
        Property<?> property = definition.getProperty(key);
        if (property == null) throw new RuntimeException(String.format(Locale.ROOT, "Unknown property '%s' on '%s'", key, definition.getOwner()));
        boolean invert = !value.isEmpty() && value.charAt(0) == '!';
        String values = invert ? value.substring(1) : value;
        List<String> matched = PIPE.splitToList(values);
        if (matched.isEmpty()) throw new RuntimeException(String.format(Locale.ROOT, "Empty value '%s' for property '%s' on '%s'", value, key, definition.getOwner()));
        Predicate<BlockState> predicate;
        if (matched.size() == 1) predicate = hasValue(definition, property, values, key, value);
        else {
            List<Predicate<BlockState>> parts = new ArrayList<>(matched.size());
            for (String one : matched) parts.add(hasValue(definition, property, one, key, value));
            sort(parts);
            predicate = ANY.computeIfAbsent(parts, ModelDedup::anyOf);
        }
        return invert ? predicate.negate() : predicate;
    }

    public static MultiPartBakedModel multipart(List<Pair<Predicate<BlockState>, BakedModel>> selectors) {
        MultiPartBakedModel[] created = new MultiPartBakedModel[1];
        MultiPartBakedModel model = MULTIPART.computeIfAbsent(selectors, s -> created[0] = new MultiPartBakedModel(s));
        if (model != created[0]) MODELS_SHARED.incrementAndGet();
        return model;
    }

    /** After a resource reload the caches would only keep the previous models alive. */
    public static void clear() {
        ANY.clear(); ALL.clear(); MULTIPART.clear();
    }

    private static Predicate<BlockState> hasValue(StateDefinition<Block, BlockState> definition, Property<?> property, String text, String key, String fullValue) {
        Optional<?> parsed = property.getValue(text);
        if (parsed.isEmpty())
            throw new RuntimeException(String.format(Locale.ROOT, "Unknown value '%s' for property '%s' on '%s' in '%s'", text, key, definition.getOwner(), fullValue));
        return HAS_VALUE.computeIfAbsent(Pair.of(property, (Comparable<?>) parsed.get()), pair -> {
            Property<?> p = pair.getLeft();
            Comparable<?> v = pair.getRight();
            return state -> state.getValue(p).equals(v);
        });
    }

    private static List<Predicate<BlockState>> canonical(Iterable<? extends Condition> conditions, StateDefinition<Block, BlockState> definition) {
        List<Predicate<BlockState>> list = new ArrayList<>();
        for (Condition condition : conditions) list.add(condition.getPredicate(definition));
        sort(list);
        return list;
    }

    /** All and any do not depend on order, so equal sets of shared predicates become equal lists. */
    private static void sort(List<Predicate<BlockState>> list) {
        list.sort(Comparator.comparingInt(Object::hashCode));
        if (list instanceof ArrayList<Predicate<BlockState>> array) array.trimToSize();
    }

    private static Predicate<BlockState> allOf(List<Predicate<BlockState>> list) {
        return state -> { for (Predicate<BlockState> p : list) if (!p.test(state)) return false; return true; };
    }

    private static Predicate<BlockState> anyOf(List<Predicate<BlockState>> list) {
        return state -> { for (Predicate<BlockState> p : list) if (p.test(state)) return true; return false; };
    }

    private ModelDedup() {}
}
