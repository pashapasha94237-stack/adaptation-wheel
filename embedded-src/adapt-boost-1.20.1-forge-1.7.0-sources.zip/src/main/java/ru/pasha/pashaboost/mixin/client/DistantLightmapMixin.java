package ru.pasha.pashaboost.mixin.client;

import com.mojang.blaze3d.platform.NativeImage;
import java.util.Arrays;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.pasha.pashaboost.OptimizationCounters;
import ru.pasha.pashaboost.RuntimeTuning;

/**
 * Distant Horizons 3.3 on 1.20.1 copies the 16x16 lightmap into its own texture on every frame,
 * querying the active texture (a driver sync) and checking glIsTexture each time, even with its
 * renderer switched off. Vanilla recomputes the lightmap at most once a tick, so an upload is
 * skipped when the pixels and the world are the same as the last one Distant Horizons received.
 * Applied only when Distant Horizons is installed (see BoostMixinPlugin).
 */
@Mixin(targets = "com.seibel.distanthorizons.common.wrappers.minecraft.MinecraftRenderWrapper_forge", remap = false)
public abstract class DistantLightmapMixin {
    @Unique private int[] pashaboost$lastPixels;
    @Unique private Object pashaboost$lastLevel;

    @Inject(method = "updateLightmap(Lcom/mojang/blaze3d/platform/NativeImage;)V", at = @At("HEAD"), cancellable = true, require = 0, remap = false)
    private void pashaboost$skipUnchangedLightmap(NativeImage pixels, CallbackInfo ci) {
        if (!RuntimeTuning.ACTIVE || !RuntimeTuning.DISTANT_LIGHTMAP_SKIP || pixels == null) return;
        Object level = Minecraft.getInstance().level;
        int[] now = pixels.getPixelsRGBA();
        if (level == pashaboost$lastLevel && Arrays.equals(now, pashaboost$lastPixels)) {
            OptimizationCounters.distantLightmapUploadsSkipped++;
            ci.cancel();
            return;
        }
        pashaboost$lastPixels = now;
        pashaboost$lastLevel = level;
    }
}
