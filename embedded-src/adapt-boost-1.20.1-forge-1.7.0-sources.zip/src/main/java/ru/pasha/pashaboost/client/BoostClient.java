package ru.pasha.pashaboost.client;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.client.ConfigScreenHandler.ConfigScreenFactory;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraft.server.packs.resources.ResourceManagerReloadListener;
import net.minecraftforge.client.event.RegisterClientReloadListenersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import ru.pasha.pashaboost.memory.ModelDedup;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.lwjgl.glfw.GLFW;
import ru.pasha.pashaboost.BoostConfig;
import ru.pasha.pashaboost.api.FpsAdaptationBoost;
import ru.pasha.pashaboost.core.AdaptiveBudget;
import ru.pasha.pashaboost.core.FrameStats;

import java.util.Locale;

public final class BoostClient {
    private static final KeyMapping MENU = new KeyMapping("key.pashaboost.menu", GLFW.GLFW_KEY_F8, "key.categories.pashaboost");
    private static final KeyMapping BENCHMARK = new KeyMapping("key.pashaboost.benchmark", GLFW.GLFW_KEY_F9, "key.categories.pashaboost");
    private static final KeyMapping TOGGLE = new KeyMapping("key.pashaboost.toggle", GLFW.GLFW_KEY_F10, "key.categories.pashaboost");
    private static final FrameStats SECOND = new FrameStats(4096);
    private static final AdaptiveBudget ADAPTIVE = new AdaptiveBudget();
    private static long lastFrame, lastUpdate;
    private static FrameStats.Snapshot latest = SECOND.snapshot();
    private static int ticks;
    /** Recent frame times in ms for the graphs, newest at RECENT_NEXT - 1. */
    static final float[] RECENT_MS = new float[240];
    static int RECENT_NEXT;
    /** Work saved per second: shader lookups, particle light, block entities, entity ticks, particle vectors, biome lookups, mobs, particles. */
    static final long[] RATES = new long[8];
    private static final long[] LAST = new long[8];
    private static long usedMemory, maxMemory;

    public static void register() {
        var modBus = FMLJavaModLoadingContext.get().getModEventBus();
        modBus.addListener(BoostClient::setup);
        modBus.addListener(BoostClient::keys);
        modBus.addListener(BoostClient::overlays);
        // Model-loading caches of the memory savings would otherwise keep the previous models alive.
        modBus.addListener((RegisterClientReloadListenersEvent event) ->
                event.registerReloadListener((ResourceManagerReloadListener) resources -> {
                    ModelDedup.clear();
                    ru.pasha.pashaboost.memory.ModelSides.clearVertices();
                }));
        ModLoadingContext.get().registerExtensionPoint(ConfigScreenFactory.class,
                () -> new ConfigScreenFactory((mc,parent) -> new BoostScreen(parent)));
        MinecraftForge.EVENT_BUS.addListener(BoostClient::tick);
        MinecraftForge.EVENT_BUS.addListener(BoostClient::frame);
        MinecraftForge.EVENT_BUS.addListener(BoostClient::living);
        MinecraftForge.EVENT_BUS.addListener(BoostClient::logout);
    }

    private static void setup(FMLClientSetupEvent event) { event.enqueueWork(ParticleOptimizer::install); }
    private static void keys(RegisterKeyMappingsEvent event) {
        event.register(MENU); event.register(BENCHMARK); event.register(TOGGLE);
    }
    private static void overlays(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("status", (gui,graphics,partial,width,height) -> {
            Minecraft mc=Minecraft.getInstance();
            if (mc.level==null || mc.options.hideGui || mc.screen instanceof BoostScreen || (!BoostConfig.HUD.get() && !Benchmark.running())) return;
            renderHud(graphics,mc);
        });
    }
    private static void living(RenderLivingEvent.Pre<?, ?> event) { EntityOptimizer.render(event); }

    private static void tick(TickEvent.ClientTickEvent event) {
        Minecraft mc=Minecraft.getInstance();
        if (event.phase==TickEvent.Phase.START) {
            OptimizationLifecycle.tick(mc);
            EntityOptimizer.tick();
            if (mc.level!=null && BoostConfig.active()) {
                ParticleOptimizer.tick();
                if (++ticks%100==0) ParticleOptimizer.install();
            }
            if (!BoostConfig.active()) ADAPTIVE.reset();
            return;
        }
        SmokeProbe.tick();
        while (MENU.consumeClick()) {
            Benchmark.cancel();
            mc.setScreen(new BoostScreen(mc.screen));
        }
        while (BENCHMARK.consumeClick()) {
            if (Benchmark.running()) Benchmark.cancel();
            else if (mc.level!=null && mc.screen==null) Benchmark.start();
        }
        while (TOGGLE.consumeClick()) {
            Benchmark.cancel();
            BoostConfig.ENABLED.set(!BoostConfig.ENABLED.get()); BoostConfig.save();
            EntityOptimizer.clear();
            if(mc.player!=null) mc.player.displayClientMessage(Component.translatable(
                    !FpsAdaptationBoost.isActive()?"pashaboost.adaptation_required":BoostConfig.ENABLED.get()?"pashaboost.enabled":"pashaboost.disabled"),true);
        }
    }

    private static void frame(TickEvent.RenderTickEvent event) {
        Minecraft mc=Minecraft.getInstance();
        // A crash guard, so it runs whether or not Boost was earned.
        if(event.phase==TickEvent.Phase.START) { RuntimeGraphicsProfile.repairFabulous(mc); return; }
        IdleFrameCap.endOfFrame(mc);
        long now=System.nanoTime();
        if(mc.level==null || mc.screen!=null || mc.isPaused() || !mc.isWindowActive()) {
            lastFrame=0;
            if (Benchmark.running()) Benchmark.cancel();
            return;
        }
        if(lastFrame!=0) {
            long elapsed=now-lastFrame;
            SECOND.addNanos(elapsed);
            Benchmark.frame(now,elapsed);
            RECENT_MS[RECENT_NEXT]=elapsed/1_000_000f;
            RECENT_NEXT=(RECENT_NEXT+1)%RECENT_MS.length;
        }
        lastFrame=now;
        if(now-lastUpdate<1_000_000_000L) return;
        lastUpdate=now;
        latest=SECOND.snapshot(); SECOND.clear();
        Runtime rt=Runtime.getRuntime();
        long used=rt.totalMemory()-rt.freeMemory();
        usedMemory=used; maxMemory=rt.maxMemory();
        if (BoostConfig.active() && BoostConfig.adaptiveEnabled() && !Benchmark.running() && latest.frames()>0) {
            int target=Math.min(BoostConfig.TARGET_FPS.get(),mc.options.framerateLimit().get());
            // VSync waits are not load; keep heap-pressure feedback active in that mode.
            double frameMillis=mc.options.enableVsync().get()?750.0/target:1000/latest.averageFps();
            ADAPTIVE.update(frameMillis,(double)used/rt.maxMemory(),target);
        } else if (!BoostConfig.adaptiveEnabled()) ADAPTIVE.reset();
        long[] now8={ru.pasha.pashaboost.OptimizationCounters.shaderLookupsSaved,ru.pasha.pashaboost.OptimizationCounters.particleLightReused+ru.pasha.pashaboost.OptimizationCounters.particleLightShared,
                ru.pasha.pashaboost.OptimizationCounters.blockEntitiesCulled,ru.pasha.pashaboost.OptimizationCounters.entityTicksSkipped,
                ru.pasha.pashaboost.OptimizationCounters.particleVectorsReused,ru.pasha.pashaboost.OptimizationCounters.biomeLookupsSaved,
                EntityOptimizer.culledCount(),ParticleOptimizer.rejectedCount()};
        for(int i=0;i<RATES.length;i++){RATES[i]=Math.max(0,now8[i]-LAST[i]);LAST[i]=now8[i];}
    }

    /** Compact HUD: FPS in colour, 1% low and p95, a frame-time graph and memory. */
    private static void renderHud(net.minecraft.client.gui.GuiGraphics g,Minecraft mc) {
        var font=mc.font;
        boolean on=BoostConfig.active();
        String fps=String.format(Locale.ROOT,"%.0f",latest.averageFps());
        String detail=String.format(Locale.ROOT," FPS  1%% %.0f  p95 %.1f ms",latest.onePercentLowFps(),latest.p95Millis());
        Component state=Component.translatable(!FpsAdaptationBoost.isActive()?"pashaboost.hud.locked":on?"pashaboost.hud.on":"pashaboost.hud.off");
        String memory=String.format(Locale.ROOT,"%d / %d MB",usedMemory/1048576,maxMemory/1048576);
        // The memory text starts after its 40 px bar.
        int width=Math.max(150,Math.max(font.width(fps)+font.width(detail),44+font.width(memory)+12+font.width(state))+12);
        int height=Benchmark.running()?52:40;
        g.fill(4,4,4+width,4+height,0xC0101A1D);
        g.fill(4,4,6,4+height,on?BoostUi.ACCENT:BoostUi.FAINT);
        g.drawString(font,fps,10,8,BoostUi.fpsColor(latest.averageFps()),false);
        g.drawString(font,detail,10+font.width(fps),8,BoostUi.MUTED,false);
        BoostUi.frameGraph(g,10,19,width-12,9,RECENT_MS,RECENT_NEXT);
        BoostUi.bar(g,10,31,40,4,maxMemory>0?(float)usedMemory/maxMemory:0,usedMemory>maxMemory*0.85?BoostUi.BAD:BoostUi.ACCENT);
        g.drawString(font,memory,54,30,BoostUi.MUTED,false);
        g.drawString(font,state,4+width-6-font.width(state),30,on?BoostUi.ACCENT:BoostUi.FAINT,false);
        if (Benchmark.running()) g.drawString(font,Benchmark.status(),10,43,BoostUi.WARN,false);
    }
    static long usedMemory() { return usedMemory; }
    static long maxMemory() { return maxMemory; }

    private static void logout(ClientPlayerNetworkEvent.LoggingOut event) {
        FpsAdaptationBoost.setActive(false);
        OptimizationLifecycle.reset(Minecraft.getInstance());
        Benchmark.cancel(); EntityOptimizer.clear(); ParticleOptimizer.clear(); ADAPTIVE.reset();
        SECOND.clear(); latest=SECOND.snapshot(); lastFrame=lastUpdate=0; ticks=0;
        java.util.Arrays.fill(RECENT_MS,0); java.util.Arrays.fill(RATES,0);
    }
    public static double particleScale() {
        return BoostConfig.active() && BoostConfig.adaptiveEnabled() && !Benchmark.running() ? ADAPTIVE.scale() : 1.0;
    }
    public static FrameStats.Snapshot stats() { return latest; }
    private BoostClient() {}
}
