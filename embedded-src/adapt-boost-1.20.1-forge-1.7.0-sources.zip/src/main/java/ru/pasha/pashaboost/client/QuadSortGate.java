package ru.pasha.pashaboost.client;

import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;

/**
 * Whether QuadSortMixin was merged whole into BufferBuilder. Only ASM and the JDK here: BoostMixinPlugin.postApply calls
 * this while BufferBuilder itself is being transformed, so linking it must not load any game class.
 */
public final class QuadSortGate {
    /** Set once by BoostMixinPlugin.postApply when all three handlers are in BufferBuilder; the deferred state needs all. */
    public static volatile boolean READY;

    /** Source names of the handlers in QuadSortMixin with the two names of the method each one is injected into. */
    private static final String[][] HANDLERS = {
            {"pashaboost$quadSortBegin", "setQuadSorting", "m_277127_"},
            {"pashaboost$quadSortState", "getSortState", "m_166770_"},
            {"pashaboost$quadSortWrite", "putSortedQuadIndices", "m_166786_"}};

    /**
     * True when every handler of QuadSortMixin is called from the method it was written for and no other mod's mixin
     * touches the code the fast path bypasses: setQuadSorting, makeQuadSortingPoints, putSortedQuadIndices and the index
     * writer getIntConsumer with its lambdas. That means no merged injector (handler$, redirect$, modify*$, localvar$,
     * constant$, args$, wrap*$) is called there and no other mod overwrote one of them. Mixin renames a merged handler to
     * handler$&lt;id&gt;$&lt;source name&gt;, so a call matches by its name ending in "$" + source name. A partial install must leave
     * the feature off: a deferred state without its resolving handlers would reach vanilla's sort with an empty point array.
     */
    public static boolean installed(ClassNode target) {
        for (String[] handler : HANDLERS) {
            boolean found = false;
            for (MethodNode method : target.methods) {
                if (!method.name.equals(handler[1]) && !method.name.equals(handler[2])) continue;
                for (AbstractInsnNode insn = method.instructions == null ? null : method.instructions.getFirst(); insn != null; insn = insn.getNext()) {
                    if (insn instanceof MethodInsnNode call && call.owner.equals(target.name)
                            && (call.name.equals(handler[0]) || call.name.endsWith("$" + handler[0]))) { found = true; break; }
                }
                if (found) break;
            }
            if (!found) return false;
        }
        for (MethodNode method : target.methods) {
            if (!bypassed(method.name)) continue;
            // Another mod's @Overwrite leaves no call to find, only its MixinMerged mark on the method.
            if (ModelDirectGate.foreign(method.visibleAnnotations) || ModelDirectGate.foreign(method.invisibleAnnotations)) return false;
            if (method.instructions == null) continue;
            for (AbstractInsnNode insn = method.instructions.getFirst(); insn != null; insn = insn.getNext())
                if (insn instanceof MethodInsnNode call && call.owner.equals(target.name) && foreign(call.name)) return false;
        }
        return true;
    }

    /** Methods whose body the fast path replaces (dev and SRG names). */
    private static final java.util.Set<String> BYPASSED = java.util.Set.of(
            "setQuadSorting", "m_277127_", "makeQuadSortingPoints", "m_166794_", "putSortedQuadIndices", "m_166786_",
            "getIntConsumer", "m_231158_");

    private static boolean bypassed(String name) {
        return BYPASSED.contains(name) || name.startsWith("lambda$getIntConsumer$") || name.startsWith("lambda$m_231158_$");
    }

    /** A merged injector method of some mixin that is not one of ours. */
    private static boolean foreign(String name) {
        if (!(name.startsWith("handler$") || name.startsWith("redirect$") || name.startsWith("modify") || name.startsWith("wrap")
                || name.startsWith("localvar$") || name.startsWith("constant$") || name.startsWith("args$"))
                || name.indexOf('$') < 0) return false;
        for (String[] handler : HANDLERS)
            if (name.equals(handler[0]) || name.endsWith("$" + handler[0])) return false;
        return true;
    }

    private QuadSortGate() {}
}
