package ru.pasha.pashaboost.mixin.client;

import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.pasha.pashaboost.core.ParticleLightShare;

/**
 * Every client block change goes through LevelChunk.setBlockState (ClientLevel.setBlock, section and block update
 * packets) or replaceWithPacketData (a resent chunk); both start a new shared particle light revision. Never gated.
 * The integrated server's chunks pass the same code and are ignored by isClientSide.
 */
// OptiFine I6 does not patch LevelChunk; Forge's has both methods (m_6978_, m_187971_).
// The level field is package-private, so it is read through the public getLevel (m_62953_ after reobf) instead of a
// shadow. require = 0.
@Mixin(value = LevelChunk.class, remap = false)
public abstract class ParticleLightChunkMixin {
    @Inject(method = {"setBlockState(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Z)Lnet/minecraft/world/level/block/state/BlockState;",
            "m_6978_(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Z)Lnet/minecraft/world/level/block/state/BlockState;"},
            at = @At("HEAD"), require = 0, remap = false)
    private void pashaboost$lightBlockSet(CallbackInfoReturnable<BlockState> cir) { pashaboost$bumpOnClient(); }

    @Inject(method = {"replaceWithPacketData(Lnet/minecraft/network/FriendlyByteBuf;Lnet/minecraft/nbt/CompoundTag;Ljava/util/function/Consumer;)V",
            "m_187971_(Lnet/minecraft/network/FriendlyByteBuf;Lnet/minecraft/nbt/CompoundTag;Ljava/util/function/Consumer;)V"},
            at = @At("HEAD"), require = 0, remap = false)
    private void pashaboost$lightChunkPacket(CallbackInfo ci) { pashaboost$bumpOnClient(); }

    @Unique
    private void pashaboost$bumpOnClient() {
        Level level = ((LevelChunk) (Object) this).getLevel();
        if (level != null && level.isClientSide) ParticleLightShare.bump();
    }
}
