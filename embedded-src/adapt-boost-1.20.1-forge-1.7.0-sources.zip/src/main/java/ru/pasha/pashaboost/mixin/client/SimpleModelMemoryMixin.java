package ru.pasha.pashaboost.mixin.client;

import com.mojang.logging.LogUtils;
import net.minecraft.client.resources.model.SimpleBakedModel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.pasha.pashaboost.memory.ModelSides;

/** Compact face lists of simple models, see ModelSides. Launch-time and earned only: see MemoryGate. */
// Forge chains vanilla's 8-argument constructor through a 9-argument one into this 10-argument one, the only one that
// sets the fields and the one the builder calls. A bare "<init>" selects only the first constructor in the class, the
// unused vanilla one, so 1.6.0 never compacted a model. require = 0 so a conflicting mod only disables this.
@Mixin(value = SimpleBakedModel.class, remap = false)
public abstract class SimpleModelMemoryMixin {
    /** One failure turns the saving off instead of breaking every model. */
    @Unique private static volatile boolean pashaboost$failed;

    @Inject(method = "<init>(Ljava/util/List;Ljava/util/Map;ZZZLnet/minecraft/client/renderer/texture/TextureAtlasSprite;"
            + "Lnet/minecraft/client/renderer/block/model/ItemTransforms;Lnet/minecraft/client/renderer/block/model/ItemOverrides;"
            + "Lnet/minecraftforge/client/RenderTypeGroup;Lnet/minecraftforge/client/RenderTypeGroup;)V",
            at = @At("TAIL"), require = 0, remap = false)
    private void pashaboost$compactFaces(CallbackInfo ci) {
        if (pashaboost$failed) return;
        try { ModelSides.compact((SimpleBakedModel) (Object) this); }
        catch (Throwable t) {
            pashaboost$failed = true;
            LogUtils.getLogger().warn("Adapt Boost stopped compacting model faces", t);
        }
    }
}
