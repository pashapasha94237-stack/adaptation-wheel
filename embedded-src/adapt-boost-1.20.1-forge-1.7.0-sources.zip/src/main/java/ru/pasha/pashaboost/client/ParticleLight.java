package ru.pasha.pashaboost.client;

import java.lang.reflect.Method;
import net.minecraft.client.particle.Particle;

/** Which particle classes use the base, position-only light lookup (OptiFine's version included). */
public final class ParticleLight {
    private static final ClassValue<Boolean> POSITIONAL = new ClassValue<>() {
        @Override protected Boolean computeValue(Class<?> type) {
            try {
                for (Class<?> k = type; k != null && k != Particle.class; k = k.getSuperclass())
                    for (Method m : k.getDeclaredMethods())
                        if ((m.getName().equals("getLightColor") || m.getName().equals("m_6355_"))
                                && m.getParameterCount() == 1 && m.getParameterTypes()[0] == float.class) return false;
                return true;
            } catch (Throwable unreadable) {
                return false;
            }
        }
    };
    /** True when the light can only change with the block position or the world's light, never with age or partial ticks. */
    public static boolean positional(Class<?> type) { return POSITIONAL.get(type); }
    private ParticleLight() {}
}
