package ru.pasha.pashaboost.mixin;

import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.levelgen.NoiseBasedChunkGenerator;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraftforge.server.ServerLifecycleHooks;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.pasha.pashaboost.OptimizationCounters;
import ru.pasha.pashaboost.PashaBoost;
import ru.pasha.pashaboost.RuntimeTuning;
import ru.pasha.pashaboost.core.DeferredSearch;
import ru.pasha.pashaboost.core.PupfishColumns;

/**
 * Alex's Mobs 1.22.8/1.22.9 AMWorldData: tickPupfish runs twice per dimension per server tick, and every 10th call builds a
 * whole NoiseChunk column (iterateNoiseColumn). The first PUPFISH_FREE_TRIES tries run at AM's own rate. After that,
 * uncached columns are capped per tick and the rest are deferred (same candidate order: a deferred try is cancelled
 * before pupfishSeedAddition++). Revisited columns are memoised, and the result AM forgets to mark dirty is persisted.
 * Plugin-gated to AM 1.22.8/1.22.9. Third-party target: remap=false, no refmap. Vanilla calls inside handler bodies
 * (setDirty -> m_77762_, getTickCount -> m_129921_) are remapped by reobfJar.
 */
@Mixin(targets = "com.github.alexthe666.alexsmobs.world.AMWorldData", remap = false)
public abstract class PupfishSearchMixin {
    @Unique private static final String AMWD = "Lcom/github/alexthe666/alexsmobs/world/AMWorldData;";
    @Unique private static final String WATER_HEIGHT = "getWaterHeight(Lnet/minecraft/world/level/levelgen/NoiseBasedChunkGenerator;"
            + "Lnet/minecraft/world/level/levelgen/RandomState;IILnet/minecraft/world/level/LevelHeightAccessor;)I";

    @Shadow(remap = false) private int pupfishSeedAddition;   // present in 1.22.8 and 1.22.9
    @Shadow(remap = false) private void searchForPupfishChunk() { throw new AssertionError("Mixin shadow"); }
    @Shadow(remap = false) public ChunkPos getPupfishChunk() { throw new AssertionError("Mixin shadow"); }

    @Unique private final DeferredSearch pashaboost$search = new DeferredSearch();
    @Unique private long pashaboost$searchStart = -1L;
    /** Set by the tail repay handler. Without it nothing is deferred, so a non-applied repay can never strand debt. */
    @Unique private boolean pashaboost$repayAlive;

    @Unique private static int pashaboost$serverTick() {
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        return server == null ? 0 : server.getTickCount();
    }
    @Unique private static boolean pashaboost$optimise() { return RuntimeTuning.ACTIVE && RuntimeTuning.PUPFISH_SEARCH; }

    // 1. Pay deferred tries at the END of AM's guarded body (restrictPupfishSpawns && !noPupfishChunk), never outside it.
    //    javap: the only PUTFIELD pupfishChunkTime in tickPupfish is @117 (1.22.9) and @34 (1.22.8). AM re-checks
    //    pupfishChunk on its next call, so a find made here can never be followed by another AM try.
    @Inject(method = "tickPupfish()V",
            at = @At(value = "FIELD", opcode = Opcodes.PUTFIELD, target = AMWD + "pupfishChunkTime:I", shift = At.Shift.AFTER),
            require = 0, remap = false)
    private void pashaboost$repay(CallbackInfo ci) {
        pashaboost$repayAlive = true;
        DeferredSearch s = pashaboost$search;
        if (s.owed() == 0) return;
        int tick = pashaboost$serverTick();
        int allowance = RuntimeTuning.PUPFISH_COLUMNS_PER_TICK;
        boolean optimise = pashaboost$optimise();
        while (getPupfishChunk() == null && s.mayPay(tick, allowance, optimise)) {
            s.pay();
            try { searchForPupfishChunk(); } finally { s.paid(); }
        }
        if (getPupfishChunk() != null) s.settle();
    }

    // 2. Over budget (after the free burst): cancel before pupfishSeedAddition++ and owe the try (candidate order unchanged).
    @Inject(method = "searchForPupfishChunk()V", at = @At("HEAD"), cancellable = true, require = 0, remap = false)
    private void pashaboost$admit(CallbackInfo ci) {
        DeferredSearch s = pashaboost$search;
        int before = s.owed();
        boolean optimise = pashaboost$repayAlive && pashaboost$optimise();
        if (!s.admit(pashaboost$serverTick(), RuntimeTuning.PUPFISH_COLUMNS_PER_TICK, optimise,
                     pupfishSeedAddition, RuntimeTuning.PUPFISH_FREE_TRIES)) {
            if (s.owed() != before) OptimizationCounters.pupfishTriesDeferred++;
            ci.cancel();
        }
    }

    // 3. 1.22.9 only: tickPupfish @32 (start stamp, ordinal 0) and @55 (elapsed check, ordinal 1). 1.22.8 has no
    //    currentTimeMillis in tickPupfish, so both redirects match nothing (require = 0).
    @Redirect(method = "tickPupfish()V",
              at = @At(value = "INVOKE", target = "Ljava/lang/System;currentTimeMillis()J", ordinal = 0), require = 0, remap = false)
    private long pashaboost$searchStarted() {
        long now = System.currentTimeMillis();
        pashaboost$searchStart = now;
        return now;
    }

    @Redirect(method = "tickPupfish()V",
              at = @At(value = "INVOKE", target = "Ljava/lang/System;currentTimeMillis()J", ordinal = 1), require = 0, remap = false)
    private long pashaboost$searchClock() {
        long now = System.currentTimeMillis();
        long start = pashaboost$searchStart;
        // Same arithmetic as AM: seconds = (now - start) / 1000; give up when seconds / 60 > 5.
        if (start != -1L && (now - start) / 1000L / 60L > 5L && pashaboost$search.holdLimit()) return start;
        return now;
    }

    // 4. Persist AM's own result. AM calls setDirty() only from get(), on the first lookup of a session.
    //    javap: searchForPupfishChunk @167 PUTFIELD pupfishChunk (both versions); tickPupfish @100 PUTFIELD noPupfishChunk (1.22.9).
    @Inject(method = "searchForPupfishChunk()V",
            at = @At(value = "FIELD", opcode = Opcodes.PUTFIELD,
                     target = AMWD + "pupfishChunk:Lnet/minecraft/world/level/ChunkPos;", shift = At.Shift.AFTER),
            require = 0, remap = false)
    private void pashaboost$found(CallbackInfo ci) { pashaboost$settled(false); }

    @Inject(method = "tickPupfish()V",
            at = @At(value = "FIELD", opcode = Opcodes.PUTFIELD, target = AMWD + "noPupfishChunk:Z", shift = At.Shift.AFTER),
            require = 0, remap = false)
    private void pashaboost$gaveUp(CallbackInfo ci) { pashaboost$settled(true); }

    @Unique private void pashaboost$settled(boolean gaveUp) {
        pashaboost$search.settle();
        PupfishColumns.release();
        if (RuntimeTuning.PUPFISH_SEARCH) {
            ((SavedData) (Object) this).setDirty();      // reobf -> m_77762_
            OptimizationCounters.pupfishResultsMarkedDirty++;
            if (gaveUp) PashaBoost.LOGGER.info(
                    "Alex's Mobs pupfish give-up will be saved; remove NoPupfishChunk from data/alexsmobs_world_data.dat to search again");
        }
    }

    // 5. Column memo (static single slot, weak owner). getWaterHeight's only caller is searchForPupfishChunk @145, and the
    //    level argument is always the overworld, so the value is a pure function of (RandomState, x, z).
    @Inject(method = WATER_HEIGHT, at = @At("HEAD"), cancellable = true, require = 0, remap = false)
    private void pashaboost$cachedHeight(NoiseBasedChunkGenerator generator, RandomState random, int x, int z,
                                         LevelHeightAccessor level, CallbackInfoReturnable<Integer> cir) {
        if (pashaboost$optimise()) {
            int h = PupfishColumns.get(random, x, z);
            if (h != PupfishColumns.MISSING) {
                OptimizationCounters.pupfishColumnsReused++;
                cir.setReturnValue(h);
                return;
            }
        }
        pashaboost$search.spend();   // one uncached noise column evaluated this tick
    }

    @Inject(method = WATER_HEIGHT, at = @At("RETURN"), require = 0, remap = false)
    private void pashaboost$rememberHeight(NoiseBasedChunkGenerator generator, RandomState random, int x, int z,
                                           LevelHeightAccessor level, CallbackInfoReturnable<Integer> cir) {
        if (RuntimeTuning.PUPFISH_SEARCH) PupfishColumns.put(random, x, z, cir.getReturnValueI());
    }
}
