package ru.pasha.pashaboost.client;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import ru.pasha.pashaboost.OptimizationCounters;
import ru.pasha.pashaboost.RuntimeTuning;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

/**
 * Mahou Tsukai draws its spell entities from RenderLevelStageEvent (AFTER_PARTICLES): each frame RenderUtils.entityRenders
 * took every client entity from ClientProxy.getAllEntities, which streams them into one HashSet and copies that into a
 * second, then tested each one against 18 of Mahou's entity classes. Only entities of those classes are handed over now,
 * in the order Mahou's copy would iterate them, so the loop draws the same entities in the same order.
 */
public final class MahouEntityScan {
    /** Every class RenderUtils.entityRenders tests with instanceof inside its loop (javap, 1.20.1-v1.34.81). All are classes. */
    private static final Set<String> DRAWN_CLASSES = Set.of(
            "stepsword.mahoutsukai.entity.fae.FaeEntity",
            "stepsword.mahoutsukai.entity.mahoujin.MysticStaffMahoujinEntity",
            "stepsword.mahoutsukai.entity.mahoujin.MysticStaffBeamMahoujinEntity",
            "stepsword.mahoutsukai.entity.GateChainEntity",
            "stepsword.mahoutsukai.entity.SmiteEntity",
            "stepsword.mahoutsukai.entity.MorganBallEntity",
            "stepsword.mahoutsukai.entity.mahoujin.AuthorityMahoujinEntity",
            "stepsword.mahoutsukai.entity.mahoujin.RhoAiasMahoujinEntity",
            "stepsword.mahoutsukai.entity.mahoujin.ReplicaTeleportMahoujinEntity",
            "stepsword.mahoutsukai.entity.mahoujin.GandrEntity",
            "stepsword.mahoutsukai.entity.mahoujin.FallenDownEntity",
            "stepsword.mahoutsukai.entity.mahoujin.FallenDownBeamEntity",
            "stepsword.mahoutsukai.entity.LightningEntity",
            "stepsword.mahoutsukai.entity.mahoujin.SpatialDisorientationMahoujinEntity",
            "stepsword.mahoutsukai.entity.mahoujin.BeamProjectileEntity",
            "stepsword.mahoutsukai.entity.mahoujin.MysticStaffAOEMahoujinEntity",
            "stepsword.mahoutsukai.entity.mahoujin.RhongomyniadEntity",
            "stepsword.mahoutsukai.entity.mahoujin.GunEntity");
    /** instanceof against a class: the class itself or one of its superclasses, so subclasses from add-ons count too. */
    private static final ClassValue<Boolean> DRAWN = new ClassValue<>() {
        @Override protected Boolean computeValue(Class<?> type) {
            for (Class<?> c = type; c != null; c = c.getSuperclass()) if (DRAWN_CLASSES.contains(c.getName())) return Boolean.TRUE;
            return Boolean.FALSE;
        }
    };
    /** Handed back when nothing is drawn; entityRenders only calls size() and iterator() on it. */
    private static final HashSet<Entity> NONE = new HashSet<>();
    /** java.util.HashMap.MIN_TREEIFY_CAPACITY: below it a 9-entry bin doubles the table instead of becoming a tree. */
    private static final int MIN_TREEIFY_CAPACITY = 64;

    public static HashSet<Entity> drawnEntities(ClientLevel level) {
        if (!RuntimeTuning.ACTIVE || !RuntimeTuning.MAHOU_ENTITY_SCAN) return everyEntity(level);
        int all = 0;
        ArrayList<Entity> drawn = null;
        // ClientLevel.entitiesForRendering() is getEntities().getAll() in Forge 47.4.0 and in OptiFine HD U I6 pre6 (both javap-checked).
        for (Entity entity : level.entitiesForRendering()) {
            all++;
            if (DRAWN.get(entity.getClass())) {
                if (drawn == null) drawn = new ArrayList<>(4);
                drawn.add(entity);
            }
        }
        if (drawn == null) {
            if (!NONE.isEmpty()) NONE.clear();
            OptimizationCounters.mahouEntitySetsAvoided++;
            return NONE;
        }
        int k = drawn.size();
        if (k == 1) {
            OptimizationCounters.mahouEntitySetsAvoided++;
            return new HashSet<>(drawn);
        }
        // Mahou's copy is new HashSet<>(firstSet): a table of this size, iterated by ascending bucket. Below 64 buckets a
        // collision of 9 can double that table (HashMap.treeifyBin), so tiny worlds (<= 23 entities) keep Mahou's computation.
        int table = tableSize(Math.max((int) (all / .75f) + 1, 16));
        if (table < MIN_TREEIFY_CAPACITY) return everyEntity(level);
        int mask = table - 1;
        int[] buckets = new int[k];
        for (int i = 0; i < k; i++) {          // insertion sort by bucket; two in one bucket: the order inside a bin is Mahou's
            Entity entity = drawn.get(i);
            int bucket = bucket(entity, mask);
            int j = i - 1;
            while (j >= 0 && buckets[j] > bucket) { buckets[j + 1] = buckets[j]; drawn.set(j + 1, drawn.get(j)); j--; }
            if (j >= 0 && buckets[j] == bucket) return everyEntity(level);
            buckets[j + 1] = bucket;
            drawn.set(j + 1, entity);
        }
        // A LinkedHashSet is a HashSet that iterates in insertion order, here Mahou's bucket order, without a table sized for every entity.
        LinkedHashSet<Entity> set = new LinkedHashSet<>(Math.max(2 * k, 16));
        set.addAll(drawn);
        OptimizationCounters.mahouEntitySetsAvoided++;
        return set;
    }

    /** Exactly ClientProxy.getAllEntities: ClientLevel.entitiesForRendering() is getEntities().getAll(). */
    private static HashSet<Entity> everyEntity(ClientLevel level) {
        return new HashSet<>(StreamSupport.stream(level.entitiesForRendering().spliterator(), false).collect(Collectors.toSet()));
    }
    /** java.util.HashMap.hash and the bucket it selects. */
    private static int bucket(Entity entity, int mask) { int h = entity.hashCode(); return (h ^ (h >>> 16)) & mask; }
    /** java.util.HashMap.tableSizeFor (JDK 17). */
    private static int tableSize(int capacity) {
        int n = -1 >>> Integer.numberOfLeadingZeros(capacity - 1);
        return n < 0 ? 1 : n >= 1 << 30 ? 1 << 30 : n + 1;
    }
    private MahouEntityScan() {}
}
