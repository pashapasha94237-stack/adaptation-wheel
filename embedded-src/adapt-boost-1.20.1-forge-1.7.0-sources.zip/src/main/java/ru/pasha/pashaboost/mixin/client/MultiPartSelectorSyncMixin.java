package ru.pasha.pashaboost.mixin.client;

import net.minecraft.client.resources.model.MultiPartBakedModel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.Map;

/**
 * A multipart model's selector cache is a plain hash map filled from the chunk-building threads. Once all states of a
 * block (and equal blocks) share one model it sees far more concurrent use, so reads and writes are synchronised,
 * as FerriteCore does. Forge routes every getQuads through getSelectors.
 */
@Mixin(value = MultiPartBakedModel.class, remap = false)
public abstract class MultiPartSelectorSyncMixin {
    @Redirect(method = "getSelectors(Lnet/minecraft/world/level/block/state/BlockState;)Ljava/util/BitSet;",
            at = @At(value = "INVOKE", target = "Ljava/util/Map;get(Ljava/lang/Object;)Ljava/lang/Object;"), require = 0, remap = false)
    private Object pashaboost$get(Map<Object, Object> cache, Object state) {
        synchronized (cache) { return cache.get(state); }
    }

    @Redirect(method = "getSelectors(Lnet/minecraft/world/level/block/state/BlockState;)Ljava/util/BitSet;",
            at = @At(value = "INVOKE", target = "Ljava/util/Map;put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;"), require = 0, remap = false)
    private Object pashaboost$put(Map<Object, Object> cache, Object state, Object selectors) {
        synchronized (cache) { return cache.put(state, selectors); }
    }
}
