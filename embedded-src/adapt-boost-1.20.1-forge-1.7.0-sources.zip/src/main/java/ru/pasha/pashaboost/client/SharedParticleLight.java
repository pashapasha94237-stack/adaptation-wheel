package ru.pasha.pashaboost.client;

import com.mojang.blaze3d.systems.RenderSystem;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import ru.pasha.pashaboost.OptimizationCounters;
import ru.pasha.pashaboost.PashaBoost;
import ru.pasha.pashaboost.RuntimeTuning;
import ru.pasha.pashaboost.core.ParticleLightShare;

import static ru.pasha.pashaboost.core.ParticleLightShare.OTHER;
import static ru.pasha.pashaboost.core.ParticleLightShare.UNCACHEABLE;
import static ru.pasha.pashaboost.core.ParticleLightShare.UNKNOWN;

/**
 * Particle light, shared by every particle in the same block. The cached function is exactly what Particle.getLightColor
 * calls: LevelRenderer.getLightColor(level, pos) = getLightColor(level, level.getBlockState(pos), pos) (m_109541_ is these
 * two calls on OptiFine I6 and on Forge). An entry is valid for one client world revision, bumped by every client block,
 * chunk and visible-light change. Inside one ParticleEngine.render pass nothing in the world changes, so any entry is
 * reused there. Vanilla air (AIR, CAVE_AIR, VOID_AIR: never emissive, no emission) depends only on the stored light,
 * so it is also reused across passes and frames while OptiFine dynamic lights are off and no other mod hooks the code
 * the hit skips. An air value computed while dynamic lights are on includes DynamicLights.getCombinedLight, and turning
 * the option off bumps nothing (Options only calls DynamicLights.removeLights), so it is stored as OTHER: this pass only.
 * Render thread only. Idea after Sodium's per-frame particle light caching (LGPL-3.0); own code.
 */
public final class SharedParticleLight {
    /** probeFull: the call site must not use or fill the table this time. */
    public static final long SKIP = -2L;
    /** probeFull: no entry; call getLightColor and hand the result to storeFull. */
    public static final long MISS = -1L;
    private static final ParticleLightShare.Table LIGHT = new ParticleLightShare.Table(), FULL = new ParticleLightShare.Table();
    private static final byte UNSET = 0, READY = 1, OFF = 2;
    private static byte state = UNSET;
    private static BlockState air, caveAir, voidAir;
    /** Cross-frame air reuse is allowed by the one-time checks (OptiFine resolved, no foreign hooks on skipped code). */
    private static boolean crossFrameStatic;
    /** Another mod hooks LevelRenderer.getLightColor: misses call m_109541_ itself and nothing is reused across passes. */
    private static boolean rendererForeign;
    /** The call-site fast path is allowed (no other mod hooks Particle.getLightColor or the call in SingleQuadParticle). */
    private static boolean fastPath;
    /** The m_6355_ redirect ran at least once with the feature on, so its tri-state reports are real. */
    private static boolean handlerSeen;
    private static Object lastLevel;
    private static long fullKey, fullRevision;
    private static int fullPass;

    /** Redirect of LevelRenderer.getLightColor(level, pos) inside Particle.getLightColor. */
    public static int light(BlockAndTintGetter getter, BlockPos pos) {
        ParticleLightShare.observed = UNCACHEABLE;
        if (!RuntimeTuning.ACTIVE || !RuntimeTuning.PARTICLE_LIGHT_SHARE || !RenderSystem.isOnRenderThread() || !ready())
            return LevelRenderer.getLightColor(getter, pos);
        int x = pos.getX(), y = pos.getY(), z = pos.getZ();
        if (getter != Minecraft.getInstance().level || !ParticleLightShare.inRange(x, y, z) || emissiveNow())
            return LevelRenderer.getLightColor(getter, pos);
        handlerSeen = true;
        sameLevel(getter);
        long key = ParticleLightShare.pack(x, y, z), revision = ParticleLightShare.revision();
        int pass = pass();
        int slot = LIGHT.find(key, revision);
        if (slot >= 0) {
            byte kind = LIGHT.kind(slot), reuse = ParticleLightShare.reuse(kind, LIGHT.pass(slot), pass);
            if (reuse == ParticleLightShare.REUSE_YES || reuse == ParticleLightShare.REUSE_IF_CROSS_AIR && crossFrameAir()) {
                OptimizationCounters.particleLightShared++;
                ParticleLightShare.observed = kind;
                return LIGHT.value(slot);
            }
        }
        int light;
        byte kind;
        if (rendererForeign) {
            light = LevelRenderer.getLightColor(getter, pos);
            kind = OTHER;
        } else {
            BlockState blockState = getter.getBlockState(pos);
            light = LevelRenderer.getLightColor(getter, blockState, pos);
            boolean isAir = blockState == air || blockState == caveAir || blockState == voidAir;
            kind = ParticleLightShare.lightKind(isAir, isAir && dynamicLightsOn());
        }
        OptimizationCounters.particleLightComputed++;
        if (ParticleLightShare.storable(kind, pass)) LIGHT.put(key, revision, pass, kind, light);
        ParticleLightShare.observed = kind;
        return light;
    }

    /**
     * SingleQuadParticle call site, for classes whose getLightColor is Particle's: the whole result for this block,
     * without the BlockPos, the hasChunkAt and the virtual call. SKIP, MISS (then call storeFull) or the light.
     */
    public static long probeFull(Object level, int x, int y, int z) {
        if (!RenderSystem.isOnRenderThread() || !ready() || !fastPath || !handlerSeen || !ParticleLightShare.inRange(x, y, z)
                || level != Minecraft.getInstance().level || emissiveNow()) return SKIP;
        sameLevel(level);
        long key = ParticleLightShare.pack(x, y, z), revision = ParticleLightShare.revision();
        int pass = pass();
        int slot = FULL.find(key, revision);
        if (slot >= 0) {
            byte reuse = ParticleLightShare.reuse(FULL.kind(slot), FULL.pass(slot), pass);
            if (reuse == ParticleLightShare.REUSE_YES || reuse == ParticleLightShare.REUSE_IF_CROSS_AIR && crossFrameAir())
                return FULL.value(slot) & 0xFFFFFFFFL;
        }
        fullKey = key;
        fullRevision = revision;
        fullPass = pass;
        ParticleLightShare.observed = UNKNOWN;
        return MISS;
    }

    /** After a MISS: keep the result as far as what the redirect reported allows. */
    public static void storeFull(int light) {
        byte kind = ParticleLightShare.fullKind(ParticleLightShare.observed, light);
        ParticleLightShare.observed = UNCACHEABLE;
        if (ParticleLightShare.storable(kind, fullPass)) FULL.put(fullKey, fullRevision, fullPass, kind, light);
    }

    /** ParticleEngine.setLevel: never gated. Drops the reference to the old level as well. */
    public static void levelChanged() {
        lastLevel = null;
        ParticleLightShare.bump();
    }

    private static void sameLevel(Object level) {
        if (level != lastLevel) {
            lastLevel = level;
            ParticleLightShare.bump();
        }
    }

    private static int pass() { return ParticleLightShare.passLive(ParticleLightShare.hooks) ? ParticleLightShare.currentPass : 0; }

    private static boolean crossFrameAir() {
        return crossFrameStatic && ParticleLightShare.invalidationLive(ParticleLightShare.hooks) && !dynamicLightsOn();
    }

    // OptiFine returns MAX_BRIGHTNESS while it draws emissive layers (isRenderEmissive && isMinecraftThread): bypass then.
    private static boolean emissiveNow() {
        MethodHandle handle = OptiFineSwitches.EMISSIVE;
        if (handle == null) return false;
        try { return (boolean) handle.invokeExact(); }
        catch (Throwable unexpected) { return true; }
    }

    // OptiFine's dynamic lights change in DynamicLights.update from setupRender, at most every 50 ms, not with a revision.
    private static boolean dynamicLightsOn() {
        MethodHandle handle = OptiFineSwitches.DYNAMIC_LIGHTS;
        if (handle == null) return false;
        try { return (boolean) handle.invokeExact(); }
        catch (Throwable unexpected) { return true; }
    }

    /**
     * OptiFine's two switches, resolved once when init() first touches this class (on the render thread, OptiFine loaded).
     * Static final, so the JIT treats each handle as a constant and inlines the call; from a plain static field every
     * invokeExact went through a generic invoker, 2.7 % of the OptiFine render thread in JFR. Null on plain Forge.
     */
    private static final class OptiFineSwitches {
        static final Class<?> CONFIG = find("net.optifine.Config"), EMISSIVE_TEXTURES = find("net.optifine.EmissiveTextures");
        static final MethodHandle EMISSIVE = staticBooleanOrNull(EMISSIVE_TEXTURES, "isRenderEmissive"),
                DYNAMIC_LIGHTS = staticBooleanOrNull(CONFIG, "isDynamicLights");
    }

    private static boolean ready() {
        byte current = state;
        return current == READY || current == UNSET && init();
    }

    /**
     * The call-site table can answer: switched on, started without error, its redirect merged into Particle (the plugin
     * skips it next to light engine and dynamic light mods) and no other mod on that call. Otherwise probeFull would only
     * ever SKIP, so QuadParticleLightMixin does not ask it.
     */
    public static boolean running() {
        return RuntimeTuning.ACTIVE && RuntimeTuning.PARTICLE_LIGHT_SHARE && RenderSystem.isOnRenderThread() && ready() && fastPath
                && (ParticleLightShare.hooks & ParticleLightShare.HOOK_LOOKUP) != 0;
    }

    private static boolean init() {
        try {
            air = Blocks.AIR.defaultBlockState();
            caveAir = Blocks.CAVE_AIR.defaultBlockState();
            voidAir = Blocks.VOID_AIR.defaultBlockState();
            boolean optiFine = ParticleLightShare.optiFine || OptiFineSwitches.CONFIG != null || OptiFineSwitches.EMISSIVE_TEXTURES != null;
            // Without the emissive switch a cached value could hide OptiFine's full-bright emissive pass: off.
            if (optiFine && OptiFineSwitches.EMISSIVE == null) return off("OptiFine without a readable EmissiveTextures");
            boolean dynamicResolved = !optiFine || OptiFineSwitches.DYNAMIC_LIGHTS != null;
            List<String> renderer = ForeignLightHooks.find("net.minecraft.client.renderer.LevelRenderer", false,
                    "m_109537_", "m_109541_", "getLightColor");
            // Alex's Caves 2.0.x: a HEAD hook on m_109537_ that acts only for EnergizedGalenaBlock and reads the same
            // light the same way (checked in its bytes); it never changes air and runs on every miss.
            renderer.remove("com.github.alexmodguy.alexscaves.mixin.client.LevelRendererMixin.ac_getLightColor");
            List<String> particle = ForeignLightHooks.find("net.minecraft.client.particle.Particle", false, "m_6355_", "getLightColor");
            particle.addAll(ForeignLightHooks.find("net.minecraft.client.particle.SingleQuadParticle", true, "m_6355_", "getLightColor"));
            List<String> world = worldHooks();
            rendererForeign = !renderer.isEmpty();
            fastPath = particle.isEmpty();
            crossFrameStatic = !rendererForeign && world.isEmpty() && dynamicResolved;
            state = READY;
            PashaBoost.LOGGER.info("Particle light share: optiFine={}, dynamicLightsReadable={}, crossFrameAir={}, callSite={}, hooks={}, "
                    + "foreign renderer={}, particle={}, world={}", optiFine, dynamicResolved, crossFrameStatic, fastPath,
                    Integer.toHexString(ParticleLightShare.hooks), renderer, particle, world);
            return true;
        } catch (Throwable unexpected) {
            PashaBoost.LOGGER.warn("Particle light share disabled", unexpected);
            state = OFF;
            return false;
        }
    }

    // Everything a cross-frame air hit skips besides LevelRenderer: block state, chunk presence, the light read and
    // the emission/emissive predicates of the state.
    private static List<String> worldHooks() {
        List<String> found = new ArrayList<>();
        String[] level = {"m_8055_", "getBlockState", "m_45517_", "getBrightness", "m_7232_", "hasChunk", "m_46805_", "m_151577_"};
        found.addAll(ForeignLightHooks.find("net.minecraft.client.multiplayer.ClientLevel", false, level));
        found.addAll(ForeignLightHooks.find("net.minecraft.world.level.Level", false, level));
        found.addAll(ForeignLightHooks.find("net.minecraft.world.level.chunk.LevelChunk", false, "m_8055_", "getBlockState"));
        found.addAll(ForeignLightHooks.find("net.minecraft.world.level.lighting.LevelLightEngine", false, "m_75814_", "getLayerListener"));
        found.addAll(ForeignLightHooks.find("net.minecraft.world.level.lighting.LightEngine", false, "m_7768_", "getLightValue"));
        String[] storage = {"m_6181_", "m_164457_", "m_75758_", "m_75761_", "getLightValue", "getDataLayer"};
        found.addAll(ForeignLightHooks.find("net.minecraft.world.level.lighting.LayerLightSectionStorage", false, storage));
        found.addAll(ForeignLightHooks.find("net.minecraft.world.level.lighting.SkyLightSectionStorage", false, storage));
        found.addAll(ForeignLightHooks.find("net.minecraft.world.level.lighting.BlockLightSectionStorage", false, storage));
        found.addAll(ForeignLightHooks.find("net.minecraft.world.level.block.state.BlockBehaviour$BlockStateBase", false,
                "m_60788_", "emissiveRendering", "m_60791_", "getLightEmission"));
        return found;
    }

    private static MethodHandle staticBooleanOrNull(Class<?> owner, String name) {
        if (owner == null) return null;
        MethodType type = MethodType.methodType(boolean.class);
        try {
            try { return MethodHandles.publicLookup().findStatic(owner, name, type); }
            // publicLookup needs an unconditional export of net.optifine; a full-privilege lookup also accepts a qualified one.
            catch (IllegalAccessException notPublic) { return MethodHandles.lookup().findStatic(owner, name, type); }
        } catch (ReflectiveOperationException | RuntimeException | LinkageError unreadable) {
            return null;
        }
    }

    private static boolean off(String reason) {
        PashaBoost.LOGGER.info("Particle light share off: {}", reason);
        state = OFF;
        return false;
    }

    private static Class<?> find(String name) {
        for (ClassLoader loader : new ClassLoader[]{SharedParticleLight.class.getClassLoader(), Thread.currentThread().getContextClassLoader()}) {
            if (loader == null) continue;
            try { return Class.forName(name, false, loader); }
            catch (ClassNotFoundException | LinkageError absent) {}
        }
        return null;
    }

    private SharedParticleLight() {}
}
