package ru.pasha.pashaboost.mixin.client;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.world.level.biome.Biome;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import ru.pasha.pashaboost.client.UniformBiomes;

/** Only the ambient-particle biome query of animateTick; other getBiome callers stay vanilla. */
// Each call site has a development and a production name; require = 0 so a conflicting mod only disables this.
@Mixin(value = ClientLevel.class, remap = false)
public abstract class AnimateTickBiomeMixin {
    @Redirect(method = {"doAnimateTick(IIIILnet/minecraft/util/RandomSource;Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos$MutableBlockPos;)V",
            "m_233612_(IIIILnet/minecraft/util/RandomSource;Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos$MutableBlockPos;)V"},
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/ClientLevel;getBiome(Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/Holder;", remap = false),
            require = 0, remap = false)
    private Holder<Biome> pashaboost$namedBiome(ClientLevel level, BlockPos pos) { return UniformBiomes.biome(level, pos); }

    @Redirect(method = {"doAnimateTick(IIIILnet/minecraft/util/RandomSource;Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos$MutableBlockPos;)V",
            "m_233612_(IIIILnet/minecraft/util/RandomSource;Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos$MutableBlockPos;)V"},
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/ClientLevel;m_204166_(Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/Holder;", remap = false),
            require = 0, remap = false)
    private Holder<Biome> pashaboost$srgBiome(ClientLevel level, BlockPos pos) { return UniformBiomes.biome(level, pos); }
}
