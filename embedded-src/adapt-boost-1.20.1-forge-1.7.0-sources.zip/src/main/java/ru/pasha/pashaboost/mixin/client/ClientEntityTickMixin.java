package ru.pasha.pashaboost.mixin.client;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.pasha.pashaboost.RuntimeTuning;
import ru.pasha.pashaboost.client.EntityOptimizer;

/**
 * The client ticked every loaded mob each game tick, along with every mod's tick handler for it, even mobs too far
 * away to be drawn. Those now tick every fourth game tick; see EntityOptimizer.skipClientTick for who is exempt.
 */
// Each method has a development and a production name; require = 0 so a conflicting mod only disables this.
@Mixin(value = ClientLevel.class, remap = false)
public abstract class ClientEntityTickMixin {
    @Inject(method = {"tickNonPassenger(Lnet/minecraft/world/entity/Entity;)V", "m_104639_(Lnet/minecraft/world/entity/Entity;)V"},
            at = @At("HEAD"), cancellable = true, require = 0, remap = false)
    private void pashaboost$throttleDistantTick(Entity entity, CallbackInfo ci) {
        if (RuntimeTuning.ACTIVE && EntityOptimizer.skipClientTick(entity)) ci.cancel();
    }
}
