package ru.pasha.pashaboost.mixin.client;

import net.minecraft.client.multiplayer.ClientChunkCache;
import net.minecraft.world.level.chunk.LevelChunk;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.pasha.pashaboost.core.ParticleLightShare;

/**
 * Which chunk a client block position reads (a real chunk or the empty one, whose blocks are VOID_AIR) changes only
 * where ClientChunkCache writes its Storage: drop, replaceWithPacketData, updateViewCenter, updateViewRadius (and the
 * constructor, which comes with a new level). Each starts a new shared particle light revision. Never gated.
 */
// Same four methods in OptiFine I6's patched ClientChunkCache and in Forge's; the Storage writes are only there.
// require = 0.
@Mixin(value = ClientChunkCache.class, remap = false)
public abstract class ParticleLightChunkCacheMixin {
    @Inject(method = {"drop(II)V", "m_104455_(II)V"}, at = @At("HEAD"), require = 0, remap = false)
    private void pashaboost$lightChunkDrop(CallbackInfo ci) { ParticleLightShare.bump(); }

    @Inject(method = {"replaceWithPacketData(IILnet/minecraft/network/FriendlyByteBuf;Lnet/minecraft/nbt/CompoundTag;Ljava/util/function/Consumer;)Lnet/minecraft/world/level/chunk/LevelChunk;",
            "m_194116_(IILnet/minecraft/network/FriendlyByteBuf;Lnet/minecraft/nbt/CompoundTag;Ljava/util/function/Consumer;)Lnet/minecraft/world/level/chunk/LevelChunk;"},
            at = @At("HEAD"), require = 0, remap = false)
    private void pashaboost$lightChunkReplace(CallbackInfoReturnable<LevelChunk> cir) { ParticleLightShare.bump(); }

    @Inject(method = {"updateViewCenter(II)V", "m_104459_(II)V"}, at = @At("HEAD"), require = 0, remap = false)
    private void pashaboost$lightViewCenter(CallbackInfo ci) { ParticleLightShare.bump(); }

    @Inject(method = {"updateViewRadius(I)V", "m_104416_(I)V"}, at = @At("HEAD"), require = 0, remap = false)
    private void pashaboost$lightViewRadius(CallbackInfo ci) { ParticleLightShare.bump(); }
}
