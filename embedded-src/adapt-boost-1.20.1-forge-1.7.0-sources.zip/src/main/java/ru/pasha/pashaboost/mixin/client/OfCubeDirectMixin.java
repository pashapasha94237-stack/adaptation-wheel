package ru.pasha.pashaboost.mixin.client;

import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.SpriteCoordinateExpander;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.optifine.render.VertexPosition;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.pasha.pashaboost.OptimizationCounters;
import ru.pasha.pashaboost.RuntimeTuning;
import ru.pasha.pashaboost.client.CubeShape;
import ru.pasha.pashaboost.client.ModelCubeDirect;
import ru.pasha.pashaboost.client.ModelDirectGate;
import ru.pasha.pashaboost.client.OfCubeWriter;
import ru.pasha.pashaboost.client.OfSpriteExpander;

/**
 * OptiFine I6's Cube.compile already transforms each distinct corner once, then hands every vertex of the cube to
 * VertexConsumer.addVertexFast, an interface call the JIT does not inline. When the consumer is a plain BufferBuilder, or a
 * SpriteCoordinateExpander over one, the whole cube is written in one call with the same stores in the same order.
 * Same goal as Embeddium's model cuboid fast path (LGPL-3.0); own code, built on OptiFine's own fast-vertex contract.
 */
// OptiFine I6 only. compile(...VertexPosition[][]) and canAddVertexFast are OptiFine's names, the same in development and
// production, so each selector has one entry. Injected before the single canAddVertexFast call (bytecode 62), after the
// corner loop. require = 0 so a conflicting mod only disables this; anything not handled returns to OptiFine's code.
@Mixin(value = ModelPart.Cube.class, remap = false)
public abstract class OfCubeDirectMixin {
    @Unique private CubeShape pashaboost$shape;

    @Inject(method = "compile(Lcom/mojang/blaze3d/vertex/PoseStack$Pose;Lcom/mojang/blaze3d/vertex/VertexConsumer;IIFFFF[[Lnet/optifine/render/VertexPosition;)V",
            at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/VertexConsumer;canAddVertexFast()Z", ordinal = 0, remap = false),
            cancellable = true, require = 0, remap = false)
    private void pashaboost$direct(PoseStack.Pose pose, VertexConsumer consumer, int light, int overlay, float red, float green,
                                   float blue, float alpha, VertexPosition[][] positions, CallbackInfo ci) {
        // Velocity positions come with shaders. The gate flags say the plugin found no other mod's code in the bypassed methods.
        if (!RuntimeTuning.ACTIVE || !RuntimeTuning.MODEL_DIRECT || positions != null
                || !ModelDirectGate.cubeClean || !ModelDirectGate.writerClean) return;
        OfCubeWriter writer;
        TextureAtlasSprite sprite = null;
        // Exact classes only: other wrappers, multi-consumers and subclasses keep OptiFine's path.
        Class<?> type = consumer.getClass();
        if (type == BufferBuilder.class) writer = (OfCubeWriter) consumer;
        else if (type == SpriteCoordinateExpander.class) {
            if (!RuntimeTuning.MODEL_DIRECT_SPRITE || !ModelDirectGate.spriteClean || !(consumer instanceof OfSpriteExpander expander)) return;
            VertexConsumer delegate = expander.pashaboost$delegate();
            sprite = expander.pashaboost$sprite();
            if (delegate == null || sprite == null || delegate.getClass() != BufferBuilder.class) return;
            writer = (OfCubeWriter) delegate;
        } else return;
        // With shaders addVertexFast also calls SVertexBuilder.endAddVertex. The wrapper's canAddVertexFast is its delegate's.
        if (!ModelCubeDirect.ready() || ModelCubeDirect.shaders() || !writer.pashaboost$canAddVertexFast()) return;
        CubeShape shape = this.pashaboost$shape;
        if (shape == null || !shape.matches()) {
            if (shape == CubeShape.FAILED) return;
            this.pashaboost$shape = shape = ModelCubeDirect.shapeOf((ModelPart.Cube) (Object) this);
            if (shape == CubeShape.FAILED) return;
        }
        // compile computes the colour per polygon from the same four floats; once gives the same value.
        if (writer.pashaboost$emitCube(shape, pose.normal(), CubeShape.color(red, green, blue, alpha), overlay, light, sprite)) {
            if (sprite == null) OptimizationCounters.modelCubesDirect++;
            else OptimizationCounters.modelSpriteCubesDirect++;
            ci.cancel();
        } else OptimizationCounters.modelCubeFallbacks++;
    }
}
