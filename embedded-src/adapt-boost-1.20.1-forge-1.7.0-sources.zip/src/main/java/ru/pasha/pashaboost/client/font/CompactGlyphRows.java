/*
 * Derived from ModernFix CompactUnihexContents by embeddedt and contributors.
 * Copyright (c) 2022 ModernFix contributors.
 * SPDX-License-Identifier: LGPL-3.0-or-later
 *
 * Pasha Boost changes, 2026-10-20: validate input and row bounds, add lossless
 * 24/32-bit rows, remove debug-only reflection, and document memory estimates.
 * Original flattened-field idea credited by ModernFix to @AnAwesomGuy.
 * Full licenses and corresponding source are supplied with this distribution.
 */
package ru.pasha.pashaboost.client.font;

import net.minecraft.client.gui.font.providers.UnihexProvider;

import java.util.Objects;

/** Immutable glyph rows that keep primitive fields instead of a separate array. */
public final class CompactGlyphRows {
    private CompactGlyphRows() {}

    private static void requireRows(int length) {
        if (length != 16) throw new IllegalArgumentException("A Unihex glyph must have exactly 16 rows");
    }

    private static void checkRow(int row) {
        if (row < 0 || row >= 16) throw new ArrayIndexOutOfBoundsException(row);
    }

    private static long packBytes(byte[] rows, int offset) {
        long packed = 0;
        for (int index = 0; index < 8; index++)
            packed |= ((long) rows[offset + index] & 0xffL) << (index * 8);
        return packed;
    }

    private static long packShorts(short[] rows, int offset) {
        long packed = 0;
        for (int index = 0; index < 4; index++)
            packed |= ((long) rows[offset + index] & 0xffffL) << (index * 16);
        return packed;
    }

    private static long packInts(int[] rows, int offset) {
        return Integer.toUnsignedLong(rows[offset]) | (Integer.toUnsignedLong(rows[offset + 1]) << 32);
    }

    /**
     * Conservative structural estimate for HotSpot with compressed references and
     * eight-byte object alignment. This is not a heap measurement or an FPS gain:
     * byte/short records lose one array header; int records also lose a reference.
     */
    public static int estimatedSavedBytes(int bitWidth) {
        return switch (bitWidth) {
            case 8, 16 -> 16;
            case 24, 32 -> 24;
            default -> throw new IllegalArgumentException("Unsupported Unihex width: " + bitWidth);
        };
    }

    public static final class Bytes implements UnihexProvider.LineData {
        private final long rows0, rows8;

        public Bytes(byte[] rows) {
            Objects.requireNonNull(rows, "rows");
            requireRows(rows.length);
            rows0 = packBytes(rows, 0);
            rows8 = packBytes(rows, 8);
        }

        @Override public int line(int row) {
            checkRow(row);
            long packed = row < 8 ? rows0 : rows8;
            return (int) ((packed >>> ((row & 7) * 8)) & 0xffL) << 24;
        }

        @Override public int bitWidth() { return 8; }
    }

    public static final class Shorts implements UnihexProvider.LineData {
        private final long rows0, rows4, rows8, rows12;

        public Shorts(short[] rows) {
            Objects.requireNonNull(rows, "rows");
            requireRows(rows.length);
            rows0 = packShorts(rows, 0);
            rows4 = packShorts(rows, 4);
            rows8 = packShorts(rows, 8);
            rows12 = packShorts(rows, 12);
        }

        @Override public int line(int row) {
            checkRow(row);
            long packed = switch (row >>> 2) {
                case 0 -> rows0;
                case 1 -> rows4;
                case 2 -> rows8;
                default -> rows12;
            };
            return (int) ((packed >>> ((row & 3) * 16)) & 0xffffL) << 16;
        }

        @Override public int bitWidth() { return 16; }
    }

    /** Input rows already use vanilla's left alignment, including its 24-bit path. */
    public static final class Ints implements UnihexProvider.LineData {
        private final long rows0, rows2, rows4, rows6, rows8, rows10, rows12, rows14;
        private final int width;

        public Ints(int[] rows, int bitWidth) {
            Objects.requireNonNull(rows, "rows");
            requireRows(rows.length);
            if (bitWidth != 24 && bitWidth != 32)
                throw new IllegalArgumentException("Int glyph width must be 24 or 32");
            rows0 = packInts(rows, 0);
            rows2 = packInts(rows, 2);
            rows4 = packInts(rows, 4);
            rows6 = packInts(rows, 6);
            rows8 = packInts(rows, 8);
            rows10 = packInts(rows, 10);
            rows12 = packInts(rows, 12);
            rows14 = packInts(rows, 14);
            width = bitWidth;
        }

        @Override public int line(int row) {
            checkRow(row);
            long packed = switch (row >>> 1) {
                case 0 -> rows0;
                case 1 -> rows2;
                case 2 -> rows4;
                case 3 -> rows6;
                case 4 -> rows8;
                case 5 -> rows10;
                case 6 -> rows12;
                default -> rows14;
            };
            return (int) (packed >>> ((row & 1) * 32));
        }

        @Override public int bitWidth() { return width; }
    }
}
