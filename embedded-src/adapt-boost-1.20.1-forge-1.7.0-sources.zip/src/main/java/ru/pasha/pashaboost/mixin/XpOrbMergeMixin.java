package ru.pasha.pashaboost.mixin;

import net.minecraft.world.entity.ExperienceOrb;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.pasha.pashaboost.OptimizationCounters;
import ru.pasha.pashaboost.RuntimeTuning;

/**
 * Idea from Clumps (MIT): mob farms leave hundreds of experience orbs, each one an entity to tick, sync and draw.
 * Vanilla already merges touching orbs of the same value into one orb with a count, but only when their ids agree
 * modulo 40, so most never merge. That lottery is dropped. Unlike Clumps, orbs of different values stay apart, so
 * pickup, Mending and the XP events see exactly the vanilla orbs, one value per touch.
 */
// Both names; require = 0 so a conflicting mod only disables this. The plugin skips it when Clumps is installed.
@Mixin(value = ExperienceOrb.class, remap = false)
public abstract class XpOrbMergeMixin {
    @Inject(method = {"canMerge(Lnet/minecraft/world/entity/ExperienceOrb;II)Z", "m_147088_(Lnet/minecraft/world/entity/ExperienceOrb;II)Z"},
            at = @At("HEAD"), cancellable = true, require = 0, remap = false)
    private static void pashaboost$mergeSameValue(ExperienceOrb orb, int id, int value, CallbackInfoReturnable<Boolean> cir) {
        if (!RuntimeTuning.ACTIVE || !RuntimeTuning.XP_ORB_MERGE) return;
        boolean merge = !orb.isRemoved() && orb.getValue() == value;
        if (merge && (orb.getId() - id) % 40 != 0) OptimizationCounters.xpOrbsMerged++;
        cir.setReturnValue(merge);
    }
}
