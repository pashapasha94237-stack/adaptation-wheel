package ru.pasha.pashaboost.memory;

import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import net.minecraft.util.Mth;
import net.minecraft.world.level.block.state.properties.Property;
import org.jetbrains.annotations.Nullable;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * All states of one block in one array, indexed by bit fields: each property owns the bits of its value index. Vanilla
 * gives every state its own neighbour table (property, value) to state, which for a big modpack is hundreds of
 * thousands of tables. Here a neighbour is the state at the index with one bit field replaced.
 * Ported from FerriteCore 6.0.1 by malte0811 (MIT, see THIRD-PARTY.md); only the binary key layout is kept.
 */
public final class FastMap<S> {
    private final List<Key<?>> keys;
    private final List<S> values;
    private final Object2IntMap<Property<?>> keyIndex;
    private final ImmutableSet<Property<?>> propertySet;

    public FastMap(Collection<Property<?>> properties, Map<Map<Property<?>, Comparable<?>>, S> statesByValues) {
        List<Key<?>> keys = new ArrayList<>(properties.size());
        keyIndex = new Object2IntOpenHashMap<>();
        keyIndex.defaultReturnValue(-1);
        int size = 1;
        for (Property<?> property : properties) {
            keyIndex.put(property, keys.size());
            Key<?> key = new Key<>(property, size);
            keys.add(key);
            size *= key.factorToNext();
        }
        this.keys = ImmutableList.copyOf(keys);
        List<S> values = new ArrayList<>(Collections.nCopies(size, null));
        for (Map.Entry<Map<Property<?>, Comparable<?>>, S> state : statesByValues.entrySet()) values.set(indexOf(state.getKey()), state.getValue());
        this.values = Collections.unmodifiableList(values);
        this.propertySet = ImmutableSet.copyOf(properties);
    }

    /** The state that differs from the one at oldIndex only in property, or null when there is none. */
    public <T extends Comparable<T>> @Nullable S with(int oldIndex, Property<T> property, T value) {
        Key<T> key = keyFor(property);
        if (key == null) return null;
        int newIndex = key.replaceIn(oldIndex, value);
        return newIndex < 0 ? null : values.get(newIndex);
    }

    /** Like vanilla's neighbour table, a value of the wrong type has no neighbour instead of failing a cast. */
    @SuppressWarnings({"unchecked", "rawtypes"})
    public @Nullable S withUnsafe(int oldIndex, Property<?> property, @Nullable Object value) {
        return property.getValueClass().isInstance(value) ? (S) with(oldIndex, (Property) property, (Comparable) value) : null;
    }

    public int indexOf(Map<Property<?>, Comparable<?>> state) {
        int index = 0;
        for (Key<?> key : keys) index += key.toPartialIndex(state.get(key.property()));
        return index;
    }

    public <T extends Comparable<T>> @Nullable T getValue(int stateIndex, Property<T> property) {
        Key<T> key = keyFor(property);
        return key == null ? null : key.getValue(stateIndex);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public @Nullable Comparable<?> getValue(int stateIndex, Object property) {
        return property instanceof Property p ? getValue(stateIndex, p) : null;
    }

    public Map.Entry<Property<?>, Comparable<?>> entry(int keyIndex, int stateIndex) {
        Key<?> key = keys.get(keyIndex);
        return new AbstractMap.SimpleImmutableEntry<>(key.property(), key.getValue(stateIndex));
    }

    public int numProperties() { return keys.size(); }
    public Key<?> key(int keyIndex) { return keys.get(keyIndex); }
    public boolean isSingleState() { return values.size() == 1; }
    public ImmutableSet<Property<?>> propertySet() { return propertySet; }

    @SuppressWarnings("unchecked")
    private <T extends Comparable<T>> @Nullable Key<T> keyFor(Property<T> property) {
        int index = keyIndex.getInt(property);
        return index == -1 ? null : (Key<T>) keys.get(index);
    }

    /** One property's bit field inside a state index. */
    public static final class Key<T extends Comparable<T>> {
        private final PropertyIndexer<T> indexer;
        private final byte firstBit, firstBitAfter;

        Key(Property<T> property, int factorBefore) {
            indexer = PropertyIndexer.of(property);
            Preconditions.checkArgument(Mth.isPowerOfTwo(factorBefore));
            int factor = Mth.smallestEncompassingPowerOfTwo(indexer.numValues());
            int bitsBefore = Mth.log2(factorBefore), bits = Mth.log2(factor);
            Preconditions.checkState(bitsBefore + bits <= 31, "Too many states for one block");
            firstBit = (byte) bitsBefore;
            firstBitAfter = (byte) (bitsBefore + bits);
        }

        public Property<T> property() { return indexer.property(); }
        public int numValues() { return indexer.numValues(); }
        public T getValue(int stateIndex) { return indexer.byIndex((stateIndex & lowestBits(firstBitAfter)) >>> firstBit); }

        int replaceIn(int stateIndex, T value) {
            int partial = toPartialIndex(value);
            if (partial < 0) return -1;
            int keep = ~lowestBits(firstBitAfter) | lowestBits(firstBit);
            return (stateIndex & keep) | partial;
        }

        @SuppressWarnings("unchecked")
        int toPartialIndex(Comparable<?> value) {
            int index = indexer.toIndex((T) value);
            return index >= 0 && index < indexer.numValues() ? index << firstBit : -1;
        }

        int factorToNext() { return 1 << (firstBitAfter - firstBit); }
        private static int lowestBits(int n) { return n >= 32 ? -1 : (1 << n) - 1; }
    }
}
