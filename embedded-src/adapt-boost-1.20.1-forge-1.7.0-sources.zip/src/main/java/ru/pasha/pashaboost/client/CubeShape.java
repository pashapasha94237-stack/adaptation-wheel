package ru.pasha.pashaboost.client;

import org.joml.Vector3f;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;

/**
 * Per model cube, what OptiFine's Cube.compile reaches through fields it cannot change after construction: the polygon
 * array (a final field), a copy of its elements, and per polygon its vertex array and normal vector (final fields of the
 * polygon). Everything mutable is still read live on every call: the array elements (compared with the copy), the
 * vertices in each vertex array, their u, v and render positions, and the components of every vector.
 */
public final class CubeShape {
    /** Reads the two final fields of one polygon. */
    public interface PolygonReader {
        Object[] vertices(Object polygon) throws ReflectiveOperationException;
        Vector3f normal(Object polygon) throws ReflectiveOperationException;
    }

    /** A cube whose shape could not be read: it always takes OptiFine's own path. */
    public static final CubeShape FAILED = new CubeShape(null, new Object[0], new Object[0][], new Vector3f[0]);

    private final Object[] polygons, snapshot;
    /** Per polygon slot: its vertex array and its normal, both null for an empty slot (OptiFine skips those). */
    public final Object[][] vertices;
    public final Vector3f[] normals;

    private CubeShape(Object[] polygons, Object[] snapshot, Object[][] vertices, Vector3f[] normals) {
        this.polygons = polygons;
        this.snapshot = snapshot;
        this.vertices = vertices;
        this.normals = normals;
    }

    /** {@code polygons} is the cube's own array object, so later element writes are seen by {@link #matches()}. */
    public static CubeShape of(Object[] polygons, PolygonReader reader) {
        if (polygons == null) return FAILED;
        Object[] snapshot = polygons.clone();
        Object[][] vertices = new Object[snapshot.length][];
        Vector3f[] normals = new Vector3f[snapshot.length];
        try {
            for (int i = 0; i < snapshot.length; i++) {
                Object polygon = snapshot[i];
                if (polygon == null) continue;
                Object[] polygonVertices = reader.vertices(polygon);
                Vector3f normal = reader.normal(polygon);
                // OptiFine would throw on these; leave that to its own code.
                if (polygonVertices == null || normal == null) return FAILED;
                vertices[i] = polygonVertices;
                normals[i] = normal;
            }
        } catch (ReflectiveOperationException | RuntimeException unexpected) {
            return FAILED;
        }
        return new CubeShape(polygons, snapshot, vertices, normals);
    }

    /** The cube still holds the very polygons this shape was read from, in the same slots. */
    public boolean matches() {
        Object[] live = polygons, copy = snapshot;
        if (live == null || live.length != copy.length) return false;
        for (int i = 0; i < copy.length; i++) if (live[i] != copy[i]) return false;
        return true;
    }

    /** OptiFine I6 MathUtils.getTransformX/Y/Z(Matrix3f, x, y, z): m0 * x + m1 * y, then + m2 * z (fmul fmul fadd fmul fadd). */
    public static float transform(float m0, float m1, float m2, float x, float y, float z) {
        return m0 * x + m1 * y + m2 * z;
    }

    /** Cube.compile bytecode 197-253: f2i of each channel times 255, shifted and or-ed without masking. */
    public static int color(float red, float green, float blue, float alpha) {
        return (int) (alpha * 255.0F) << 24 | (int) (blue * 255.0F) << 16 | (int) (green * 255.0F) << 8 | (int) (red * 255.0F);
    }

    /** Cube.compile bytecode 276-302: the three normalIntValue bytes masked to 8 bits, z high, x low. */
    public static int packNormal(byte x, byte y, byte z) {
        return (z & 255) << 16 | (y & 255) << 8 | x & 255;
    }

    /** OptiFine I6 BufferBuilder.addVertexFast bytecode 0-139: nine 4-byte slots starting at int index {@code ix}. */
    public static void putVertex(FloatBuffer floats, IntBuffer ints, int ix, float x, float y, float z, int color, float u, float v,
                                 int overlay, int light, int normal) {
        floats.put(ix, x);
        floats.put(ix + 1, y);
        floats.put(ix + 2, z);
        ints.put(ix + 3, color);
        floats.put(ix + 4, u);
        floats.put(ix + 5, v);
        ints.put(ix + 6, overlay);
        ints.put(ix + 7, light);
        ints.put(ix + 8, normal);
    }
}
