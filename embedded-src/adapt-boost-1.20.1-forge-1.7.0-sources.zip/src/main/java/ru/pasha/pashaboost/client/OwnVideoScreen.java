package ru.pasha.pashaboost.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.GraphicsStatus;
import net.minecraft.client.OptionInstance;
import net.minecraft.client.Options;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Renderable;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.ConfirmScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.GpuWarnlistManager;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

import java.util.ArrayList;
import java.util.List;

/**
 * Original layout over Minecraft's own option controls. Deliberately depends only on
 * Screen: other mods may replace the video-settings class and its inheritance tree.
 */
public final class OwnVideoScreen extends Screen {
    private static final int ACCENT = 0xFF67D9BD;
    private static final int TEXT = 0xFFE5F1ED;
    private static final int MUTED = 0xFFA4B7B0;
    private static final String[] TABS = {"world", "quality", "display"};
    private final Screen returnScreen;
    private final Options videoOptions;
    private final GpuWarnlistManager graphicsWarnings;
    private final List<AbstractWidget> optionControls = new ArrayList<>();
    private int tab, page, pages = 1;
    private int panelLeft, panelTop, panelWidth, panelBottom, guiScale;
    private int appliedMipmaps;
    private boolean warningOpen, hasNativeSettings;

    public OwnVideoScreen(Screen parent, Options options) {
        super(Component.translatable("pashaboost.video.title"));
        returnScreen = parent;
        videoOptions = options;
        appliedMipmaps = videoOptions.mipmapLevels().get();
        graphicsWarnings = Minecraft.getInstance().getGpuWarnlistManager();
        graphicsWarnings.resetWarnings();
        if (videoOptions.graphicsMode().get() == GraphicsStatus.FABULOUS) graphicsWarnings.dismissWarning();
    }

    @Override
    protected void init() {
        optionControls.clear();
        panelWidth = Math.min(580, width - 20);
        int panelHeight = Math.min(310, height - 20);
        panelLeft = (width - panelWidth) / 2;
        panelTop = (height - panelHeight) / 2;
        panelBottom = panelTop + panelHeight;
        guiScale = videoOptions.guiScale().get();
        hasNativeSettings = VideoCompatibility.isOptiFinePresent();

        int innerWidth = panelWidth - 24;
        int tabWidth = (innerWidth - 8) / 3;
        for (int index = 0; index < TABS.length; index++) {
            int selectedTab = index;
            FlatButton button = new FlatButton(panelLeft + 12 + index * (tabWidth + 4), panelTop + 48,
                    tabWidth, 22, Component.translatable("pashaboost.video.tab." + TABS[index]),
                    pressed -> { tab = selectedTab; page = 0; rebuildWidgets(); }, index == tab);
            button.active = index != tab;
            addRenderableWidget(button);
        }

        int columns = panelWidth >= 300 ? 2 : 1;
        int columnWidth = (innerWidth - (columns - 1) * 10) / columns;
        int controlsTop = panelTop + 96;
        int footerTop = panelBottom - (hasNativeSettings ? 54 : 30);
        int rows = Math.max(1, Math.min(3, (footerTop - controlsTop + 2) / 30));
        int capacity = rows * columns;
        List<OptionInstance<?>> settings = settings();
        pages = Math.max(1, (settings.size() + capacity - 1) / capacity);
        page = Math.max(0, Math.min(page, pages - 1));
        for (int index = 0; index < capacity && page * capacity + index < settings.size(); index++) {
            OptionInstance<?> option = settings.get(page * capacity + index);
            AbstractWidget control = option.createButton(videoOptions,
                    panelLeft + 12 + (index % columns) * (columnWidth + 10),
                    controlsTop + (index / columns) * 30, columnWidth);
            optionControls.add(addRenderableWidget(control));
        }
        if (pages > 1) {
            addRenderableWidget(new FlatButton(panelLeft + panelWidth - 57, panelTop + 76, 20, 14,
                    Component.literal("<"), button -> turnPage(-1), false));
            addRenderableWidget(new FlatButton(panelLeft + panelWidth - 33, panelTop + 76, 20, 14,
                    Component.literal(">"), button -> turnPage(1), false));
        }

        if (hasNativeSettings) {
            FlatButton advanced = new FlatButton(panelLeft + 12, footerTop, innerWidth, 20,
                    Component.translatable("pashaboost.video.advanced"), button -> {
                        videoOptions.save();
                        VideoSettingsHook.openNative(this);
                    }, false);
            advanced.setTooltip(Tooltip.create(Component.translatable("pashaboost.video.advanced.tip")));
            addRenderableWidget(advanced);
        }

        int doneWidth = Math.min(104, (innerWidth - 8) / 3);
        int mainFooterTop = panelBottom - 30;
        FlatButton performance = new FlatButton(panelLeft + 12, mainFooterTop, innerWidth - doneWidth - 8, 20,
                Component.translatable("pashaboost.video.performance"), button -> {
                    videoOptions.save();
                    minecraft.setScreen(new BoostScreen(this));
                }, true);
        performance.setTooltip(Tooltip.create(Component.translatable("pashaboost.video.performance.tip")));
        addRenderableWidget(performance);
        addRenderableWidget(new FlatButton(panelLeft + panelWidth - 12 - doneWidth, mainFooterTop,
                doneWidth, 20, Component.translatable("gui.done"), button -> onClose(), false));
    }

    private List<OptionInstance<?>> settings() {
        return switch (tab) {
            case 1 -> List.of(videoOptions.graphicsMode(), videoOptions.ambientOcclusion(), videoOptions.cloudStatus(),
                    videoOptions.particles(), videoOptions.entityShadows(), videoOptions.mipmapLevels());
            case 2 -> List.of(videoOptions.fullscreen(), videoOptions.guiScale(), videoOptions.enableVsync(),
                    videoOptions.framerateLimit(), videoOptions.gamma(), videoOptions.bobView());
            default -> List.of(videoOptions.renderDistance(), videoOptions.simulationDistance(), videoOptions.entityDistanceScaling(),
                    videoOptions.prioritizeChunkUpdates(), videoOptions.biomeBlendRadius(), videoOptions.showAutosaveIndicator());
        };
    }

    private void turnPage(int delta) {
        page = Math.floorMod(page + delta, pages);
        rebuildWidgets();
    }

    @Override
    public void tick() {
        super.tick();
        applyScreenChanges();
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        boolean handled = super.mouseClicked(mouseX, mouseY, button);
        applyScreenChanges();
        return handled;
    }

    @Override
    public boolean keyPressed(int key, int scanCode, int modifiers) {
        boolean handled = super.keyPressed(key, scanCode, modifiers);
        applyScreenChanges();
        return handled;
    }

    private void applyScreenChanges() {
        if (minecraft.screen != this) return;
        if (guiScale != videoOptions.guiScale().get()) {
            guiScale = videoOptions.guiScale().get();
            minecraft.resizeDisplay();
        }
        if (graphicsWarnings.isShowingWarning() && !warningOpen) {
            warningOpen = true;
            Component fabulous = Component.translatable("options.graphics.fabulous");
            MutableComponent message = Component.translatable("options.graphics.warning.message", fabulous, fabulous);
            appendDriverWarning(message, "options.graphics.warning.renderer", graphicsWarnings.getRendererWarnings());
            appendDriverWarning(message, "options.graphics.warning.vendor", graphicsWarnings.getVendorWarnings());
            appendDriverWarning(message, "options.graphics.warning.version", graphicsWarnings.getVersionWarnings());
            minecraft.setScreen(new ConfirmScreen(accepted -> {
                if (accepted) {
                    graphicsWarnings.dismissWarning();
                    videoOptions.graphicsMode().set(GraphicsStatus.FABULOUS);
                    minecraft.levelRenderer.allChanged();
                } else {
                    graphicsWarnings.dismissWarningAndSkipFabulous();
                }
                warningOpen = false;
                videoOptions.save();
                minecraft.setScreen(this);
            }, Component.translatable("options.graphics.warning.title"), message,
                    Component.translatable("options.graphics.warning.accept"),
                    Component.translatable("options.graphics.warning.cancel")));
        }
    }

    private static void appendDriverWarning(MutableComponent message, String key, String detail) {
        if (detail != null) message.append("\n\n").append(Component.translatable(key, detail));
    }

    @Override
    public void removed() {
        int selectedMipmaps = videoOptions.mipmapLevels().get();
        if (selectedMipmaps != appliedMipmaps) {
            minecraft.updateMaxMipLevel(selectedMipmaps);
            minecraft.delayTextureReload();
            appliedMipmaps = selectedMipmaps;
        }
        videoOptions.save();
        super.removed();
    }

    @Override
    public void onClose() {
        videoOptions.save();
        minecraft.setScreen(returnScreen);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        if (Screen.hasControlDown() && delta != 0) {
            int candidate = videoOptions.guiScale().get() + (int) Math.signum(delta);
            int maximum = minecraft.getWindow().calculateScale(0, videoOptions.forceUnicodeFont().get());
            if (candidate > 0 && candidate <= maximum) {
                videoOptions.guiScale().set(candidate);
                applyScreenChanges();
                return true;
            }
            return false;
        }
        if (!Screen.hasControlDown() && pages > 1 && delta != 0) {
            turnPage(delta < 0 ? 1 : -1);
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, delta);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        graphics.fillGradient(0, 0, width, height, 0xF0162023, 0xF0081013);
        graphics.fill(panelLeft, panelTop, panelLeft + panelWidth, panelBottom, 0xF21A2529);
        graphics.fill(panelLeft, panelTop, panelLeft + panelWidth, panelTop + 2, ACCENT);
        graphics.fill(panelLeft + 12, panelTop + 13, panelLeft + 16, panelTop + 29, ACCENT);
        graphics.fill(panelLeft + 19, panelTop + 18, panelLeft + 23, panelTop + 29, 0xFF438E7D);
        graphics.fill(panelLeft + 26, panelTop + 23, panelLeft + 30, panelTop + 29, 0xFF345E55);
        graphics.drawString(font, Component.translatable("pashaboost.video.title"), panelLeft + 39, panelTop + 12, TEXT, false);
        graphics.drawString(font, Component.translatable("pashaboost.video.subtitle"), panelLeft + 39, panelTop + 27, MUTED, false);
        String description = Component.translatable("pashaboost.video.description." + TABS[tab]).getString();
        graphics.drawString(font, font.plainSubstrByWidth(description, panelWidth - (pages > 1 ? 80 : 24)),
                panelLeft + 12, panelTop + 79, MUTED, false);
        if (panelBottom - panelTop >= 265) {
            graphics.drawString(font, Component.translatable("pashaboost.video.saved"),
                    panelLeft + 12, panelBottom - (hasNativeSettings ? 73 : 49), MUTED, false);
        }
        // Screen.renderWithTooltip supplies native tooltips and accessibility behavior. Minecraft's own option
        // controls render first (hover state, tooltips, narration) and are then repainted in the flat style.
        for (Renderable widget : renderables) {
            widget.render(graphics, mouseX, mouseY, partialTick);
            if (widget instanceof AbstractWidget control && optionControls.contains(control)) {
                // Text is batched until the end of the frame and drawn slightly in front (z +0.03): flush it,
                // then repaint further in front so the vanilla label is covered.
                graphics.flush();
                graphics.pose().pushPose();
                graphics.pose().translate(0, 0, 1);
                paintFlat(graphics, control);
                graphics.pose().popPose();
            }
        }
    }

    private static final java.lang.reflect.Field SLIDER_VALUE =
            net.minecraftforge.fml.util.ObfuscationReflectionHelper.findField(net.minecraft.client.gui.components.AbstractSliderButton.class, "f_93577_");

    private void paintFlat(GuiGraphics graphics, AbstractWidget control) {
        int x = control.getX(), y = control.getY(), right = x + control.getWidth(), bottom = y + control.getHeight();
        boolean hot = control.active && control.isHoveredOrFocused();
        graphics.fill(x, y, right, bottom, hot ? BoostUi.CARD_HOVER : BoostUi.CARD);
        String message = BoostUi.fit(font, control.getMessage().getString(), control.getWidth() - 12);
        int color = control.active ? TEXT : BoostUi.FAINT;
        if (control instanceof net.minecraft.client.gui.components.AbstractSliderButton) {
            double value;
            try { value = SLIDER_VALUE.getDouble(control); } catch (IllegalAccessException unreadable) { value = 0; }
            int trackY = bottom - 5, knob = x + 4 + (int) Math.round(value * (control.getWidth() - 12));
            graphics.fill(x + 4, trackY, right - 4, trackY + 2, BoostUi.TRACK);
            graphics.fill(x + 4, trackY, knob + 2, trackY + 2, control.active ? ACCENT : BoostUi.FAINT);
            graphics.fill(knob, trackY - 2, knob + 4, trackY + 4, control.active ? 0xFFD8FFF0 : BoostUi.FAINT);
            graphics.drawString(font, message, x + 6, y + 4, color, false);
        } else {
            graphics.fill(x, bottom - 1, right, bottom, hot ? ACCENT : 0xFF51645F);
            graphics.drawCenteredString(font, message, (x + right) / 2, y + (control.getHeight() - 8) / 2, color);
        }
        if (control.isFocused()) graphics.renderOutline(x, y, control.getWidth(), control.getHeight(), ACCENT);
    }

    private static final class FlatButton extends Button {
        private final boolean accent;

        private FlatButton(int x, int y, int width, int height, Component message, OnPress action, boolean accent) {
            super(x, y, width, height, message, action, DEFAULT_NARRATION);
            this.accent = accent;
        }

        @Override
        protected void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
            int background = accent ? 0xFF28594F : 0xFF29363B;
            if (active && isHoveredOrFocused()) background = accent ? 0xFF367663 : 0xFF3A4C51;
            graphics.fill(getX(), getY(), getX() + getWidth(), getY() + getHeight(), background);
            graphics.fill(getX(), getY() + getHeight() - 1, getX() + getWidth(), getY() + getHeight(),
                    accent ? ACCENT : 0xFF51645F);
            if (isFocused()) graphics.renderOutline(getX(), getY(), getWidth(), getHeight(), ACCENT);
            renderScrollingString(graphics, Minecraft.getInstance().font, 4, accent ? 0xFFD8FFF0 : TEXT);
        }
    }
}
