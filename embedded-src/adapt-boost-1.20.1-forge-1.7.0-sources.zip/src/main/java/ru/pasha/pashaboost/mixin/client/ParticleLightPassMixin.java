package ru.pasha.pashaboost.mixin.client;

import net.minecraft.client.particle.ParticleEngine;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.pasha.pashaboost.client.SharedParticleLight;
import ru.pasha.pashaboost.core.ParticleLightShare;

/**
 * One ParticleEngine.render call is one pass of the shared particle light table: between its HEAD and its RETURN only
 * particles are drawn, nothing in the world changes. Bookkeeping only, never gated.
 */
// Forge's render(..., Frustum) overload has no SRG name; the vanilla m_107336_ only forwards to it with a null frustum
// (OptiFine I6 and Forge alike), and OptiFine's renderLevel calls it three times. Its only exit is one return besides
// the crash-report throw, which the frame-start reset in ParticleLightRendererMixin covers. require = 0.
@Mixin(value = ParticleEngine.class, remap = false)
public abstract class ParticleLightPassMixin {
    @Inject(method = "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource$BufferSource;Lnet/minecraft/client/renderer/LightTexture;Lnet/minecraft/client/Camera;FLnet/minecraft/client/renderer/culling/Frustum;)V",
            at = @At("HEAD"), require = 0, remap = false)
    private void pashaboost$lightPassStart(CallbackInfo ci) { ParticleLightShare.beginPass(); }

    @Inject(method = "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource$BufferSource;Lnet/minecraft/client/renderer/LightTexture;Lnet/minecraft/client/Camera;FLnet/minecraft/client/renderer/culling/Frustum;)V",
            at = @At("RETURN"), require = 0, remap = false)
    private void pashaboost$lightPassEnd(CallbackInfo ci) { ParticleLightShare.endPass(); }

    @Inject(method = {"setLevel(Lnet/minecraft/client/multiplayer/ClientLevel;)V", "m_107342_(Lnet/minecraft/client/multiplayer/ClientLevel;)V"},
            at = @At("HEAD"), require = 0, remap = false)
    private void pashaboost$lightLevelChanged(CallbackInfo ci) { SharedParticleLight.levelChanged(); }
}
