package ru.pasha.pashaboost.core;

import java.util.Arrays;

/** Bounded frame history. Recording a frame does not allocate any objects. */
public final class FrameStats {
    public static final int DEFAULT_CAPACITY = 8192;
    public static final int MAX_CAPACITY = 16384;
    private static final double NANOS_PER_SECOND = 1_000_000_000.0;
    private static final double NANOS_PER_MILLI = 1_000_000.0;

    private final long[] samples;
    private int next;
    private int count;

    public FrameStats() {
        this(DEFAULT_CAPACITY);
    }

    public FrameStats(int capacity) {
        if (capacity < 1 || capacity > MAX_CAPACITY) {
            throw new IllegalArgumentException("Frame capacity must be between 1 and " + MAX_CAPACITY);
        }
        samples = new long[capacity];
    }

    /** Ignores invalid durations; real long frames are retained, including freezes. */
    public synchronized void addNanos(long nanos) {
        if (nanos <= 0) {
            return;
        }
        samples[next] = nanos;
        next = (next + 1) % samples.length;
        if (count < samples.length) {
            count++;
        }
    }

    public synchronized void clear() {
        next = 0;
        count = 0;
    }

    public synchronized int size() {
        return count;
    }

    /** Statistics cover only the retained frames, including their total measured time. */
    public Snapshot snapshot() {
        final long[] sorted;
        synchronized (this) {
            if (count == 0) {
                return new Snapshot(0, 0, 0, 0, 0, 0);
            }
            sorted = Arrays.copyOf(samples, count);
        }
        Arrays.sort(sorted);
        double totalNanos = 0;
        for (long nanos : sorted) {
            totalNanos += nanos;
        }
        int slowCount = Math.max(1, (int) Math.ceil(sorted.length * 0.01));
        double slowTotalNanos = 0;
        for (int index = sorted.length - slowCount; index < sorted.length; index++) {
            slowTotalNanos += sorted[index];
        }
        int p95Index = Math.max(0, (int) Math.ceil(sorted.length * 0.95) - 1);
        return new Snapshot(
                sorted.length * NANOS_PER_SECOND / totalNanos,
                slowCount * NANOS_PER_SECOND / slowTotalNanos,
                sorted[p95Index] / NANOS_PER_MILLI,
                sorted[sorted.length - 1] / NANOS_PER_MILLI,
                sorted.length,
                totalNanos / NANOS_PER_SECOND);
    }

    /** One-percent low is the reciprocal of the mean duration of the slowest 1% of frames. */
    public record Snapshot(double averageFps, double onePercentLowFps, double p95Millis,
                           double maxMillis, int frames, double seconds) {
    }
}
