package ru.pasha.pashaboost.client;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectIterators;
import it.unimi.dsi.fastutil.objects.ObjectListIterator;
import net.minecraft.client.Minecraft;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.AABB;
import ru.pasha.pashaboost.OptimizationCounters;
import ru.pasha.pashaboost.RuntimeTuning;

/**
 * BrandonsCore draws the see-through part of a few block entities (in this pack only Draconic Evolution's reactor core)
 * in its own after-particles pass, BCClientEventHandler.renderLevelStage. Every frame that pass walked every block entity
 * of every visible section and built its render box and frustum test before asking whether the renderer is a
 * BlockEntityRendererTransparent at all: 3.5 % of the render thread and two AABBs per block entity in JFR.
 */
public final class BrandonsTransparency {
    /** Handed to BrandonsCore instead of a real box for block entities its own renderer test rejects anyway; outside every frustum. */
    public static final AABB SKIP = new AABB(0.0, -3.0E7, 0.0, 1.0, -3.0E7 + 1.0, 1.0);
    private static final Class<?> TRANSPARENT = find("com.brandon3055.brandonscore.client.render.BlockEntityRendererTransparent");
    // Written by chunk-compile threads, read by the render thread. Sticky: once any section list held a block entity with a
    // transparent renderer, the walk over visible sections is never skipped again in this session.
    private static volatile boolean recorderLive, sectionListHasTransparent;

    private static Class<?> find(String name) {
        try { return Class.forName(name, false, BrandonsTransparency.class.getClassLoader()); }
        catch (ClassNotFoundException | LinkageError absent) { return null; }
    }

    // The very lookup BrandonsCore makes (BlockEntityRenderDispatcher.getRenderer is renderers.get(be.getType())).
    private static boolean transparent(BlockEntity blockEntity) {
        return TRANSPARENT.isInstance(Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity));
    }

    /** Render thread. Same answer BrandonsCore reaches, without the box for block entities it would not draw. */
    public static AABB boundsOrSkip(BlockEntity blockEntity) {
        if (!RuntimeTuning.ACTIVE || !RuntimeTuning.BRANDONS_BOUNDS_FILTER || TRANSPARENT == null || transparent(blockEntity))
            return blockEntity.getRenderBoundingBox();
        OptimizationCounters.brandonsBoundsSkipped++;
        return SKIP;
    }

    /** Chunk-compile thread, just before vanilla adds a block entity to a section's renderable list. Never gated: it must see every compile. */
    public static void beforeSectionListAdd(BlockEntity blockEntity) {
        if (!recorderLive) recorderLive = true;
        if (sectionListHasTransparent) return;
        try {
            if (TRANSPARENT == null || transparent(blockEntity)) sectionListHasTransparent = true;
        } catch (RuntimeException | LinkageError unexpected) {
            sectionListHasTransparent = true; // never break chunk compilation; just stop skipping
        }
    }

    /** Render thread. BrandonsCore's walk over visible sections, or none while no section list can hold a match. */
    public static ObjectListIterator<?> visibleSections(ObjectArrayList<?> renderChunksInFrustum) {
        // OptiFine I6 builds section lists through the same handleBlockEntity -> CompiledChunk path (checked in its bytes),
        // and BrandonsCore still walks renderChunksInFrustum there, so the skip holds with it as well.
        if (RuntimeTuning.ACTIVE && RuntimeTuning.BRANDONS_SECTION_SKIP && recorderLive && !sectionListHasTransparent
                && TRANSPARENT != null) {
            OptimizationCounters.brandonsSectionWalksSkipped++;
            return ObjectIterators.EMPTY_ITERATOR;
        }
        return renderChunksInFrustum.iterator();
    }

    private BrandonsTransparency() {}
}
