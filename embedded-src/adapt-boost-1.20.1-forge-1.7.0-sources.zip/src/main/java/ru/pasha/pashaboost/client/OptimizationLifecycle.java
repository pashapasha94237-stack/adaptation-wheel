package ru.pasha.pashaboost.client;

import net.minecraft.client.Minecraft;
import ru.pasha.pashaboost.BoostConfig;
import ru.pasha.pashaboost.PashaBoost;
import ru.pasha.pashaboost.RuntimeTuning;
import ru.pasha.pashaboost.api.FpsAdaptationBoost;

/** Applies runtime changes only after the wearable wheel has completed FPS adaptation. */
final class OptimizationLifecycle {
    private static boolean active;

    static void tick(Minecraft mc) {
        boolean desired = mc.level != null && BoostConfig.active();
        RuntimeTuning.ACTIVE = desired;
        RenderSettings.refresh();
        // Packed glyphs used to be applied with a full resource reload on every activation and release:
        // a freeze of seconds in a large pack, on each login with the wheel on. Packed rows draw the same
        // pixels, so once earned they are simply used by the next natural reload (launch, F3+T).
        // Launch-time memory savings are earned the same way and start with the next launch.
        if (mc.level != null && FpsAdaptationBoost.isActive() && BoostConfig.ENABLED.get()
                && (!BoostConfig.GLYPHS_EARNED.get() || !BoostConfig.MEMORY_EARNED.get())) {
            BoostConfig.GLYPHS_EARNED.set(true);
            BoostConfig.MEMORY_EARNED.set(true);
            BoostConfig.save();
        }
        BoostConfig.applyGlyphGate();
        if (active != desired) {
            active = desired;
            EntityOptimizer.clear();
            ParticleOptimizer.clear();
            UniformBiomes.clear();
            if (active) ParticleOptimizer.install();
            PashaBoost.LOGGER.info("Runtime optimization {}", active ? "activated after FPS adaptation" : "released");
        }
        RuntimeGraphicsProfile.tick(mc);
    }

    static void reset(Minecraft mc) {
        RuntimeTuning.ACTIVE = false;
        active = false;
        UniformBiomes.clear();
        RuntimeGraphicsProfile.reset(mc);
    }

    /** Kept for the smoke probe: no forced font reload happens any more. */
    static boolean reloadingFonts() { return false; }
    private OptimizationLifecycle() {}
}
