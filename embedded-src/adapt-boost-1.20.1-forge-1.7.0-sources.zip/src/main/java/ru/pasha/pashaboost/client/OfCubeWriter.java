package ru.pasha.pashaboost.client;

import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import org.joml.Matrix3f;

/** Added to BufferBuilder under OptiFine I6 by OfCubeWriterMixin. */
public interface OfCubeWriter {
    /** OptiFine's BufferBuilder.canAddVertexFast(). */
    boolean pashaboost$canAddVertexFast();

    /**
     * Writes every vertex of the cube as OptiFine's addVertexFast would, with sprite UVs when {@code sprite} is not null.
     * Returns false, with the builder's write position and vertex count restored, if anything threw.
     */
    boolean pashaboost$emitCube(CubeShape shape, Matrix3f normal, int color, int overlay, int light, TextureAtlasSprite sprite);
}
