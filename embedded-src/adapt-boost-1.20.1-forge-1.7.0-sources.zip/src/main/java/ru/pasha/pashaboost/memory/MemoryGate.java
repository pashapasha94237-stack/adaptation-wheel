package ru.pasha.pashaboost.memory;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * Memory savings change how block states are built, which can only happen at launch, before any config system runs.
 * Like the rest of Adapt Boost they must be earned: they apply from the launch after Boost was first unlocked by the
 * FPS adaptation, read straight from the client config file. A missing or unreadable file means vanilla.
 */
public final class MemoryGate {
    /** Whether the launch-time memory mixins were allowed this launch; set by the mixin plugin. */
    public static volatile boolean applied;

    /** Top-level keys of pashaboost-client.toml: Boost enabled, and earned (new key, or the glyph flag of 1.4-1.5). */
    public static boolean earned(Path clientConfig) {
        try { return earned(Files.readAllLines(clientConfig, StandardCharsets.UTF_8)); }
        catch (IOException | RuntimeException e) { return false; }
    }

    static boolean earned(List<String> lines) {
        Boolean enabled = null, memory = null, glyphs = null;
        for (String raw : lines) {
            String line = raw.strip();
            if (line.startsWith("[")) break; // section keys such as [entities] enabled are not Boost's switch
            int eq = line.indexOf('=');
            if (line.startsWith("#") || eq < 0) continue;
            String key = line.substring(0, eq).strip();
            boolean value = line.substring(eq + 1).strip().startsWith("true");
            switch (key) {
                case "enabled" -> enabled = value;
                case "startupMemoryEarned" -> memory = value;
                case "packedGlyphsEarned" -> glyphs = value;
                default -> {}
            }
        }
        boolean wasEarned = memory != null ? memory : glyphs != null && glyphs;
        return wasEarned && (enabled == null || enabled);
    }

    private MemoryGate() {}
}
