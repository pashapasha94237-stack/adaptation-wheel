package ru.pasha.pashaboost.mixin;

import net.minecraft.world.level.chunk.LightChunk;
import net.minecraft.world.level.chunk.LightChunkGetter;
import net.minecraft.world.level.lighting.LightEngine;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Group;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.pasha.pashaboost.RuntimeTuning;
import ru.pasha.pashaboost.api.LightCacheMetrics;
import ru.pasha.pashaboost.core.LightChunkCache;

/** Keeps vanilla's two hot entries and caches only its chunk-source misses. */
@Mixin(value = LightEngine.class, remap = false)
public abstract class LightChunkLookupMixin implements LightCacheMetrics {
    // Lazy creation also makes clearChunkCache() safe during the target constructor.
    @Unique private LightChunkCache<LightChunk> pashaboost$lightChunks;

    @Group(name = "pashaboost$lightLookup", min = 1, max = 1)
    @Redirect(method = {
            "getChunk(II)Lnet/minecraft/world/level/chunk/LightChunk;",
            "m_284303_(II)Lnet/minecraft/world/level/chunk/LightChunk;"
    }, at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/chunk/LightChunkGetter;getChunkForLighting(II)Lnet/minecraft/world/level/chunk/LightChunk;", remap = false),
            require = 0, remap = false)
    private LightChunk pashaboost$namedLightLookup(LightChunkGetter source, int x, int z) {
        return pashaboost$lookup(source, x, z);
    }

    @Group(name = "pashaboost$lightLookup", min = 1, max = 1)
    @Redirect(method = {
            "getChunk(II)Lnet/minecraft/world/level/chunk/LightChunk;",
            "m_284303_(II)Lnet/minecraft/world/level/chunk/LightChunk;"
    }, at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/chunk/LightChunkGetter;m_6196_(II)Lnet/minecraft/world/level/chunk/LightChunk;", remap = false),
            require = 0, remap = false)
    private LightChunk pashaboost$srgLightLookup(LightChunkGetter source, int x, int z) {
        return pashaboost$lookup(source, x, z);
    }

    @Unique
    private LightChunk pashaboost$lookup(LightChunkGetter source, int x, int z) {
        if (!RuntimeTuning.ACTIVE || !RuntimeTuning.LIGHT_CACHE) {
            // A disabled interval must never keep references from an earlier batch.
            if (pashaboost$lightChunks != null && pashaboost$lightChunks.size() != 0) pashaboost$lightChunks.clear();
            return source.getChunkForLighting(x, z);
        }
        if (pashaboost$lightChunks == null) pashaboost$lightChunks = new LightChunkCache<>();
        LightChunk cached=pashaboost$lightChunks.getIfPresent(x,z);
        if(cached!=null)return cached;
        LightChunk chunk = source.getChunkForLighting(x, z);
        pashaboost$lightChunks.put(x, z, chunk);
        return chunk;
    }

    @Inject(method = {"clearChunkCache()V", "m_284550_()V"}, at = @At("RETURN"), require = 1, remap = false)
    private void pashaboost$clearLightChunks(CallbackInfo ci) {
        if (pashaboost$lightChunks != null) pashaboost$lightChunks.clear();
    }

    @Override public long pashaboost$lightHits() {
        return pashaboost$lightChunks == null ? 0 : pashaboost$lightChunks.hits();
    }
    @Override public long pashaboost$lightMisses() {
        return pashaboost$lightChunks == null ? 0 : pashaboost$lightChunks.misses();
    }
    @Unique public int pashaboost$lightCacheSize() {
        return pashaboost$lightChunks == null ? 0 : pashaboost$lightChunks.size();
    }
}
