package ru.pasha.pashaboost;

import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.fml.event.config.ModConfigEvent;

public final class BoostCommonConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue LIGHT_CACHE, WRITE_BACKPRESSURE, COMPACT_GLYPHS;
    public static final ForgeConfigSpec.IntValue WRITE_THRESHOLD, WRITE_BURST, WRITE_BUDGET_MICROS;
    static {
        var b=new ForgeConfigSpec.Builder();
        LIGHT_CACHE=b.comment("16-slot lighting chunk lookup cache, cleared after each light update batch. Auto-skipped with replacement light/chunk engines.")
                .define("lightingChunkCache",true);
        COMPACT_GLYPHS=b.comment("Pack Unicode glyph rows into primitive fields. Supports 8/16/24/32-bit sources. Auto-skipped with ModernFix. Reload resources after changing.")
                .define("compactUnicodeGlyphs",true);
        b.push("chunkWrites");
        WRITE_BACKPRESSURE=b.comment("Drain a small extra batch from vanilla's existing I/O worker when its pending-write map grows. Never deletes writes or starts extra threads.")
                .define("enabled",true);
        WRITE_THRESHOLD=b.comment("Pending chunk writes above which extra draining is allowed. Not a cap on total JVM memory.")
                .defineInRange("threshold",512,1,65536);
        WRITE_BURST=b.comment("Maximum additional writes per batch. One in-flight disk operation cannot be preempted.")
                .defineInRange("extraWrites",4,1,4);
        WRITE_BUDGET_MICROS=b.comment("Time checked between additional writes, in microseconds.")
                .defineInRange("budgetMicros",2000,100,2000);
        b.pop();
        SPEC=b.build();
    }
    public static void changed(ModConfigEvent event) {
        if(event.getConfig().getSpec()!=SPEC) return;
        RuntimeTuning.LIGHT_CACHE=LIGHT_CACHE.get();
        RuntimeTuning.GLYPH_COMPACTION=COMPACT_GLYPHS.get();
        RuntimeTuning.WRITE_BACKPRESSURE=WRITE_BACKPRESSURE.get();
        RuntimeTuning.WRITE_THRESHOLD=WRITE_THRESHOLD.get();
        RuntimeTuning.WRITE_BURST=WRITE_BURST.get();
        RuntimeTuning.WRITE_BUDGET_NANOS=WRITE_BUDGET_MICROS.get()*1000L;
    }
    private BoostCommonConfig() {}
}
