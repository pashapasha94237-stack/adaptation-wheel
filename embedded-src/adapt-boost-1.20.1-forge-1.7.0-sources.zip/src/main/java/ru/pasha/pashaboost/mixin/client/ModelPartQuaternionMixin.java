package ru.pasha.pashaboost.mixin.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.model.geom.ModelPart;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import ru.pasha.pashaboost.OptimizationCounters;
import ru.pasha.pashaboost.RuntimeTuning;

/**
 * ModelPart.translateAndRotate does poseStack.mulPose(new Quaternionf().rotationZYX(z, y, x)) for every rotated part.
 * rotationZYX overwrites all four components, and PoseStack.mulPose only feeds Matrix4f.rotate and Matrix3f.rotate, which
 * read it and keep nothing (same bytecode in OptiFine's and Forge's classes), so one scratch object gives the same
 * matrices. It saves about 1.4 % of render-thread allocation; CPU gain is negligible. Other threads allocate as before.
 */
@Mixin(value = ModelPart.class, remap = false)
public abstract class ModelPartQuaternionMixin {
    @Unique private static final Quaternionf pashaboost$scratch = new Quaternionf();

    @Redirect(method = {"translateAndRotate(Lcom/mojang/blaze3d/vertex/PoseStack;)V", "m_104299_(Lcom/mojang/blaze3d/vertex/PoseStack;)V"},
            at = @At(value = "NEW", target = "()Lorg/joml/Quaternionf;", remap = false), require = 0, remap = false)
    private Quaternionf pashaboost$quaternion() {
        if (RuntimeTuning.ACTIVE && RuntimeTuning.MODEL_QUATERNION_REUSE && RenderSystem.isOnRenderThread()) {
            OptimizationCounters.modelQuaternionsReused++;
            return pashaboost$scratch;
        }
        return new Quaternionf();
    }
}
