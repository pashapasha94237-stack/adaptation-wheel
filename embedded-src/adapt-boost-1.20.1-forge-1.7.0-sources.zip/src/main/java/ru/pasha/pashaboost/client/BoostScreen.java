package ru.pasha.pashaboost.client;

import java.util.Locale;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.common.ForgeConfigSpec;
import ru.pasha.pashaboost.BoostConfig;
import ru.pasha.pashaboost.api.FpsAdaptationBoost;

import static ru.pasha.pashaboost.client.BoostUi.*;

/**
 * Overview (live frame times, what each optimization saves, presets, A/B result) and settings. After the FPS
 * adaptation some settings are fixed by the reward; the screen shows the value that is actually in force.
 */
public final class BoostScreen extends Screen {
    private static final String[] SAVINGS = {"shaders", "particleLight", "blockEntities", "entityTicks", "particleVectors", "biomes", "mobs", "particles"};
    private static int tab;
    private final Screen parent;
    private int left, top, panelWidth, bottom, contentTop;

    public BoostScreen(Screen parent) { super(Component.translatable("pashaboost.title")); this.parent=parent; }

    private static boolean unlocked() { return FpsAdaptationBoost.isActive(); }

    @Override protected void init() {
        panelWidth=Math.min(600,width-16);
        int panelHeight=Math.min(330,height-12);
        left=(width-panelWidth)/2;
        top=(height-panelHeight)/2;
        bottom=top+panelHeight;
        int right=left+panelWidth-12;
        addRenderableWidget(new Switch(right-124,top+10,124,Component.translatable("pashaboost.master.short"),BoostConfig.ENABLED::get,b->{
            BoostConfig.ENABLED.set(!BoostConfig.ENABLED.get()); BoostConfig.save(); EntityOptimizer.clear();
        })).setTooltip(Tooltip.create(Component.translatable(unlocked()?"pashaboost.master":"pashaboost.fps_override")));
        for(int i=0;i<2;i++){
            int index=i;
            Flat button=addRenderableWidget(new Flat(left+12+i*104,top+38,100,16,Component.translatable(i==0?"pashaboost.tab.overview":"pashaboost.tab.settings"),b->{tab=index;rebuildWidgets();}));
            button.selected=tab==i;
        }
        contentTop=top+62;
        if(tab==0) overview(); else settings();
        addRenderableWidget(new Flat(right-100,bottom-24,100,18,Component.translatable("gui.done"),b->onClose()).accent());
    }

    private void overview() {
        int presetsY=contentTop+118, width=(panelWidth-24-80-8)/3;
        int current=presetIndex();
        String[] keys={"pashaboost.safe","pashaboost.balanced","pashaboost.fast"};
        for(int i=0;i<3;i++){
            int preset=i;
            Flat button=addRenderableWidget(new Flat(left+12+80+i*(width+4),presetsY,width,18,Component.translatable(keys[i]),b->{BoostConfig.preset(preset);rebuildWidgets();}));
            button.selected=current==i;
            button.setTooltip(Tooltip.create(Component.translatable(keys[i]+".tip")));
        }
        Flat measure=addRenderableWidget(new Flat(left+12,presetsY+26,Math.min(220,panelWidth/2-20),18,Component.translatable("pashaboost.measure.short"),b->{
            minecraft.setScreen(null); Benchmark.start();
        }));
        measure.active=minecraft.level!=null && unlocked();
        measure.setTooltip(Tooltip.create(Component.translatable("pashaboost.measure.tip")));
    }

    /** 0, 1 or 2 when the settings match a preset exactly, -1 otherwise. */
    private static int presetIndex() {
        for(int p=0;p<3;p++){
            if(BoostConfig.WALL_CULLING.get()==(p==2) && BoostConfig.ENTITY_DISTANCE.get()==(p==0?128:p==1?80:48)
                    && BoostConfig.PARTICLE_DISTANCE.get()==(p==0?64:p==1?48:32) && BoostConfig.PARTICLE_LIMIT.get()==(p==0?4096:p==1?2048:1024)
                    && BoostConfig.ENTITY_CULLING.get() && BoostConfig.PARTICLES.get() && BoostConfig.ADAPTIVE.get()) return p;
        }
        return -1;
    }

    private void settings() {
        int column=(panelWidth-24-6)/2, x0=left+12, x1=x0+column+6, y=contentTop;
        boolean reward=unlocked();
        rewardSwitch(x0,y,column,"pashaboost.entities",BoostConfig.ENTITY_CULLING,reward);
        rewardSwitch(x1,y,column,"pashaboost.particles",BoostConfig.PARTICLES,reward);
        y+=22;
        addRenderableWidget(new Switch(x0,y,column,Component.translatable("pashaboost.walls"),BoostConfig.WALL_CULLING::get,b->flip(BoostConfig.WALL_CULLING)))
                .setTooltip(Tooltip.create(Component.translatable("pashaboost.walls.tip")));
        rewardSwitch(x1,y,column,"pashaboost.adaptive",BoostConfig.ADAPTIVE,reward);
        y+=22;
        slider(x0,y,column,BoostConfig.ENTITY_DISTANCE,32,256,8,"pashaboost.entityDistance",reward?48:Integer.MAX_VALUE);
        slider(x1,y,column,BoostConfig.PARTICLE_DISTANCE,8,128,8,"pashaboost.particleDistance",reward?32:Integer.MAX_VALUE);
        y+=22;
        slider(x0,y,column,BoostConfig.PARTICLE_LIMIT,128,16384,128,"pashaboost.particleLimit",reward?1024:Integer.MAX_VALUE);
        slider(x1,y,column,BoostConfig.TARGET_FPS,30,240,10,"pashaboost.target",Integer.MAX_VALUE);
        y+=22;
        addRenderableWidget(new Switch(x0,y,column,Component.translatable("pashaboost.hud"),BoostConfig.HUD::get,b->flip(BoostConfig.HUD)));
        // After the reward unknown mod particles are never filtered (BoostConfig.filterModParticles).
        Switch mod=addRenderableWidget(new Switch(x1,y,column,Component.translatable("pashaboost.modParticles"),
                () -> !reward && BoostConfig.FILTER_MOD_PARTICLES.get(),b->flip(BoostConfig.FILTER_MOD_PARTICLES)));
        mod.active=!reward;
        mod.setTooltip(Tooltip.create(Component.translatable(reward?"pashaboost.modParticles.reward":"pashaboost.modParticles.tip")));
        y+=22;
        addRenderableWidget(new Switch(x0,y,column,Component.translatable("pashaboost.backgroundFps"),BoostConfig.BACKGROUND_FPS_CAP::get,b->flip(BoostConfig.BACKGROUND_FPS_CAP)))
                .setTooltip(Tooltip.create(Component.translatable("pashaboost.backgroundFps.tip")));
    }

    private void rewardSwitch(int x,int y,int width,String key,ForgeConfigSpec.BooleanValue value,boolean reward) {
        Switch button=addRenderableWidget(new Switch(x,y,width,Component.translatable(key),() -> reward || value.get(),b->flip(value)));
        button.active=!reward;
        if(reward) button.setTooltip(Tooltip.create(Component.translatable("pashaboost.forced")));
    }

    private void slider(int x,int y,int width,ForgeConfigSpec.IntValue value,int min,int max,int step,String key,int rewardLimit) {
        addRenderableWidget(new Slider(x,y,width,value.get(),min,max,step,v -> v>rewardLimit
                ? Component.translatable(key,v).append(Component.translatable("pashaboost.effective",rewardLimit))
                : Component.translatable(key,v),value::set) {
            @Override public void onRelease(double mouseX,double mouseY) { super.onRelease(mouseX,mouseY); BoostConfig.save(); }
        });
    }

    private static void flip(ForgeConfigSpec.BooleanValue value) {
        value.set(!value.get()); BoostConfig.save(); EntityOptimizer.clear();
    }

    @Override public void render(GuiGraphics g,int mouseX,int mouseY,float partial) {
        background(g,width,height);
        panel(g,left,top,left+panelWidth,bottom);
        logo(g,left+12,top+11);
        g.drawString(font,Component.translatable("pashaboost.name"),left+38,top+10,TEXT,false);
        boolean unlocked=unlocked(), on=BoostConfig.active();
        Component status=Component.translatable(!unlocked?"pashaboost.status.locked":on?"pashaboost.status.on":"pashaboost.status.off");
        g.drawString(font,fit(font,status.getString(),panelWidth-200),left+38,top+22,!unlocked?WARN:on?ACCENT:MUTED,false);
        if(tab==0) renderOverview(g);
        else if(unlocked) {
            // Below the six rows of settings.
            int y=contentTop+6*22+4;
            for(var line:font.split(Component.translatable("pashaboost.reward_limits"),panelWidth-24)) { g.drawString(font,line,left+12,y,MUTED,false); y+=10; }
        }
        g.drawString(font,fit(font,Component.translatable("pashaboost.keys").getString(),panelWidth-140),left+12,bottom-19,FAINT,false);
        super.render(g,mouseX,mouseY,partial);
    }

    private void renderOverview(GuiGraphics g) {
        var stats=BoostClient.stats();
        int x=left+12, y=contentTop, w=panelWidth-24;
        g.fill(x,y,x+w,y+46,CARD);
        String fps=String.format(Locale.ROOT,"%.0f",stats.averageFps());
        g.pose().pushPose();
        g.pose().scale(2,2,1);
        g.drawString(font,fps,(x+8)/2,(y+6)/2,fpsColor(stats.averageFps()),false);
        g.pose().popPose();
        int after=x+12+font.width(fps)*2;
        g.drawString(font,"FPS",after,y+14,MUTED,false);
        g.drawString(font,Component.translatable("pashaboost.low",String.format(Locale.ROOT,"%.0f",stats.onePercentLowFps())),x+8,y+26,TEXT,false);
        g.drawString(font,Component.translatable("pashaboost.p95",String.format(Locale.ROOT,"%.1f",stats.p95Millis())),x+8,y+36,MUTED,false);
        int graphX=x+Math.max(110,after+30-x), graphWidth=x+w-8-graphX;
        if(graphWidth>40) {
            frameGraph(g,graphX,y+6,graphWidth,24,BoostClient.RECENT_MS,BoostClient.RECENT_NEXT);
            long used=BoostClient.usedMemory(), max=BoostClient.maxMemory();
            bar(g,graphX,y+36,Math.min(80,graphWidth/3),4,max>0?(float)used/max:0,used>max*0.85?BAD:ACCENT);
            g.drawString(font,Component.translatable("pashaboost.memory",used/1048576,max/1048576),graphX+Math.min(80,graphWidth/3)+6,y+34,MUTED,false);
        }
        y+=52;
        g.drawString(font,Component.translatable(unlocked()?"pashaboost.savings":"pashaboost.savings.locked"),x,y,ACCENT,false);
        y+=12;
        int column=(w-6)/2;
        for(int i=0;i<SAVINGS.length;i++){
            int cx=x+(i%2)*(column+6), cy=y+(i/2)*12;
            String value=rate(BoostClient.RATES[i]);
            g.drawString(font,fit(font,Component.translatable("pashaboost.saving."+SAVINGS[i]).getString(),column-font.width(value)-10),cx,cy,MUTED,false);
            g.drawString(font,value,cx+column-font.width(value),cy,BoostClient.RATES[i]>0?TEXT:FAINT,false);
        }
        int presetsY=contentTop+118;
        g.drawString(font,Component.translatable("pashaboost.profile"),x,presetsY+5,MUTED,false);
        double[] last=Benchmark.last();
        int resultX=left+12+Math.min(220,panelWidth/2-20)+8;
        Component result=last==null?Component.translatable("pashaboost.bench.none")
                :Component.translatable("pashaboost.bench.last",String.format(Locale.ROOT,"%.0f",last[0]),String.format(Locale.ROOT,"%.0f",last[1]),
                        String.format(Locale.ROOT,"%.2f",last[0]>0?last[1]/last[0]:0));
        g.drawString(font,fit(font,result.getString(),left+panelWidth-12-resultX),resultX,presetsY+31,last==null?FAINT:TEXT,false);
    }

    private static String rate(long perSecond) {
        String number=perSecond>=1_000_000?String.format(Locale.ROOT,"%.1fM",perSecond/1e6)
                :perSecond>=10_000?String.format(Locale.ROOT,"%.0fk",perSecond/1e3):Long.toString(perSecond);
        return Component.translatable("pashaboost.rate",number).getString();
    }

    @Override public boolean isPauseScreen() { return false; }
    @Override public void onClose() { BoostConfig.save(); minecraft.setScreen(parent); }
}
