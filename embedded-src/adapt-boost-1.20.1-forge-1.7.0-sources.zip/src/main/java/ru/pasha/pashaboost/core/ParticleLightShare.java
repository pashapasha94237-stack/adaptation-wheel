package ru.pasha.pashaboost.core;

import java.util.concurrent.atomic.AtomicLong;

/**
 * Pure bookkeeping for the shared particle light table: block keys, the client world revision, ParticleEngine passes,
 * which invalidation hooks really landed, and the per-call tri-state. No Minecraft classes, so the mixin plugin can
 * write the hook bits while classes are still being transformed, and tests can run it.
 */
public final class ParticleLightShare {
    // Hook bits, one per injector the reuse depends on; the plugin's postApply sets a bit only when a call to that
    // handler is present in the transformed class (require = 0 may have skipped any of them).
    public static final int HOOK_BLOCK_SET = 1, HOOK_CHUNK_PACKET = 1 << 1, HOOK_CHUNK_DROP = 1 << 2, HOOK_CHUNK_REPLACE = 1 << 3,
            HOOK_VIEW_CENTER = 1 << 4, HOOK_VIEW_RADIUS = 1 << 5, HOOK_LIGHT_SWAP = 1 << 6, HOOK_ALL_CHANGED = 1 << 7,
            HOOK_SET_LEVEL = 1 << 8, HOOK_PASS_START = 1 << 9, HOOK_PASS_END = 1 << 10, HOOK_FRAME_START = 1 << 11,
            HOOK_LOOKUP = 1 << 12;
    /** Every revision bump; reuse across ParticleEngine passes needs all of them. */
    public static final int INVALIDATION = HOOK_BLOCK_SET | HOOK_CHUNK_PACKET | HOOK_CHUNK_DROP | HOOK_CHUNK_REPLACE
            | HOOK_VIEW_CENTER | HOOK_VIEW_RADIUS | HOOK_LIGHT_SWAP | HOOK_ALL_CHANGED | HOOK_SET_LEVEL;
    /** Reuse inside one pass needs its start, its end and the frame-start reset. */
    public static final int PASS = HOOK_PASS_START | HOOK_PASS_END | HOOK_FRAME_START;
    public static volatile int hooks;
    /** Set by the mixin plugin from its strict OptiFine detection. */
    public static volatile boolean optiFine;

    // Entry kinds, and what the m_6355_ redirect saw during one call (render thread only).
    public static final byte NONE = 0, AIR = 1, OTHER = 2, UNLOADED = 3, UNCACHEABLE = 4;
    /** UNKNOWN until the redirect runs inside the current call; then AIR, OTHER or UNCACHEABLE. */
    public static final byte UNKNOWN = 0;
    public static byte observed = UNCACHEABLE;

    // The client world revision. Long, so it never wraps back onto an old entry.
    private static final AtomicLong REVISION = new AtomicLong(1);
    /** Non-zero only between ParticleEngine.render HEAD and RETURN. Render thread only. */
    public static int currentPass;
    private static int passCounter;

    public static long revision() { return REVISION.get(); }
    public static void bump() { REVISION.incrementAndGet(); }

    public static void beginPass() { currentPass = passCounter = nextPass(passCounter); }
    public static void endPass() { currentPass = 0; }
    /** The next pass number; 0 means "outside any pass", so a wrap skips it. */
    public static int nextPass(int pass) { int next = pass + 1; return next == 0 ? 1 : next; }
    public static boolean samePass(int entryPass, int pass) { return pass != 0 && entryPass == pass; }
    public static final byte REUSE_NO = 0, REUSE_YES = 1, REUSE_IF_CROSS_AIR = 2;
    /**
     * An entry is reused inside the pass that stored it; an air entry also across passes, but only if the caller's
     * cross-frame check holds (left to the caller so its OptiFine call runs only for air outside the pass).
     */
    public static byte reuse(byte kind, int entryPass, int pass) {
        return samePass(entryPass, pass) ? REUSE_YES : kind == AIR ? REUSE_IF_CROSS_AIR : REUSE_NO;
    }
    /** What may be stored: air for any pass, other known kinds only inside a pass, NONE never. */
    public static boolean storable(byte kind, int pass) { return kind == AIR || kind != NONE && pass != 0; }
    /** Vanilla air is AIR only without OptiFine dynamic lights, whose contribution and option toggle no revision tracks. */
    public static byte lightKind(boolean air, boolean dynamicLights) { return air && !dynamicLights ? AIR : OTHER; }

    public static synchronized void recordHooks(int bits) { hooks |= bits; }
    public static boolean invalidationLive(int hooks) { return (hooks & INVALIDATION) == INVALIDATION; }
    public static boolean passLive(int hooks) { return (hooks & PASS) == PASS; }
    /** The bit for a call to a merged handler; Mixin renames handlers to handler$<id>$pashaboost$<name>. */
    public static int hookBit(String calledName) {
        int at = calledName.lastIndexOf("pashaboost$");
        if (at < 0) return 0;
        switch (calledName.substring(at + "pashaboost$".length())) {
            case "lightBlockSet": return HOOK_BLOCK_SET;
            case "lightChunkPacket": return HOOK_CHUNK_PACKET;
            case "lightChunkDrop": return HOOK_CHUNK_DROP;
            case "lightChunkReplace": return HOOK_CHUNK_REPLACE;
            case "lightViewCenter": return HOOK_VIEW_CENTER;
            case "lightViewRadius": return HOOK_VIEW_RADIUS;
            case "lightSwap": return HOOK_LIGHT_SWAP;
            case "lightAllChanged": return HOOK_ALL_CHANGED;
            case "lightLevelChanged": return HOOK_SET_LEVEL;
            case "lightPassStart": return HOOK_PASS_START;
            case "lightPassEnd": return HOOK_PASS_END;
            case "lightFrameStart": return HOOK_FRAME_START;
            case "sharedLightNamed": case "sharedLightSrg": return HOOK_LOOKUP;
            default: return 0;
        }
    }

    /**
     * What a call-site lookup may store, from what the redirect observed and the result. UNKNOWN means the redirect
     * did not run: with ClientLevel's hasChunk always true that only happens when another mod changed hasChunkAt, so
     * a 0 is kept for this pass only and any other value is not stored.
     */
    public static byte fullKind(byte observed, int result) {
        switch (observed) {
            case UNKNOWN: return result == 0 ? UNLOADED : NONE;
            case AIR: return AIR;
            case OTHER: return OTHER;
            default: return NONE;
        }
    }

    /** BlockPos.asLong packs y into 12 bits and x, z into 26, so keys are exact only inside these ranges. */
    public static boolean inRange(int x, int y, int z) {
        return y >= -2048 && y <= 2047 && x >= -(1 << 25) && x < (1 << 25) && z >= -(1 << 25) && z < (1 << 25);
    }
    /** Same bits as BlockPos.asLong(x, y, z). */
    public static long pack(int x, int y, int z) {
        return ((long) x & 0x3FFFFFFL) << 38 | ((long) z & 0x3FFFFFFL) << 12 | (long) y & 0xFFFL;
    }

    /** Direct-mapped: a colliding key replaces the old one; a slot is valid for one revision. */
    public static final class Table {
        public static final int SLOTS = 4096;
        private final long[] keys = new long[SLOTS], revisions = new long[SLOTS];
        private final int[] values = new int[SLOTS], passes = new int[SLOTS];
        private final byte[] kinds = new byte[SLOTS];

        static int slot(long key) {
            long h = key * 0x9E3779B97F4A7C15L;
            return (int) (h ^ h >>> 32 ^ h >>> 48) & (SLOTS - 1);
        }
        /** The slot holding key at this revision, or -1. */
        public int find(long key, long revision) {
            int i = slot(key);
            return kinds[i] != NONE && keys[i] == key && revisions[i] == revision ? i : -1;
        }
        public byte kind(int slot) { return kinds[slot]; }
        public int pass(int slot) { return passes[slot]; }
        public int value(int slot) { return values[slot]; }
        public void put(long key, long revision, int pass, byte kind, int value) {
            int i = slot(key);
            keys[i] = key; revisions[i] = revision; passes[i] = pass; values[i] = value; kinds[i] = kind;
        }
    }

    private ParticleLightShare() {}
}
