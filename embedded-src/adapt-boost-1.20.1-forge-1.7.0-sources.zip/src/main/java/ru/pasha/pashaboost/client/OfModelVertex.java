package ru.pasha.pashaboost.client;

import net.optifine.render.RenderPositions;

/** Added to ModelPart$Vertex under OptiFine I6 by OfModelVertexMixin; the class itself is package-private. */
public interface OfModelVertex {
    float pashaboost$u();
    float pashaboost$v();
    RenderPositions pashaboost$renderPositions();
}
