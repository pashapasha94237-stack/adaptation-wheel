package ru.pasha.pashaboost.memory;

import com.google.common.collect.ImmutableMap;
import com.mojang.logging.LogUtils;
import net.minecraft.world.level.block.state.properties.Property;
import org.jetbrains.annotations.Nullable;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;

/**
 * ImmutableMap, ImmutableSet and ImmutableCollection can only be extended from Guava's own package. Three abstract
 * classes in that package make their package-private methods public; FastPropertyMap and its views extend those.
 * FerriteCore ships them as precompiled bytes; here they are generated, and src/guavastubs holds the same API for
 * compiling only. If Guava refuses them, states keep vanilla property maps and only the neighbour tables shrink.
 */
final class GuavaAccess {
    static final String MAP = "com.google.common.collect.AdaptBoostImmutableMapAccess";
    static final String SET = "com.google.common.collect.AdaptBoostEntrySetAccess";
    static final String COLLECTION = "com.google.common.collect.AdaptBoostImmutableCollectionAccess";
    private static final @Nullable MethodHandle PROPERTY_MAP = define();

    /** A view of the state's values backed by its FastMap, or null when the classes could not be defined. */
    @SuppressWarnings("unchecked")
    static @Nullable ImmutableMap<Property<?>, Comparable<?>> propertyMap(FastMapStateHolder<?> state) {
        if (PROPERTY_MAP == null) return null;
        try { return (ImmutableMap<Property<?>, Comparable<?>>) PROPERTY_MAP.invoke(state); }
        catch (RuntimeException | Error e) { throw e; }
        catch (Throwable t) { throw new IllegalStateException(t); }
    }

    private static @Nullable MethodHandle define() {
        try {
            MethodHandles.Lookup guava = MethodHandles.privateLookupIn(ImmutableMap.class, MethodHandles.lookup());
            guava.defineClass(abstractClass(MAP, "com/google/common/collect/ImmutableMap",
                    "createEntrySet", "()Lcom/google/common/collect/ImmutableSet;", "isPartialView", "()Z",
                    "createKeySet", "()Lcom/google/common/collect/ImmutableSet;", "createValues", "()Lcom/google/common/collect/ImmutableCollection;"));
            guava.defineClass(abstractClass(SET, "com/google/common/collect/ImmutableSet", "isPartialView", "()Z"));
            guava.defineClass(abstractClass(COLLECTION, "com/google/common/collect/ImmutableCollection", "isPartialView", "()Z"));
            // Loaded only now: its superclass did not exist before.
            Class<?> map = Class.forName("ru.pasha.pashaboost.memory.FastPropertyMap", true, GuavaAccess.class.getClassLoader());
            return MethodHandles.lookup().findConstructor(map, MethodType.methodType(void.class, FastMapStateHolder.class));
        } catch (Throwable t) {
            LogUtils.getLogger().warn("Adapt Boost keeps vanilla block-state property maps: {}", t.toString());
            return null;
        }
    }

    /** A public abstract class with a no-argument constructor that re-declares the given methods public abstract. */
    private static byte[] abstractClass(String name, String superName, String... methods) {
        ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        writer.visit(Opcodes.V17, Opcodes.ACC_PUBLIC | Opcodes.ACC_ABSTRACT | Opcodes.ACC_SUPER, name.replace('.', '/'), null, superName, null);
        MethodVisitor init = writer.visitMethod(Opcodes.ACC_PUBLIC, "<init>", "()V", null, null);
        init.visitCode();
        init.visitVarInsn(Opcodes.ALOAD, 0);
        init.visitMethodInsn(Opcodes.INVOKESPECIAL, superName, "<init>", "()V", false);
        init.visitInsn(Opcodes.RETURN);
        init.visitMaxs(0, 0);
        init.visitEnd();
        for (int i = 0; i < methods.length; i += 2) writer.visitMethod(Opcodes.ACC_PUBLIC | Opcodes.ACC_ABSTRACT, methods[i], methods[i + 1], null, null).visitEnd();
        writer.visitEnd();
        return writer.toByteArray();
    }

    private GuavaAccess() {}
}
