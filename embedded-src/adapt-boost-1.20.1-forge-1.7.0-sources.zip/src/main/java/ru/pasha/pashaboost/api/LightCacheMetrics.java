package ru.pasha.pashaboost.api;

public interface LightCacheMetrics {
    long pashaboost$lightHits();
    long pashaboost$lightMisses();
}
