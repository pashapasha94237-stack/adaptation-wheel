package ru.pasha.pashaboost.client;

import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;
import ru.pasha.pashaboost.BoostConfig;
import ru.pasha.pashaboost.OptimizationCounters;
import ru.pasha.pashaboost.RuntimeTuning;

/**
 * Idea from Dynamic FPS (MIT): a game nobody is looking at does not need hundreds of frames a second, and a paused
 * game behind another window ran at full speed, heating the GPU. While the window is unfocused frames are held at
 * 30 a second, while it is minimised at 10. Ticks keep their pace: the client runs several ticks per frame when it
 * falls behind, and the integrated server has its own thread.
 */
final class IdleFrameCap {
    static final int UNFOCUSED_FPS = 30, MINIMIZED_FPS = 10;
    private static long lastFrameEnd;

    /** Called at the end of every frame, before the buffers are swapped. */
    static void endOfFrame(Minecraft mc) {
        long now = System.nanoTime();
        int fps = targetFps(mc);
        if (fps > 0 && lastFrameEnd != 0) {
            long waitNanos = 1_000_000_000L / fps - (now - lastFrameEnd);
            if (waitNanos > 1_000_000L) {
                try { Thread.sleep(waitNanos / 1_000_000L, (int) (waitNanos % 1_000_000L)); }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); }
                OptimizationCounters.idleFramesCapped++;
                now = System.nanoTime();
            }
        }
        lastFrameEnd = now;
    }

    /** 0 when frames are not capped. */
    static int targetFps(Minecraft mc) {
        if (!RuntimeTuning.ACTIVE || !RuntimeTuning.IDLE_FRAME_CAP || mc.isWindowActive() || !BoostConfig.BACKGROUND_FPS_CAP.get()) return 0;
        return GLFW.glfwGetWindowAttrib(mc.getWindow().getWindow(), GLFW.GLFW_ICONIFIED) != 0 ? MINIMIZED_FPS : UNFOCUSED_FPS;
    }

    private IdleFrameCap() {}
}
