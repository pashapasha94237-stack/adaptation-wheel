package ru.pasha.pashaboost;

import com.mojang.logging.LogUtils;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.loading.FMLEnvironment;
import org.slf4j.Logger;
import ru.pasha.pashaboost.client.BoostClient;

@Mod(PashaBoost.ID)
public final class PashaBoost {
    public static final String ID = "pashaboost";
    public static final Logger LOGGER = LogUtils.getLogger();
    public PashaBoost() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, BoostConfig.SPEC);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, BoostCommonConfig.SPEC);
        FMLJavaModLoadingContext.get().getModEventBus().addListener(BoostCommonConfig::changed);
        FMLJavaModLoadingContext.get().getModEventBus().addListener(BoostConfig::changed);
        // A method reference to BoostClient makes the lambda bootstrap link BoostClient, whose
        // client-only fields (KeyMapping, Screen) crash a dedicated server. Only touch it on the client.
        if (FMLEnvironment.dist == Dist.CLIENT) BoostClient.register();
    }
}
