package ru.pasha.pashaboost.mixin.client;

import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.MultiPartBakedModel;
import net.minecraft.world.level.block.state.BlockState;
import org.apache.commons.lang3.tuple.Pair;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import ru.pasha.pashaboost.memory.ModelDedup;

import java.util.List;
import java.util.function.Predicate;

/** All states of a multipart block share one baked model, see ModelDedup. Launch-time and earned only: see MemoryGate. */
// Both names; require = 0 so a conflicting mod only disables this.
@Mixin(value = MultiPartBakedModel.Builder.class, remap = false)
public abstract class MultiPartModelMemoryMixin {
    @Redirect(method = {"build()Lnet/minecraft/client/resources/model/BakedModel;", "m_119476_()Lnet/minecraft/client/resources/model/BakedModel;"},
            at = @At(value = "NEW", target = "(Ljava/util/List;)Lnet/minecraft/client/resources/model/MultiPartBakedModel;"), require = 0, remap = false)
    private MultiPartBakedModel pashaboost$shared(List<Pair<Predicate<BlockState>, BakedModel>> selectors) {
        return ModelDedup.multipart(selectors);
    }
}
