package ru.pasha.pashaboost.client;

import java.util.function.Function;
import net.minecraft.client.OptionInstance;
import net.minecraft.client.Options;

/** Save visitor that keeps temporary adaptation settings out of options.txt. */
public final class SavedOptionsAccess implements Options.FieldAccess {
    private final Options.FieldAccess output;
    public SavedOptionsAccess(Options.FieldAccess output) { this.output = output; }
    @Override public <T> void process(String key, OptionInstance<T> option) {
        output.process(key, RuntimeGraphicsProfile.forSaving(option));
    }
    @Override public int process(String key, int value) { return output.process(key, value); }
    @Override public boolean process(String key, boolean value) { return output.process(key, value); }
    @Override public String process(String key, String value) { return output.process(key, value); }
    @Override public float process(String key, float value) { return output.process(key, value); }
    @Override public <T> T process(String key, T value, Function<String,T> read, Function<T,String> write) {
        return output.process(key, value, read, write);
    }
}
