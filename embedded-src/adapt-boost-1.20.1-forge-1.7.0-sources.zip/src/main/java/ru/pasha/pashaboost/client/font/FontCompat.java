package ru.pasha.pashaboost.client.font;

/** Set at mixin-config time; read on the text hot path. */
public final class FontCompat {
    /** Another mixin config targets FontSet, so its getGlyph/getGlyphInfo hooks must never be bypassed. */
    public static volatile boolean foreignFontSetMixins;
    private FontCompat() {}
}
