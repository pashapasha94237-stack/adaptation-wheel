package ru.pasha.pashaboost.memory;

import com.google.common.collect.AdaptBoostEntrySetAccess;
import com.google.common.collect.AdaptBoostImmutableCollectionAccess;
import com.google.common.collect.AdaptBoostImmutableMapAccess;
import com.google.common.collect.ImmutableCollection;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.UnmodifiableIterator;
import net.minecraft.world.level.block.state.properties.Property;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.Objects;

/**
 * A state's property values as a view of the block's FastMap instead of a map per state. Never referenced directly:
 * GuavaAccess loads it after defining its superclass. Ported from FerriteCore 6.0.1 by malte0811 (MIT, see THIRD-PARTY.md).
 */
final class FastPropertyMap extends AdaptBoostImmutableMapAccess<Property<?>, Comparable<?>> {
    private final FastMapStateHolder<?> state;

    FastPropertyMap(FastMapStateHolder<?> state) { this.state = state; }

    @Override public int size() { return state.pashaboost$stateMap().numProperties(); }
    @Override public @Nullable Comparable<?> get(@Nullable Object key) { return state.pashaboost$stateMap().getValue(state.pashaboost$stateIndex(), key); }
    @Override public ImmutableSet<Map.Entry<Property<?>, Comparable<?>>> createEntrySet() { return new EntrySet(state); }
    // ImmutableMap would cache the entry set in a field of every state; building it per call keeps states small.
    @Override public ImmutableSet<Map.Entry<Property<?>, Comparable<?>>> entrySet() { return new EntrySet(state); }
    @Override public ImmutableSet<Property<?>> createKeySet() { return state.pashaboost$stateMap().propertySet(); }
    @Override public ImmutableCollection<Comparable<?>> createValues() { return new Values(state); }
    @Override public boolean isPartialView() { return false; }

    private abstract static class Iterator<T> extends UnmodifiableIterator<T> {
        private final FastMapStateHolder<?> state;
        private int next;
        Iterator(FastMapStateHolder<?> state) { this.state = state; }
        @Override public boolean hasNext() { return next < state.pashaboost$stateMap().numProperties(); }
        @Override public T next() {
            if (!hasNext()) throw new java.util.NoSuchElementException();
            return get(state.pashaboost$stateMap(), next++, state.pashaboost$stateIndex());
        }
        abstract T get(FastMap<?> map, int keyIndex, int stateIndex);
    }

    private static final class EntrySet extends AdaptBoostEntrySetAccess<Property<?>, Comparable<?>> {
        private final FastMapStateHolder<?> state;
        EntrySet(FastMapStateHolder<?> state) { this.state = state; }
        @Override public UnmodifiableIterator<Map.Entry<Property<?>, Comparable<?>>> iterator() {
            return new Iterator<>(state) {
                @Override Map.Entry<Property<?>, Comparable<?>> get(FastMap<?> map, int keyIndex, int stateIndex) { return map.entry(keyIndex, stateIndex); }
            };
        }
        @Override public int size() { return state.pashaboost$stateMap().numProperties(); }
        @Override public boolean contains(@Nullable Object object) {
            if (!(object instanceof Map.Entry<?, ?> entry)) return false;
            Comparable<?> value = state.pashaboost$stateMap().getValue(state.pashaboost$stateIndex(), entry.getKey());
            return value != null && value.equals(entry.getValue());
        }
        @Override public boolean isPartialView() { return false; }
    }

    private static final class Values extends AdaptBoostImmutableCollectionAccess<Comparable<?>> {
        private final FastMapStateHolder<?> state;
        Values(FastMapStateHolder<?> state) { this.state = state; }
        @Override public UnmodifiableIterator<Comparable<?>> iterator() {
            return new Iterator<>(state) {
                @Override Comparable<?> get(FastMap<?> map, int keyIndex, int stateIndex) { return map.key(keyIndex).getValue(stateIndex); }
            };
        }
        @Override public int size() { return state.pashaboost$stateMap().numProperties(); }
        @Override public boolean contains(@Nullable Object object) {
            for (Comparable<?> value : this) if (Objects.equals(value, object)) return true;
            return false;
        }
        @Override public boolean isPartialView() { return false; }
    }
}
