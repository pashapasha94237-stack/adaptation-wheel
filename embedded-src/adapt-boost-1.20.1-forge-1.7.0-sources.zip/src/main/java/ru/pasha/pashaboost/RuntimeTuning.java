package ru.pasha.pashaboost;

/** Allocation-free settings for hot paths, safe even during early resource bootstrap. */
public final class RuntimeTuning {
    // Startup is deliberately vanilla. Only a completed FPS adaptation can open this gate.
    public static volatile boolean ACTIVE;
    public static volatile boolean GLYPH_ACTIVE;
    public static volatile boolean LIGHT_CACHE = true;
    public static volatile boolean WRITE_BACKPRESSURE = true;
    public static volatile boolean GLYPH_COMPACTION = true;
    // 1.4: render-path work found with JFR on a 400-mob / 400-block-entity scene. System properties opt out.
    public static volatile boolean SHADER_SAMPLER_CACHE = !Boolean.getBoolean("pashaboost.disableShaderCache");
    public static volatile boolean BIOME_SHORTCUT = !Boolean.getBoolean("pashaboost.disableBiomeShortcut");
    public static volatile boolean PARTICLE_LIGHT_CACHE = !Boolean.getBoolean("pashaboost.disableParticleLightCache");
    public static volatile boolean BLOCK_ENTITY_CULLING = !Boolean.getBoolean("pashaboost.disableBlockEntityCulling");
    public static volatile boolean DISTANT_LIGHTMAP_SKIP = !Boolean.getBoolean("pashaboost.disableDistantLightmapSkip");
    // 1.5: found on a 23-mod OptiFine scene with 1.4 already on.
    public static volatile boolean ENTITY_TICK_THROTTLE = !Boolean.getBoolean("pashaboost.disableEntityTickThrottle");
    public static volatile boolean PARTICLE_SCRATCH = !Boolean.getBoolean("pashaboost.disableParticleScratch");
    // 1.6 (Adapt Boost): ideas from the optimisation mods in Pasha's ForgeX pack (particle_core, Clumps, Dynamic FPS).
    public static volatile boolean PARTICLE_ROTATION = !Boolean.getBoolean("pashaboost.disableParticleRotation");
    public static volatile boolean XP_ORB_MERGE = !Boolean.getBoolean("pashaboost.disableXpOrbMerge");
    public static volatile boolean IDLE_FRAME_CAP = !Boolean.getBoolean("pashaboost.disableIdleFrameCap");
    // 1.7: ideas from the Forge 1.20.1 optimisation mods (FerriteCore, ImmediatelyFast, MoreCulling) and hotspots of Pasha's pack.
    public static volatile boolean PUPFISH_SEARCH = !Boolean.getBoolean("pashaboost.disablePupfishSearch");
    /** Pupfish noise columns Alex's Mobs may sample per server tick once the free tries are spent. */
    public static volatile int PUPFISH_COLUMNS_PER_TICK = Math.max(1, Math.min(16, Integer.getInteger("pashaboost.pupfishColumnsPerTick", 1)));
    public static volatile int PUPFISH_FREE_TRIES = Math.max(0, Integer.getInteger("pashaboost.pupfishFreeTries", 512));
    public static volatile boolean CLOUD_RAIN_SHORTCUT = !Boolean.getBoolean("pashaboost.disableCloudRainShortcut");
    public static volatile boolean BRANDONS_BOUNDS_FILTER = !Boolean.getBoolean("pashaboost.disableBrandonsBoundsFilter");
    public static volatile boolean BRANDONS_SECTION_SKIP = !Boolean.getBoolean("pashaboost.disableBrandonsSectionSkip");
    public static volatile boolean MAHOU_ENTITY_SCAN = !Boolean.getBoolean("pashaboost.disableMahouEntityScan");
    public static volatile boolean SIGN_TEXT_CULLING = !Boolean.getBoolean("pashaboost.disableSignTextCulling");
    public static volatile boolean GLYPH_LOOKUP_CACHE = !Boolean.getBoolean("pashaboost.disableGlyphLookupCache");
    public static volatile boolean ENTITY_VERDICT_CACHE = !Boolean.getBoolean("pashaboost.disableEntityVerdictCache");
    // 1.7: generic vanilla costs found with JFR on the base427 scenes without OptiFine.
    public static volatile boolean SAMPLER_NAME_CACHE = !Boolean.getBoolean("pashaboost.disableSamplerNames");
    public static volatile boolean VERTEX_ELEMENT_ARRAY = !Boolean.getBoolean("pashaboost.disableVertexElementArray");
    public static volatile boolean ENTITY_DATA_LOCK_ELISION = !Boolean.getBoolean("pashaboost.disableEntityDataLockElision");
    // 1.7: costs found with JFR on the OptiFine scene. Model cubes written straight into the BufferBuilder (OptiFine I6; SPRITE also
    // through SpriteCoordinateExpander), particle light shared per block, allocation-free translucent quad sorting, OptiFine
    // entity-section memo and a render-thread model quaternion scratch.
    public static volatile boolean MODEL_DIRECT = !Boolean.getBoolean("pashaboost.disableModelDirect");
    public static volatile boolean MODEL_DIRECT_SPRITE = !Boolean.getBoolean("pashaboost.disableModelDirectSprite");
    public static volatile boolean PARTICLE_LIGHT_SHARE = !Boolean.getBoolean("pashaboost.disableParticleLightShare");
    public static volatile boolean QUAD_SORT = !Boolean.getBoolean("pashaboost.disableQuadSort");
    public static volatile boolean ENTITY_SECTION_MEMO = !Boolean.getBoolean("pashaboost.disableEntitySectionMemo");
    public static volatile boolean MODEL_QUATERNION_REUSE = !Boolean.getBoolean("pashaboost.disableModelQuaternionReuse");
    public static volatile int WRITE_THRESHOLD = 512;
    public static volatile int WRITE_BURST = 4;
    public static volatile long WRITE_BUDGET_NANOS = 2_000_000L;
    private RuntimeTuning() {}
}
