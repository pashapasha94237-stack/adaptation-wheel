package ru.pasha.pashaboost.client;

import net.minecraft.client.CloudStatus;
import net.minecraft.client.GraphicsStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.gui.screens.VideoSettingsScreen;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.LevelSettings;
import net.minecraft.world.level.WorldDataConfiguration;
import net.minecraft.world.level.levelgen.WorldOptions;
import net.minecraft.world.level.levelgen.presets.WorldPresets;
import net.minecraftforge.fml.ModList;
import org.lwjgl.glfw.GLFW;
import ru.pasha.pashaboost.BoostConfig;
import ru.pasha.pashaboost.OptimizationCounters;
import ru.pasha.pashaboost.PashaBoost;
import ru.pasha.pashaboost.RuntimeTuning;
import ru.pasha.pashaboost.api.FpsAdaptationBoost;

/** Explicit opt-in checks. Normal gameplay never runs this code. */
final class SmokeProbe {
    private static int ticks, worldTicks, activeTicks, restoreTicks, phase;
    private static boolean opened, worldRequested, checkedStartup, storageChecked;
    private static net.minecraft.client.gui.screens.Screen ownVideo, nativeVideo;

    static void tick() {
        if (!Boolean.getBoolean("pashaboost.smoke")) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.getOverlay() != null) return;
        if (worldRequested) {
            if (mc.level == null || mc.player == null) return;
            // The natural detector must see real focused frames, not an eligibility bypass.
            if (phase == 0 && Boolean.getBoolean("adaptationwheel.fps.smoke")) {
                GLFW.glfwShowWindow(mc.getWindow().getWindow());
                GLFW.glfwFocusWindow(mc.getWindow().getWindow());
            } else GLFW.glfwHideWindow(mc.getWindow().getWindow());
            worldTick(mc);
            return;
        }
        GLFW.glfwHideWindow(mc.getWindow().getWindow());
        if (mc.screen == null) return;
        if (!opened) {
            if (Boolean.getBoolean("pashaboost.smoke.expectOptifine") && !VideoCompatibility.isOptiFinePresent())
                throw new IllegalStateException("The real OptiFine transformer was not loaded for this compatibility test");
            for (String id : new String[]{"embeddium", "sodium", "ferritecore", "aiimprovements"})
                if (ModList.get().isLoaded(id)) throw new IllegalStateException("An always-on engine was embedded: " + id);
            BoostConfig.setBenchmarkOverride(true);
            if (BoostConfig.active()) throw new IllegalStateException("Benchmark bypassed the wheel unlock");
            BoostConfig.setBenchmarkOverride(null);
            if (RuntimeTuning.ACTIVE || RuntimeTuning.GLYPH_ACTIVE || OptimizationCounters.GLYPHS_COMPACTED.get() != 0)
                throw new IllegalStateException("Optimization ran before FPS adaptation");
            mc.options.graphicsMode().set(GraphicsStatus.FANCY);
            mc.options.cloudStatus().set(CloudStatus.FANCY);
            mc.options.entityShadows().set(true);
            mc.options.renderDistance().set(10);
            mc.setScreen(new VideoSettingsScreen(mc.screen, mc.options));
            if (!(mc.screen instanceof OwnVideoScreen)) {
                throw new IllegalStateException("Own video screen did not replace vanilla entry");
            }
            ownVideo = mc.screen;
            if (VideoCompatibility.isOptiFinePresent()) PashaBoost.LOGGER.info(
                    "PASHABOOST_VIDEO_CUSTOM_OPTIFINE PASS: our screen opens with the real OptiFine transformer; superclass={}",
                    ownVideo.getClass().getSuperclass().getName());
            opened = true;
        }
        if (++ticks == 20) Screenshot.grab(mc.gameDirectory, "smoke-video-settings.png", mc.getMainRenderTarget(), message -> {});
        if (ticks == 22) {
            button(ownVideo, net.minecraft.network.chat.Component.translatable("pashaboost.video.tab.quality").getString()).onPress();
            button(ownVideo, net.minecraft.network.chat.Component.translatable("pashaboost.video.tab.display").getString()).onPress();
            button(ownVideo, net.minecraft.network.chat.Component.translatable("pashaboost.video.tab.world").getString()).onPress();
        }
        if (ticks == 25) {
            button(ownVideo, net.minecraft.network.chat.Component.translatable("pashaboost.video.performance").getString()).onPress();
            if (!(mc.screen instanceof BoostScreen)) throw new IllegalStateException("Own menu cannot open optimization controls");
            mc.screen.onClose();
            if (mc.screen != ownVideo) throw new IllegalStateException("Optimization controls did not return to our menu");
            if (VideoCompatibility.isOptiFinePresent()) {
                button(ownVideo, net.minecraft.network.chat.Component.translatable("pashaboost.video.advanced").getString()).onPress();
                if (mc.screen.getClass() != VideoSettingsScreen.class) throw new IllegalStateException("Advanced settings did not open native OptiFine screen");
                nativeVideo = mc.screen;
            }
        }
        if (ticks == 27 && VideoCompatibility.isOptiFinePresent()) {
            click(nativeVideo, net.minecraft.client.resources.language.I18n.get("of.options.shaders"));
            if (!mc.screen.getClass().getName().equals("net.optifine.shaders.gui.GuiShaders"))
                throw new IllegalStateException("Native shader button did not open the real shader page");
            PashaBoost.LOGGER.info("PASHABOOST_SHADER_PAGE PASS: own video -> advanced settings -> real OptiFine shader page");
        }
        if (ticks == 31 && VideoCompatibility.isOptiFinePresent()) {
            click(mc.screen, net.minecraft.network.chat.Component.translatable("gui.done").getString());
            if (mc.screen != nativeVideo) throw new IllegalStateException("Shader Done did not return to the approved native settings instance");
        }
        if (ticks == 34 && VideoCompatibility.isOptiFinePresent()) {
            click(nativeVideo, net.minecraft.network.chat.Component.translatable("gui.done").getString());
            if (mc.screen != ownVideo) throw new IllegalStateException("Native Done did not return to our original menu");
            PashaBoost.LOGGER.info("PASHABOOST_VIDEO_ADVANCED_ROUNDTRIP PASS: own -> native -> shaders -> same native -> same own; no redirect loops");
        }
        if (ticks == 40) {
            PashaBoost.LOGGER.info("PASHABOOST_SMOKE PASS: original video screen, no embedded engines, startup and benchmark gates locked");
            if (!Boolean.getBoolean("pashaboost.smoke.world")) { mc.stop(); return; }
            worldRequested = true;
            GameRules rules = new GameRules();
            rules.getRule(GameRules.RULE_DOMOBSPAWNING).set(false, null);
            rules.getRule(GameRules.RULE_DAYLIGHT).set(false, null);
            mc.createWorldOpenFlows().createFreshLevel("PashaBoost-Smoke-" + System.currentTimeMillis(),
                    new LevelSettings("Pasha Boost smoke", GameType.CREATIVE, false, Difficulty.NORMAL, true, rules, WorldDataConfiguration.DEFAULT),
                    new WorldOptions(12340L, false, false),
                    registry -> registry.registryOrThrow(Registries.WORLD_PRESET).getHolderOrThrow(WorldPresets.FLAT).value().createWorldDimensions());
        }
    }

    private static void worldTick(Minecraft mc) {
        if (++worldTicks > 1800) throw new IllegalStateException("Smoke client did not finish its transitions");
        if (phase == 0) {
            if (worldTicks == 20) {
                if (Boolean.getBoolean("adaptationwheel.fps.smoke")) invokeFps("smokePrepareNatural");
                else { FpsAdaptationBoost.setActive(true); phase = 1; }
            }
            if (worldTicks == 250 && Boolean.getBoolean("adaptationwheel.fps.smoke")) {
                invokeFps("smokeCheckNatural");
                if (BoostConfig.active() || RuntimeTuning.ACTIVE || RuntimeGraphicsProfile.isApplied()
                        || OptimizationCounters.GLYPHS_COMPACTED.get() != 0 || OptimizationCounters.EXTRA_NBT_WRITES.get() != 0)
                    throw new IllegalStateException("Optimization activated during incomplete natural adaptation");
                long rejected = ParticleOptimizer.rejectedCount();
                if (mc.particleEngine.createParticle(ParticleTypes.SMOKE, mc.player.getX() + 1000, mc.player.getY(), mc.player.getZ(), 0, 0, 0) == null
                        || ParticleOptimizer.rejectedCount() != rejected)
                    throw new IllegalStateException("Locked optimization filtered a particle");
                PashaBoost.LOGGER.info("PASHABOOST_LOCKED PASS: incomplete adaptation leaves graphics, lighting, NBT, glyphs and particles vanilla");
                invokeFps("smokeCheck");
                mc.setScreen(null);
                phase = 1;
            }
            return;
        }
        if (phase == 2) {
            if (++restoreTicks < 15 || OptimizationLifecycle.reloadingFonts()) return;
            if (FpsAdaptationBoost.isActive() || BoostConfig.active() || RuntimeTuning.ACTIVE || RuntimeTuning.GLYPH_ACTIVE
                    || RuntimeGraphicsProfile.isApplied()) throw new IllegalStateException("Optimization stayed active after unequipping");
            int restoredDistance = VideoCompatibility.isOptiFinePresent() ? 12 : 10;
            CloudStatus restoredClouds = VideoCompatibility.isOptiFinePresent() ? CloudStatus.FANCY : CloudStatus.FAST;
            if (mc.options.graphicsMode().get() != GraphicsStatus.FANCY || mc.options.renderDistance().get() != restoredDistance
                    || !mc.options.entityShadows().get() || mc.options.cloudStatus().get() != restoredClouds)
                throw new IllegalStateException("Temporary settings did not restore or overwrote a manual edit");
            PashaBoost.LOGGER.info("PASHABOOST_RESTORE PASS: wheel removal releases all gates, reloads fonts and restores settings while preserving manual changes");
            PashaBoost.LOGGER.info("PASHABOOST_WORLD PASS: natural 30 FPS qualification, final-stage activation and real runtime work verified");
            mc.stop();
            return;
        }
        if (!RuntimeTuning.ACTIVE || OptimizationLifecycle.reloadingFonts()) return;
        if (!checkedStartup) {
            CloudStatus expectedClouds = VideoCompatibility.isOptiFinePresent() ? CloudStatus.FAST : CloudStatus.OFF;
            if (!RuntimeGraphicsProfile.isApplied() || mc.options.graphicsMode().get() != GraphicsStatus.FAST
                    || mc.options.renderDistance().get() > 8 || mc.options.cloudStatus().get() != expectedClouds
                    || mc.options.entityShadows().get()) throw new IllegalStateException("Post-adaptation graphics profile did not apply: applied="
                    + RuntimeGraphicsProfile.isApplied() + ", graphics=" + mc.options.graphicsMode().get()
                    + ", distance=" + mc.options.renderDistance().get() + ", clouds=" + mc.options.cloudStatus().get()
                    + ", shadows=" + mc.options.entityShadows().get());
            if (!BoostConfig.GLYPHS_EARNED.get()) throw new IllegalStateException("Activation did not record packed glyphs for the next resource load");
            PashaBoost.LOGGER.info("PASHABOOST_UNLOCKED PASS: runtime gates and temporary graphics profile active; packed glyphs recorded without a forced reload");
            checkedStartup = true;
        }
        if (LowLevelSmokeChecks.enabled() && !storageChecked) {
            LowLevelSmokeChecks.fontsAndStorage(mc);
            storageChecked = true;
        }
        LowLevelSmokeChecks.worldTick(mc, activeTicks);
        if (++activeTicks == 20) {
            mc.player.setYRot(0); mc.player.setXRot(0);
            for (int i = 0; i < 24; i++) {
                Zombie zombie = new Zombie(EntityType.ZOMBIE, mc.level);
                zombie.setPos(mc.player.getX() + (i % 6 - 3) * 1.5, mc.player.getY(), mc.player.getZ() + 32 + (i / 6) * 2);
                mc.level.putNonPlayerEntity(2_000_000 + i, zombie);
            }
            long before = ParticleOptimizer.rejectedCount();
            for (int i = 0; i < 512; i++) mc.particleEngine.createParticle(ParticleTypes.SMOKE,
                    mc.player.getX(), mc.player.getY() + 1, mc.player.getZ() + 2, 0, .01, 0);
            if (ParticleOptimizer.rejectedCount() - before < 300) throw new IllegalStateException("Unlocked particle budget did not filter the burst");
            if (mc.particleEngine.createParticle(ParticleTypes.FLAME, mc.player.getX(), mc.player.getY() + 1, mc.player.getZ() + 2, 0, 0, 0) == null)
                throw new IllegalStateException("Combat particle was filtered");
            BoostConfig.HUD.set(true); BoostConfig.ENTITY_DISTANCE.set(32);
        }
        if (activeTicks == 100) {
            if (EntityOptimizer.culledCount() == 0) throw new IllegalStateException("Unlocked entity filtering did not skip a draw");
            // OptiFine owns its cloud controls, so use the common distance slider for
            // its manual-edit regression. Plain Minecraft tests the cloud preference.
            if (VideoCompatibility.isOptiFinePresent()) mc.options.renderDistance().set(12);
            else mc.options.cloudStatus().set(CloudStatus.FAST);
            mc.options.save();
            try {
                var saved = java.nio.file.Files.readAllLines(mc.gameDirectory.toPath().resolve("options.txt"));
                int savedDistance = VideoCompatibility.isOptiFinePresent() ? 12 : 10;
                int liveDistance = VideoCompatibility.isOptiFinePresent() ? 12 : 8;
                if (!saved.contains("renderDistance:" + savedDistance) || !saved.contains("graphicsMode:1") || !saved.contains("entityShadows:true")
                        || mc.options.renderDistance().get() != liveDistance || mc.options.graphicsMode().get() != GraphicsStatus.FAST)
                    throw new IllegalStateException("Saving options persisted temporary optimization settings or changed live graphics");
            } catch (java.io.IOException error) { throw new IllegalStateException("Cannot verify saved preferences", error); }
            PashaBoost.LOGGER.info("PASHABOOST_SAVE PASS: temporary graphics stay active but options.txt retains the player's original choices");
            PashaBoost.LOGGER.info("PASHABOOST_WORLD culling/particles PASS: skippedDraws={}, rejectedParticles={}", EntityOptimizer.culledCount(), ParticleOptimizer.rejectedCount());
        }
        if (activeTicks == 140) {
            Screenshot.grab(mc.gameDirectory, "smoke-world.png", mc.getMainRenderTarget(), message -> {});
            if (Boolean.getBoolean("adaptationwheel.fps.smoke")) invokeFps("smokeUnequip");
            else FpsAdaptationBoost.setActive(false);
            phase = 2;
        }
    }

    private static void invokeFps(String method) {
        try { Class.forName("ru.pasha.adaptationwheel.client.FpsAdaptation").getMethod(method).invoke(null); }
        catch (ReflectiveOperationException failure) { throw new IllegalStateException("FPS adaptation integration test failed", failure); }
    }
    private static net.minecraft.client.gui.components.Button button(net.minecraft.client.gui.screens.Screen screen, String label) {
        return screen.children().stream().filter(child -> child instanceof net.minecraft.client.gui.components.Button candidate
                        && candidate.getMessage().getString().equals(label))
                .map(child -> (net.minecraft.client.gui.components.Button) child).findFirst()
                .orElseThrow(() -> new IllegalStateException("Missing button '" + label + "' in " + screen.getClass().getName()));
    }
    private static void click(net.minecraft.client.gui.screens.Screen screen, String label) {
        var target = button(screen, label);
        if (!target.active) throw new IllegalStateException("Disabled native button: " + label);
        screen.mouseClicked(target.getX() + target.getWidth() / 2.0, target.getY() + target.getHeight() / 2.0, 0);
    }
    private SmokeProbe() {}
}
