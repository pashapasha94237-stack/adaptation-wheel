package ru.pasha.pashaboost.mixin.client;

import net.minecraft.client.renderer.LevelRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.pasha.pashaboost.core.ParticleLightShare;

/**
 * Shared particle light bookkeeping, never gated: every frame starts outside any pass (so a pass left open by a thrown
 * render cannot leak into later lookups), and allChanged (F3+A, settings, resource reloads) starts a new revision.
 */
// Same descriptors in OptiFine I6's patched LevelRenderer and in Forge's. require = 0.
@Mixin(value = LevelRenderer.class, remap = false)
public abstract class ParticleLightRendererMixin {
    @Inject(method = {"renderLevel(Lcom/mojang/blaze3d/vertex/PoseStack;FJZLnet/minecraft/client/Camera;Lnet/minecraft/client/renderer/GameRenderer;Lnet/minecraft/client/renderer/LightTexture;Lorg/joml/Matrix4f;)V",
            "m_109599_(Lcom/mojang/blaze3d/vertex/PoseStack;FJZLnet/minecraft/client/Camera;Lnet/minecraft/client/renderer/GameRenderer;Lnet/minecraft/client/renderer/LightTexture;Lorg/joml/Matrix4f;)V"},
            at = @At("HEAD"), require = 0, remap = false)
    private void pashaboost$lightFrameStart(CallbackInfo ci) { ParticleLightShare.endPass(); }

    @Inject(method = {"allChanged()V", "m_109818_()V"}, at = @At("HEAD"), require = 0, remap = false)
    private void pashaboost$lightAllChanged(CallbackInfo ci) { ParticleLightShare.bump(); }
}
