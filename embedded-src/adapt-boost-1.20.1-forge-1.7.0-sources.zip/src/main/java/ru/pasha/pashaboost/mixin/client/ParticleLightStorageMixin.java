package ru.pasha.pashaboost.mixin.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.world.level.lighting.LayerLightSectionStorage;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.pasha.pashaboost.core.ParticleLightShare;

/**
 * Light reads (getLightValue with updating = false) see only visibleSectionData. After construction that field is
 * written only by swapSectionMap, and every write to light data goes into a copy listed in changedSections first, so
 * the light a particle sees cannot change without this write. Each one starts a new shared particle light revision.
 * Client light updates run on the render thread (LevelRenderer.renderLevel, packet tasks); the integrated server's
 * never do, so only render-thread swaps bump. Never gated.
 */
// Neither OptiFine I6 nor Forge patches LayerLightSectionStorage; client-srg m_75790_ offset 26 is the only PUTFIELD of
// f_75731_ outside the constructor. The field is protected, so no shadow: a FIELD point instead. require = 0.
@Mixin(value = LayerLightSectionStorage.class, remap = false)
public abstract class ParticleLightStorageMixin {
    @Inject(method = {"swapSectionMap()V", "m_75790_()V"},
            at = {@At(value = "FIELD", opcode = Opcodes.PUTFIELD, remap = false,
                    target = "Lnet/minecraft/world/level/lighting/LayerLightSectionStorage;visibleSectionData:Lnet/minecraft/world/level/lighting/DataLayerStorageMap;"),
                  @At(value = "FIELD", opcode = Opcodes.PUTFIELD, remap = false,
                    target = "Lnet/minecraft/world/level/lighting/LayerLightSectionStorage;f_75731_:Lnet/minecraft/world/level/lighting/DataLayerStorageMap;")},
            require = 0, remap = false)
    private void pashaboost$lightSwap(CallbackInfo ci) {
        if (RenderSystem.isOnRenderThread()) ParticleLightShare.bump();
    }
}
