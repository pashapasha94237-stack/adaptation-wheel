package ru.pasha.pashaboost.mixin.client;

import net.minecraft.world.level.block.entity.BlockEntity;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.pasha.pashaboost.client.BrandonsTransparency;

/**
 * Notes, while a section compiles, whether a block entity going into the section's renderable list has a BrandonsCore
 * transparent renderer, so BrandonsTransparentPassMixin knows when its walk over visible sections cannot find one.
 * Off-screen renderers (the reactor core among them) go to the global list instead, which BrandonsCore still walks.
 */
// CompileResults is package-private, hence @Coerce Object (Flywheel 1.0.5 does the same on this method). Method and field
// have a development and a production name; require = 0 so a conflicting mod only leaves the skip off (it needs this to
// have run). No ordinal: every GETFIELD of the list in this method is covered. The plugin skips this with an
// Embeddium-family renderer, which rebuilds sections its own way; OptiFine keeps this method vanilla.
@Mixin(targets = "net.minecraft.client.renderer.chunk.ChunkRenderDispatcher$RenderChunk$RebuildTask", remap = false)
public abstract class SectionListRecorderMixin {
    @Inject(method = {"handleBlockEntity(Lnet/minecraft/client/renderer/chunk/ChunkRenderDispatcher$RenderChunk$RebuildTask$CompileResults;Lnet/minecraft/world/level/block/entity/BlockEntity;)V",
            "m_234476_(Lnet/minecraft/client/renderer/chunk/ChunkRenderDispatcher$RenderChunk$RebuildTask$CompileResults;Lnet/minecraft/world/level/block/entity/BlockEntity;)V"},
            at = {@At(value = "FIELD", opcode = Opcodes.GETFIELD, target = "Lnet/minecraft/client/renderer/chunk/ChunkRenderDispatcher$RenderChunk$RebuildTask$CompileResults;blockEntities:Ljava/util/List;", remap = false),
                  @At(value = "FIELD", opcode = Opcodes.GETFIELD, target = "Lnet/minecraft/client/renderer/chunk/ChunkRenderDispatcher$RenderChunk$RebuildTask$CompileResults;f_234485_:Ljava/util/List;", remap = false)},
            require = 0, remap = false)
    private void pashaboost$beforeSectionListAdd(@Coerce Object results, BlockEntity blockEntity, CallbackInfo ci) {
        BrandonsTransparency.beforeSectionListAdd(blockEntity);
    }
}
