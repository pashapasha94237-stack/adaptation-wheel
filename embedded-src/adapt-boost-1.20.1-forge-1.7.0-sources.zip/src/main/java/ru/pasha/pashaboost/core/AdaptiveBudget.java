package ru.pasha.pashaboost.core;

/** Hysteresis prevents frame spikes from making visual quality oscillate. */
public final class AdaptiveBudget {
    private double scale = 1.0;
    private int overloaded, spare;

    public double update(double meanFrameMillis, double heapFraction, int targetFps) {
        if (!Double.isFinite(meanFrameMillis) || meanFrameMillis <= 0) return scale;
        double targetMillis = 1000.0 / Math.max(30, targetFps);
        if (meanFrameMillis > targetMillis * 1.15 || heapFraction >= 0.85) {
            spare = 0;
            if (++overloaded >= 2) {
                scale = Math.max(0.5, scale - 0.1);
                overloaded = 0;
            }
        } else if (meanFrameMillis < targetMillis * 0.80 && heapFraction < 0.75) {
            overloaded = 0;
            if (++spare >= 5) {
                scale = Math.min(1.0, scale + 0.05);
                spare = 0;
            }
        } else {
            overloaded = spare = 0;
        }
        return scale;
    }
    public double scale() { return scale; }
    /** A render distance scaled like the particle budget, never below {@code floor} (or the configured value if smaller). */
    public static int distance(int configured, int floor, double scale) {
        if (!(scale < 1)) return configured;
        return Math.max(Math.min(configured, floor), (int) Math.round(configured * Math.max(0.5, scale)));
    }
    public void reset() { scale = 1.0; overloaded = spare = 0; }
}
