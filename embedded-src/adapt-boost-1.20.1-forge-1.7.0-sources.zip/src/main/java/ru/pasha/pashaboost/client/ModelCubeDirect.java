package ru.pasha.pashaboost.client;

import net.minecraft.client.model.geom.ModelPart;
import net.minecraftforge.fml.util.ObfuscationReflectionHelper;
import org.joml.Vector3f;
import ru.pasha.pashaboost.RuntimeTuning;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * OptiFine I6 only, first used from Cube.compile on the render thread. Resolves what the fast path reads by reflection
 * once: Cube.polygons, Polygon.vertices and Polygon.normal (Polygon is package-private, so no shadow can name its type),
 * and net.optifine.Config.isShaders(). If any of it is missing the feature switches itself off.
 */
public final class ModelCubeDirect {
    private static final Field POLYGONS, VERTICES, NORMAL;
    private static final MethodHandle IS_SHADERS;
    private static final boolean READY;
    private static final CubeShape.PolygonReader READER = new CubeShape.PolygonReader() {
        @Override public Object[] vertices(Object polygon) throws IllegalAccessException { return (Object[]) VERTICES.get(polygon); }
        @Override public Vector3f normal(Object polygon) throws IllegalAccessException { return (Vector3f) NORMAL.get(polygon); }
    };

    static {
        Field polygons = null, vertices = null, normal = null;
        MethodHandle isShaders = null;
        try {
            polygons = ObfuscationReflectionHelper.findField(ModelPart.Cube.class, "f_104341_");
            Class<?> polygon = polygons.getType().getComponentType();
            vertices = ObfuscationReflectionHelper.findField(polygon, "f_104359_");
            normal = ObfuscationReflectionHelper.findField(polygon, "f_104360_");
            if (!vertices.getType().isArray() || normal.getType() != Vector3f.class) vertices = null;
            isShaders = shadersHandle();
        } catch (RuntimeException | LinkageError unexpected) {
            vertices = null;
        }
        POLYGONS = polygons; VERTICES = vertices; NORMAL = normal; IS_SHADERS = isShaders;
        READY = polygons != null && vertices != null && normal != null && isShaders != null;
        if (!READY) RuntimeTuning.MODEL_DIRECT = false;
    }

    private static MethodHandle shadersHandle() {
        Class<?> config;
        try { config = Class.forName("net.optifine.Config", false, ModelCubeDirect.class.getClassLoader()); }
        catch (ClassNotFoundException | LinkageError absent) { return null; }
        MethodType type = MethodType.methodType(boolean.class);
        try { return MethodHandles.lookup().findStatic(config, "isShaders", type); }
        catch (ReflectiveOperationException | RuntimeException notVisible) {}
        try {
            Method method = config.getMethod("isShaders");
            if (method.getReturnType() != boolean.class || method.getParameterCount() != 0) return null;
            method.setAccessible(true);
            return MethodHandles.lookup().unreflect(method);
        } catch (ReflectiveOperationException | RuntimeException notVisible) { return null; }
    }

    public static boolean ready() { return READY; }

    /** Config.isShaders() is getstatic Shaders.shaderPackLoaded in I6. Anything unexpected counts as shaders on. */
    public static boolean shaders() {
        try { return (boolean) IS_SHADERS.invokeExact(); }
        catch (Throwable unexpected) { return true; }
    }

    public static CubeShape shapeOf(ModelPart.Cube cube) {
        try { return CubeShape.of((Object[]) POLYGONS.get(cube), READER); }
        catch (IllegalAccessException | RuntimeException unexpected) { return CubeShape.FAILED; }
    }

    private ModelCubeDirect() {}
}
