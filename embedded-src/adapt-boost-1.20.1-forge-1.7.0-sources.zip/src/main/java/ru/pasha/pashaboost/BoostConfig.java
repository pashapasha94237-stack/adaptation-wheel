package ru.pasha.pashaboost;

import net.minecraftforge.common.ForgeConfigSpec;
import ru.pasha.pashaboost.api.FpsAdaptationBoost;

public final class BoostConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue ENABLED, ENTITY_CULLING, WALL_CULLING, PARTICLES,
            FILTER_MOD_PARTICLES, HUD, ADAPTIVE, GLYPHS_EARNED, MEMORY_EARNED, BACKGROUND_FPS_CAP;
    public static final ForgeConfigSpec.IntValue ENTITY_DISTANCE, NEAR_DISTANCE, WALL_CHECKS_PER_TICK,
            VISIBILITY_CACHE_TICKS, PARTICLE_DISTANCE, PARTICLE_LIMIT, PARTICLES_PER_TICK, TARGET_FPS;
    private static volatile Boolean benchmarkOverride;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        ENABLED = b.comment("Allow optimization only after completing the fourth FPS adaptation stage. Cannot bypass the wheel unlock.").define("enabled", true);
        HUD = b.comment("Show measured FPS, frame time, RAM and culling counters.").define("showHud", false);
        GLYPHS_EARNED = b.comment("Set once FPS adaptation unlocked Adapt Boost. Packed Unicode glyphs then apply at every resource load",
                "(game start, F3+T) without a forced reload. Set false to return to vanilla glyph storage at the next reload.").define("packedGlyphsEarned", false);
        MEMORY_EARNED = b.comment("Set once FPS adaptation unlocked Adapt Boost. Block states then share compact tables from the next game start",
                "(FerriteCore's technique; about 1.1 GB less memory in a 23-mod pack). Read at launch, before the game starts.").define("startupMemoryEarned", false);
        BACKGROUND_FPS_CAP = b.comment("After the FPS adaptation: at most 30 frames a second while the game window is unfocused, 10 while minimised.",
                "Turn off to record or stream the game from another window at full frame rate.").define("backgroundFrameCap", true);
        ADAPTIVE = b.comment("Adapt decorative particle budgets to frame time and heap pressure, with slow quality recovery.").define("adaptive", true);
        TARGET_FPS = b.comment("Adaptive controller target; a target is not an FPS guarantee.").defineInRange("targetFps", 120, 30, 240);
        b.push("entities");
        ENTITY_CULLING = b.comment("Skip rendering distant ordinary living entities. Players, named, glowing, boss and mounted entities are preserved.").define("enabled", true);
        ENTITY_DISTANCE = b.comment("Maximum render distance for ordinary living entities, blocks.").defineInRange("distance", 80, 32, 256);
        NEAR_DISTANCE = b.comment("Never perform wall culling inside this radius.").defineInRange("protectedRadius", 24, 8, 64);
        WALL_CULLING = b.comment("Approximate wall visibility. Off by default for maximum compatibility; only full opaque blocks occlude.").define("wallCulling", false);
        WALL_CHECKS_PER_TICK = b.comment("Maximum entities tested per tick. Untested entities stay visible.").defineInRange("wallChecksPerTick", 4, 1, 16);
        VISIBILITY_CACHE_TICKS = b.comment("Wall cache lifetime, ticks; movement invalidates results.").defineInRange("visibilityCacheTicks", 5, 1, 10);
        b.pop().push("particles");
        PARTICLES = b.comment("Filter decorative particles before allocation; preserve combat/forced particles.").define("enabled", true);
        PARTICLE_DISTANCE = b.comment("Maximum decorative particle distance, blocks.").defineInRange("distance", 48, 8, 128);
        PARTICLE_LIMIT = b.comment("Stop creating decorative particles above this active count. Combat/forced particles may exceed it.").defineInRange("activeLimit", 2048, 128, 16384);
        PARTICLES_PER_TICK = b.comment("Maximum new decorative particles per tick; combat particles exempt.").defineInRange("newPerTick", 128, 8, 2048);
        FILTER_MOD_PARTICLES = b.comment("Also filter unknown mod particles. May hide mod signals; off by default.").define("filterModParticles", false);
        b.pop();
        SPEC = b.build();
    }

    public static boolean active() {
        if (!FpsAdaptationBoost.isActive()) return false;
        Boolean override = benchmarkOverride;
        return override != null ? override : ENABLED.get();
    }
    public static boolean entityCullingEnabled() { return FpsAdaptationBoost.isActive() || ENTITY_CULLING.get(); }
    public static boolean particlesEnabled() { return FpsAdaptationBoost.isActive() || PARTICLES.get(); }
    public static boolean adaptiveEnabled() { return FpsAdaptationBoost.isActive() || ADAPTIVE.get(); }
    public static int entityDistance() { return effectiveLimit(ENTITY_DISTANCE.get(), 48); }
    public static int particleDistance() { return effectiveLimit(PARTICLE_DISTANCE.get(), 32); }
    public static int particleLimit() { return effectiveLimit(PARTICLE_LIMIT.get(), 1024); }
    public static int particlesPerTick() { return effectiveLimit(PARTICLES_PER_TICK.get(), 64); }
    public static boolean filterModParticles() { return !FpsAdaptationBoost.isActive() && FILTER_MOD_PARTICLES.get(); }
    private static int effectiveLimit(int configured, int boostLimit) {
        return FpsAdaptationBoost.isActive() ? Math.min(configured, boostLimit) : configured;
    }
    public static void setBenchmarkOverride(Boolean value) { benchmarkOverride = value; }
    public static void preset(int preset) {
        ENABLED.set(true);
        ENTITY_CULLING.set(true);
        PARTICLES.set(true);
        ADAPTIVE.set(true);
        FILTER_MOD_PARTICLES.set(false);
        WALL_CULLING.set(preset == 2);
        ENTITY_DISTANCE.set(preset == 0 ? 128 : preset == 1 ? 80 : 48);
        NEAR_DISTANCE.set(24);
        PARTICLE_DISTANCE.set(preset == 0 ? 64 : preset == 1 ? 48 : 32);
        PARTICLE_LIMIT.set(preset == 0 ? 4096 : preset == 1 ? 2048 : 1024);
        PARTICLES_PER_TICK.set(preset == 0 ? 256 : preset == 1 ? 128 : 64);
        save();
    }
    public static void save() { SPEC.save(); }
    /** Packed glyphs are used by resource loads once earned; the config is read before the first load. */
    public static void applyGlyphGate() {
        RuntimeTuning.GLYPH_ACTIVE = SPEC.isLoaded() && GLYPHS_EARNED.get() && ENABLED.get() && RuntimeTuning.GLYPH_COMPACTION;
    }
    public static void changed(net.minecraftforge.fml.event.config.ModConfigEvent event) {
        if (event.getConfig().getSpec() == SPEC && !(event instanceof net.minecraftforge.fml.event.config.ModConfigEvent.Unloading)) applyGlyphGate();
    }
    private BoostConfig() {}
}
