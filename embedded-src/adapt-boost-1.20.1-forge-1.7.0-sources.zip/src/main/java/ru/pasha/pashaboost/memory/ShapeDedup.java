package ru.pasha.pashaboost.memory;

import it.unimi.dsi.fastutil.booleans.BooleanArrays;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenCustomHashMap;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.phys.shapes.ArrayVoxelShape;
import net.minecraft.world.phys.shapes.BitSetDiscreteVoxelShape;
import net.minecraft.world.phys.shapes.CubeVoxelShape;
import net.minecraft.world.phys.shapes.DiscreteVoxelShape;
import net.minecraft.world.phys.shapes.SliceShape;
import net.minecraft.world.phys.shapes.SubShape;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraftforge.fml.util.ObfuscationReflectionHelper;
import org.jetbrains.annotations.Nullable;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Every block state caches its collision shape, six face slices of its occlusion shape and its sturdy faces. Mods
 * often build new but equal shapes for each state, so hundreds of thousands of equal copies were kept. Equal ones
 * are now one object, and an equal shape still referenced elsewhere shares the canonical one's arrays.
 * Adapted from FerriteCore 6.0.1 by malte0811 (MIT, see THIRD-PARTY.md); fields are reached by reflection with their
 * SRG names because Adapt Boost has no mixin refmap.
 */
public final class ShapeDedup {
    public static final AtomicLong CACHES_DEDUPLICATED = new AtomicLong();
    private static final Class<?> CACHE_CLASS = cacheClass();
    private static final MethodHandle CACHE = getter(BlockBehaviour.BlockStateBase.class, "f_60593_");
    private static final MethodHandle COLLISION = getter(CACHE_CLASS, "f_60842_"), SET_COLLISION = setter(CACHE_CLASS, "f_60842_");
    private static final MethodHandle OCCLUSION = getter(CACHE_CLASS, "f_60849_"), SET_OCCLUSION = setter(CACHE_CLASS, "f_60849_");
    private static final MethodHandle STURDY = getter(CACHE_CLASS, "f_60850_"), SET_STURDY = setter(CACHE_CLASS, "f_60850_");
    private static final MethodHandle SHAPE = getter(VoxelShape.class, "f_83211_"), SET_SHAPE = setter(VoxelShape.class, "f_83211_");
    private static final MethodHandle FACES = getter(VoxelShape.class, "f_83212_"), SET_FACES = setter(VoxelShape.class, "f_83212_");
    private static final MethodHandle XS = getter(ArrayVoxelShape.class, "f_82563_"), SET_XS = setter(ArrayVoxelShape.class, "f_82563_");
    private static final MethodHandle YS = getter(ArrayVoxelShape.class, "f_82564_"), SET_YS = setter(ArrayVoxelShape.class, "f_82564_");
    private static final MethodHandle ZS = getter(ArrayVoxelShape.class, "f_82565_"), SET_ZS = setter(ArrayVoxelShape.class, "f_82565_");
    private static final MethodHandle STORAGE = getter(BitSetDiscreteVoxelShape.class, "f_82580_");
    private static final MethodHandle[] BOUNDS = getters(BitSetDiscreteVoxelShape.class, "f_82581_", "f_82582_", "f_82583_", "f_82584_", "f_82585_", "f_82586_");
    private static final MethodHandle PARENT = getter(SubShape.class, "f_83182_");
    private static final MethodHandle[] RANGE = getters(SubShape.class, "f_83183_", "f_83184_", "f_83185_", "f_83186_", "f_83187_", "f_83188_");
    private static final MethodHandle DELEGATE = getter(SliceShape.class, "f_83168_"), AXIS = getter(SliceShape.class, "f_83169_");

    private static final it.unimi.dsi.fastutil.Hash.Strategy<VoxelShape> SHAPES = new it.unimi.dsi.fastutil.Hash.Strategy<>() {
        @Override public int hashCode(VoxelShape shape) { return shape == null ? 0 : hash(shape); }
        @Override public boolean equals(VoxelShape a, VoxelShape b) { return same(a, b); }
    };
    // Guarded by ShapeDedup.class: caches may be rebuilt lazily from several threads (ModernFix).
    private static final Map<VoxelShape, VoxelShape> COLLISION_SHAPES = new Object2ObjectOpenCustomHashMap<>(SHAPES);
    private static final Map<VoxelShape, VoxelShape[]> FACE_SLICES = new Object2ObjectOpenCustomHashMap<>(SHAPES);
    private static final Map<boolean[], boolean[]> STURDY_FACES = new Object2ObjectOpenCustomHashMap<>(BooleanArrays.HASH_STRATEGY);
    private static final ThreadLocal<Object> PREVIOUS = new ThreadLocal<>();

    /** Before BlockStateBase.initCache: the cache it replaces, whose shapes are reused when equal. */
    public static void before(BlockBehaviour.BlockStateBase state) {
        try { PREVIOUS.set(CACHE.invoke(state)); } catch (Throwable t) { throw rethrow(t); }
    }

    /** After BlockStateBase.initCache: point the new cache at canonical shapes. */
    public static void after(BlockBehaviour.BlockStateBase state) {
        try {
            Object cache = CACHE.invoke(state), previous = PREVIOUS.get();
            PREVIOUS.remove();
            if (cache == null) return; // blocks with dynamic shapes keep no cache
            synchronized (ShapeDedup.class) {
                VoxelShape collision = (VoxelShape) COLLISION.invoke(cache);
                VoxelShape kept = previous != null && same((VoxelShape) COLLISION.invoke(previous), collision) ? (VoxelShape) COLLISION.invoke(previous)
                        : collision instanceof ArrayVoxelShape ? COLLISION_SHAPES.computeIfAbsent(collision, s -> s) : collision;
                shareInternals(kept, collision);
                SET_COLLISION.invoke(cache, kept);

                VoxelShape[] slices = (VoxelShape[]) OCCLUSION.invoke(cache);
                VoxelShape occlusion = sliced(slices);
                if (occlusion != null) {
                    VoxelShape[] previousSlices = previous == null ? null : (VoxelShape[]) OCCLUSION.invoke(previous);
                    VoxelShape previousOcclusion = sliced(previousSlices);
                    VoxelShape[] keptSlices = previousOcclusion != null && same(previousOcclusion, occlusion) ? previousSlices : FACE_SLICES.putIfAbsent(occlusion, slices);
                    if (keptSlices != null) {
                        shareInternals(sliced(keptSlices), occlusion);
                        SET_OCCLUSION.invoke(cache, keptSlices);
                    }
                }

                boolean[] sturdy = (boolean[]) STURDY.invoke(cache);
                boolean[] previousSturdy = previous == null ? null : (boolean[]) STURDY.invoke(previous);
                SET_STURDY.invoke(cache, Arrays.equals(previousSturdy, sturdy) ? previousSturdy : STURDY_FACES.computeIfAbsent(sturdy, s -> s));
            }
            CACHES_DEDUPLICATED.incrementAndGet();
        } catch (Throwable t) { throw rethrow(t); }
    }

    /** The occlusion shape the six face slices were cut from. */
    private static @Nullable VoxelShape sliced(@Nullable VoxelShape[] slices) throws Throwable {
        if (slices != null) for (VoxelShape slice : slices) if (slice instanceof SliceShape) return (VoxelShape) DELEGATE.invoke(slice);
        return null;
    }

    /** An equal copy still referenced elsewhere (a block's own shape constants) stops holding its own arrays. */
    private static void shareInternals(@Nullable VoxelShape keep, @Nullable VoxelShape replace) throws Throwable {
        if (keep == replace || !(keep instanceof ArrayVoxelShape) || !(replace instanceof ArrayVoxelShape)) return;
        SET_XS.invoke(replace, XS.invoke(keep));
        SET_YS.invoke(replace, YS.invoke(keep));
        SET_ZS.invoke(replace, ZS.invoke(keep));
        SET_FACES.invoke(replace, FACES.invoke(keep));
        SET_SHAPE.invoke(replace, SHAPE.invoke(keep));
    }

    static int hash(VoxelShape shape) {
        try {
            if (shape instanceof SliceShape) return (31 * Objects.hashCode(AXIS.invoke(shape)) + hash((DiscreteVoxelShape) SHAPE.invoke(shape))) * 31 + hash((VoxelShape) DELEGATE.invoke(shape));
            if (shape instanceof ArrayVoxelShape) return 31 * Objects.hash(XS.invoke(shape), YS.invoke(shape), ZS.invoke(shape)) + hash((DiscreteVoxelShape) SHAPE.invoke(shape));
            if (shape instanceof CubeVoxelShape) return hash((DiscreteVoxelShape) SHAPE.invoke(shape));
            return shape.hashCode();
        } catch (Throwable t) { throw rethrow(t); }
    }

    static boolean same(@Nullable VoxelShape a, @Nullable VoxelShape b) {
        if (a == b) return true;
        if (a == null || b == null || a.getClass() != b.getClass()) return false;
        try {
            if (a instanceof SliceShape) return Objects.equals(AXIS.invoke(a), AXIS.invoke(b)) && same((VoxelShape) DELEGATE.invoke(a), (VoxelShape) DELEGATE.invoke(b))
                    && same((DiscreteVoxelShape) SHAPE.invoke(a), (DiscreteVoxelShape) SHAPE.invoke(b));
            if (a instanceof ArrayVoxelShape) return Objects.equals(XS.invoke(a), XS.invoke(b)) && Objects.equals(YS.invoke(a), YS.invoke(b))
                    && Objects.equals(ZS.invoke(a), ZS.invoke(b)) && same((DiscreteVoxelShape) SHAPE.invoke(a), (DiscreteVoxelShape) SHAPE.invoke(b));
            if (a instanceof CubeVoxelShape) return same((DiscreteVoxelShape) SHAPE.invoke(a), (DiscreteVoxelShape) SHAPE.invoke(b));
            return a.equals(b);
        } catch (Throwable t) { throw rethrow(t); }
    }

    static int hash(DiscreteVoxelShape shape) throws Throwable {
        int result = (shape.getXSize() * 31 + shape.getYSize()) * 31 + shape.getZSize();
        if (shape instanceof SubShape) {
            for (MethodHandle bound : RANGE) result = 31 * result + (int) bound.invoke(shape);
            return 31 * result + hash((DiscreteVoxelShape) PARENT.invoke(shape));
        }
        if (shape instanceof BitSetDiscreteVoxelShape) {
            for (MethodHandle bound : BOUNDS) result = 31 * result + (int) bound.invoke(shape);
            return 31 * result + Objects.hashCode(STORAGE.invoke(shape));
        }
        return 31 * result + shape.hashCode();
    }

    static boolean same(@Nullable DiscreteVoxelShape a, @Nullable DiscreteVoxelShape b) throws Throwable {
        if (a == b) return true;
        if (a == null || b == null || a.getClass() != b.getClass()
                || a.getXSize() != b.getXSize() || a.getYSize() != b.getYSize() || a.getZSize() != b.getZSize()) return false;
        if (a instanceof SubShape) {
            for (MethodHandle bound : RANGE) if ((int) bound.invoke(a) != (int) bound.invoke(b)) return false;
            return same((DiscreteVoxelShape) PARENT.invoke(a), (DiscreteVoxelShape) PARENT.invoke(b));
        }
        if (a instanceof BitSetDiscreteVoxelShape) {
            for (MethodHandle bound : BOUNDS) if ((int) bound.invoke(a) != (int) bound.invoke(b)) return false;
            return STORAGE.invoke(a).equals(STORAGE.invoke(b));
        }
        return a.equals(b);
    }

    private static Class<?> cacheClass() {
        try { return Class.forName("net.minecraft.world.level.block.state.BlockBehaviour$BlockStateBase$Cache"); }
        catch (ClassNotFoundException e) { throw new IllegalStateException(e); }
    }

    private static Field field(Class<?> owner, String srgName) { return ObfuscationReflectionHelper.findField(owner, srgName); }

    private static MethodHandle getter(Class<?> owner, String srgName) {
        try { return MethodHandles.lookup().unreflectGetter(field(owner, srgName)); }
        catch (IllegalAccessException e) { throw new IllegalStateException(e); }
    }

    private static MethodHandle setter(Class<?> owner, String srgName) {
        try { return MethodHandles.lookup().unreflectSetter(field(owner, srgName)); }
        catch (IllegalAccessException e) { throw new IllegalStateException(e); }
    }

    private static MethodHandle[] getters(Class<?> owner, String... srgNames) {
        MethodHandle[] handles = new MethodHandle[srgNames.length];
        for (int i = 0; i < srgNames.length; i++) handles[i] = getter(owner, srgNames[i]);
        return handles;
    }

    private static RuntimeException rethrow(Throwable t) {
        if (t instanceof RuntimeException e) return e;
        if (t instanceof Error e) throw e;
        return new IllegalStateException(t);
    }

    private ShapeDedup() {}
}
