package ru.pasha.pashaboost.mixin.client;

import com.mojang.blaze3d.shaders.Uniform;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import net.minecraft.client.renderer.ShaderInstance;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import ru.pasha.pashaboost.OptimizationCounters;
import ru.pasha.pashaboost.RuntimeTuning;

/**
 * Vanilla ShaderInstance.apply() asks the driver for every sampler's uniform location on every
 * draw. JFR on a busy scene showed it as most of the render thread's native time. A location is
 * fixed once a program is linked, so it is remembered per program (OptiFine keeps the same call).
 */
// Each call site has a development and a production name; require = 0 so a conflicting mod only disables this.
@Mixin(value = ShaderInstance.class, remap = false)
public abstract class ShaderSamplerMixin {
    @Unique private Object2IntOpenHashMap<String> pashaboost$samplerLocations;
    @Unique private int pashaboost$samplerProgram = Integer.MIN_VALUE;

    @Redirect(method = {"apply()V", "m_173363_()V"},
            at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/shaders/Uniform;glGetUniformLocation(ILjava/lang/CharSequence;)I", remap = false),
            require = 0, remap = false)
    private int pashaboost$namedSampler(int program, CharSequence name) { return pashaboost$location(program, name); }

    @Redirect(method = {"apply()V", "m_173363_()V"},
            at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/shaders/Uniform;m_85624_(ILjava/lang/CharSequence;)I", remap = false),
            require = 0, remap = false)
    private int pashaboost$srgSampler(int program, CharSequence name) { return pashaboost$location(program, name); }

    @Unique
    private int pashaboost$location(int program, CharSequence name) {
        if (!RuntimeTuning.ACTIVE || !RuntimeTuning.SHADER_SAMPLER_CACHE) return Uniform.glGetUniformLocation(program, name);
        Object2IntOpenHashMap<String> locations = pashaboost$samplerLocations;
        if (locations == null || program != pashaboost$samplerProgram) {
            // A different program (reload, OptiFine re-link) invalidates every remembered location.
            locations = new Object2IntOpenHashMap<>();
            locations.defaultReturnValue(Integer.MIN_VALUE);
            pashaboost$samplerLocations = locations;
            pashaboost$samplerProgram = program;
        }
        String key = name.toString();
        int location = locations.getInt(key);
        if (location != Integer.MIN_VALUE) { OptimizationCounters.shaderLookupsSaved++; return location; }
        location = Uniform.glGetUniformLocation(program, name);
        locations.put(key, location);
        return location;
    }
}
