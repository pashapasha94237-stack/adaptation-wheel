package ru.pasha.pashaboost.core;

/** Rate-limits AM's pupfish tries without changing which tries run: each executed try takes the next seed index. */
public final class DeferredSearch {
    public static final int MAX_STEPS_PER_TICK = 64;
    private int owed, tick = Integer.MIN_VALUE, spent, steps;
    private boolean closed, paying;

    private void roll(int t) { if (t != tick) { tick = t; spent = 0; steps = 0; } }

    /** HEAD of searchForPupfishChunk. executed = AM's pupfishSeedAddition. true = let AM run this try now. */
    public boolean admit(int t, int allowance, boolean optimise, int executed, int freeTries) {
        if (paying) return true;           // our own repayment call
        if (closed) return false;          // 1.22.9 deadline passed: only already-owed tries still run
        roll(t);
        if (!optimise || executed < freeTries || spent < allowance) return true;
        if (owed < Integer.MAX_VALUE) owed++;
        return false;
    }
    public boolean mayPay(int t, int allowance, boolean optimise) {
        if (owed == 0 || !(optimise || closed)) return false;
        roll(t);
        return spent < allowance && steps < MAX_STEPS_PER_TICK;
    }
    public void pay()   { owed--; steps++; paying = true; }
    public void paid()  { paying = false; }
    public void spend() { spent++; }
    /** AM 1.22.9's "> 5 minutes" fired: true = hold its clock because tries are still owed. */
    public boolean holdLimit() { if (owed == 0) return false; closed = true; return true; }
    public void settle() { owed = 0; closed = false; }
    public int owed() { return owed; }
}
