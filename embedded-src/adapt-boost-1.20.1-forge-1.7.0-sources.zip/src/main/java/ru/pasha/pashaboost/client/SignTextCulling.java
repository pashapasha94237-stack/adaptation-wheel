package ru.pasha.pashaboost.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.network.chat.Style;
import net.minecraft.util.Unit;
import net.minecraft.world.level.block.entity.SignText;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import ru.pasha.pashaboost.OptimizationCounters;

import java.util.Optional;

/**
 * Render-thread test of whether one side of a sign's text would show anything. Allocation-free.
 * Side: the eye comes from the projection itself (null vector of its x, y and w rows), so bob, hurt and nausea,
 * which vanilla folds into the projection, are exact. An orthographic projection (GUI, Ponder) has no finite eye
 * and keeps vanilla behaviour. Front text sits at local z = +offset facing +z; back text is turned 180 degrees.
 * With the eye more than 1/16 block behind the board plane, every glyph of that side is back-facing. Text render
 * types keep the default CULL, so the GPU would drop them anyway, and the opaque board covers them.
 * Empty: the same styled visit Font.split uses; a side with no character emits no vertex in any projection.
 */
public final class SignTextCulling {
    private static final float SIDE_MARGIN = 1F / 16F;    // blocks; an eye inside the board keeps both sides
    private static final Optional<Unit> FOUND = Optional.of(Unit.INSTANCE);
    private static final FormattedText.StyledContentConsumer<Unit> ANY_TEXT = (style, s) -> s.isEmpty() ? Optional.empty() : FOUND;
    private static final Matrix4f MODEL = new Matrix4f(); // render thread only
    private static float eyeX, eyeY, eyeZ;

    public static boolean skip(Matrix4f pose, SignText text, boolean front) {
        if (!RenderSystem.isOnRenderThread()) return false;
        // An empty side is identical to skip in any projection, so test it first (also covers GUI and Ponder).
        if (isEmpty(text)) { OptimizationCounters.signTextEmptySidesSkipped++; return true; }
        if (hiddenSide(pose, front)) { OptimizationCounters.signTextSidesCulled++; return true; }
        return false;
    }

    private static boolean hiddenSide(Matrix4f pose, boolean front) {
        if (!eye(RenderSystem.getProjectionMatrix())) return false;
        Matrix4f mv = RenderSystem.getModelViewMatrix();
        Matrix4fc m = (mv.properties() & Matrix4fc.PROPERTY_IDENTITY) != 0 ? pose : mv.mul(pose, MODEL);
        float a0x = m.m00(), a0y = m.m01(), a0z = m.m02();
        float a1x = m.m10(), a1y = m.m11(), a1z = m.m12();
        float dx = eyeX - m.m30(), dy = eyeY - m.m31(), dz = eyeZ - m.m32();
        float nx = a0y * a1z - a0z * a1y, ny = a0z * a1x - a0x * a1z, nz = a0x * a1y - a0y * a1x;
        float det = nx * m.m20() + ny * m.m21() + nz * m.m22();
        float nLen = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
        if (!(nLen > 1.0E-6F) || !(Math.abs(det) > 1.0E-9F)) return false;        // collapsed pose
        float side = (nx * dx + ny * dy + nz * dz) / nLen;
        if (det < 0F) side = -side;                                                // mirrored pose
        return front ? side < -SIDE_MARGIN : side > SIDE_MARGIN;
    }

    /** Eye in model-view space: the point the projection maps to x = y = w = 0. False for orthographic matrices. */
    private static boolean eye(Matrix4fc p) {
        float a = p.m00(), b = p.m10(), c = p.m20(), d = p.m30();
        float e = p.m01(), f = p.m11(), g = p.m21(), h = p.m31();
        float i = p.m03(), j = p.m13(), k = p.m23(), l = p.m33();
        float w = -det3(a, b, c, e, f, g, i, j, k);
        if (!(Math.abs(w) > 1.0E-6F)) return false;
        eyeX = det3(b, c, d, f, g, h, j, k, l) / w;
        eyeY = -det3(a, c, d, e, g, h, i, k, l) / w;
        eyeZ = det3(a, b, d, e, f, h, i, j, l) / w;
        return true;
    }

    private static float det3(float a, float b, float c, float d, float e, float f, float g, float h, float i) {
        return a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g);
    }

    /** True when no line of the rendered side has a character; same array and same styled visit the renderer splits. */
    private static boolean isEmpty(SignText text) {
        for (Component line : text.getMessages(Minecraft.getInstance().isTextFilteringEnabled()))
            if (line.visit(ANY_TEXT, Style.EMPTY).isPresent()) return false;
        return true;
    }

    private SignTextCulling() {}
}
