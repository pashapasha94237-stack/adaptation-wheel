package ru.pasha.pashaboost.mixin.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.SignRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.SignText;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.pasha.pashaboost.RuntimeTuning;
import ru.pasha.pashaboost.client.SignTextCulling;

/**
 * Vanilla draws both sides of every sign's text. A side whose glyphs all face away from the camera, or a side with
 * no characters, produces nothing on screen, so it is skipped before any work. HangingSignRenderer inherits this
 * method. Idea credited to MoreCulling (GPL-3.0); no code taken.
 */
// Each method has a development and a production name; require = 0 so a conflicting mod only disables this.
// Before the first pushPose rather than at HEAD: vanilla calls nothing earlier, and OptiFine first drops signs beyond its
// text render distance or in the shadow pass, which should not pay for this check. The pose is the same at both points.
@Mixin(value = SignRenderer.class, remap = false)
public abstract class SignTextCullMixin {
    @Inject(method = {
            "renderSignText(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/entity/SignText;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;IIIZ)V",
            "m_278841_(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/entity/SignText;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;IIIZ)V"},
            at = {@At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;pushPose()V", ordinal = 0, remap = false),
                  @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;m_85836_()V", ordinal = 0, remap = false)},
            cancellable = true, require = 0, remap = false)
    private void pashaboost$cullSignText(BlockPos pos, SignText text, PoseStack poseStack, MultiBufferSource buffers,
                                         int light, int lineHeight, int maxWidth, boolean front, CallbackInfo ci) {
        if (!RuntimeTuning.ACTIVE || !RuntimeTuning.SIGN_TEXT_CULLING) return;
        if (SignTextCulling.skip(poseStack.last().pose(), text, front)) ci.cancel();
    }
}
