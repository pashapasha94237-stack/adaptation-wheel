package ru.pasha.pashaboost.mixin;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Table;
import net.minecraft.world.level.block.state.StateHolder;
import net.minecraft.world.level.block.state.properties.Property;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.pasha.pashaboost.memory.FastMap;
import ru.pasha.pashaboost.memory.FastMapStateHolder;
import ru.pasha.pashaboost.memory.StateMemory;

import java.util.Map;

/**
 * Every block and fluid state kept its own neighbour table and property map; a big modpack has hundreds of thousands
 * of states. They now share one FastMap per block (FerriteCore's technique, MIT). Applied at launch only, and only
 * once Adapt Boost has been earned: see MemoryGate.
 */
// Both names; require = 0 so a conflicting mod only disables this.
@Mixin(value = StateHolder.class, remap = false)
public abstract class StateHolderMemoryMixin<O, S> implements FastMapStateHolder<S> {
    @Shadow(aliases = {"values"}, remap = false) @Final @Mutable
    private ImmutableMap<Property<?>, Comparable<?>> f_61111_;
    @Shadow(aliases = {"neighbours"}, remap = false)
    private Table<Property<?>, Comparable<?>, S> f_61114_;
    @Unique private FastMap<S> pashaboost$map;
    @Unique private int pashaboost$index;

    @Inject(method = {"populateNeighbours(Ljava/util/Map;)V", "m_61133_(Ljava/util/Map;)V"}, at = @At("HEAD"), cancellable = true,
            require = 0, remap = false)
    private void pashaboost$populateFromFastMap(Map<Map<Property<?>, Comparable<?>>, S> states, CallbackInfo ci) {
        StateMemory.populateNeighbours(states, this);
        ci.cancel();
    }

    @Override public FastMap<S> pashaboost$stateMap() { return pashaboost$map; }
    @Override public void pashaboost$setStateMap(FastMap<S> map) { pashaboost$map = map; }
    @Override public int pashaboost$stateIndex() { return pashaboost$index; }
    @Override public void pashaboost$setStateIndex(int index) { pashaboost$index = index; }
    @Override public ImmutableMap<Property<?>, Comparable<?>> pashaboost$vanillaValues() { return f_61111_; }
    @Override public void pashaboost$replaceValues(ImmutableMap<Property<?>, Comparable<?>> newValues) { f_61111_ = newValues; }
    @Override public Table<Property<?>, Comparable<?>, S> pashaboost$neighbours() { return f_61114_; }
    @Override public void pashaboost$setNeighbours(Table<Property<?>, Comparable<?>, S> table) { f_61114_ = table; }
}
