package ru.pasha.pashaboost.mixin.client;

import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.pasha.pashaboost.client.EntityOptimizer;

/** Keep native frustum decisions; reject distant ordinary mobs before renderer setup. */
@Mixin(value=EntityRenderDispatcher.class,remap=false)
public abstract class EntityDistanceMixin {
    @Inject(method={
            "shouldRender(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/client/renderer/culling/Frustum;DDD)Z",
            "m_114397_(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/client/renderer/culling/Frustum;DDD)Z"
    },at=@At("RETURN"),cancellable=true,require=1,remap=false)
    private void pashaboost$distanceBeforeModel(Entity entity,Frustum frustum,double x,double y,double z,CallbackInfoReturnable<Boolean> result){
        if(result.getReturnValueZ()&&EntityOptimizer.cullBeforeRender(entity,x,y,z))result.setReturnValue(false);
    }
}
