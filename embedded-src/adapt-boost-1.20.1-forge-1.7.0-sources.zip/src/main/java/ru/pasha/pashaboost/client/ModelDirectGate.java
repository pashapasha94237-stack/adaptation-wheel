package ru.pasha.pashaboost.client;

import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.AnnotationNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;

import java.util.List;

/**
 * Load-time facts for the OptiFine model fast path. It names no game class: the mixin plugin calls it while the targets
 * are being transformed. Each flag turns true only after the plugin saw the final target class (postApply runs after every
 * config's mixins for that class) and found no other mod's mixin code in the methods the fast path stands in for.
 */
public final class ModelDirectGate {
    public static volatile boolean cubeClean, writerClean, spriteClean;
    private static final String MERGED = "Lorg/spongepowered/asm/mixin/transformer/meta/MixinMerged;";
    private static final String OWN = "ru.pasha.pashaboost.";

    public static void audit(String mixinClassName, ClassNode target) {
        try {
            if (mixinClassName.endsWith(".OfCubeDirectMixin"))
                cubeClean = clean(target, "compile(Lcom/mojang/blaze3d/vertex/PoseStack$Pose;Lcom/mojang/blaze3d/vertex/VertexConsumer;IIFFFF[[Lnet/optifine/render/VertexPosition;)V");
            else if (mixinClassName.endsWith(".OfCubeWriterMixin"))
                writerClean = clean(target, "addVertexFast(FFFIFFIII)V", "canAddVertexFast()Z", "m_85722_(I)V");
            else if (mixinClassName.endsWith(".OfSpriteExpanderMixin"))
                spriteClean = clean(target, "addVertexFast(FFFIFFIII)V", "canAddVertexFast()Z");
        } catch (RuntimeException | LinkageError unexpected) {
            // The flag stays false: the fast path is simply off.
        }
    }

    /** Every named method exists, none was overwritten by another mod, and none calls another mod's merged handler. */
    public static boolean clean(ClassNode target, String... methods) {
        for (String method : methods) {
            MethodNode node = find(target, method);
            if (node == null || foreign(node.visibleAnnotations) || foreign(node.invisibleAnnotations)) return false;
            for (AbstractInsnNode insn : node.instructions) {
                // Mixin names merged handlers handler$, redirect$, modify$, localvar$, constant$ (MixinExtras alike):
                // the name always has a '$' and the owning mod's id, and OptiFine's own calls here have none.
                if (insn instanceof MethodInsnNode call && call.name.indexOf('$') >= 0 && !call.name.contains("$pashaboost$")) return false;
            }
        }
        return true;
    }

    /** The ASCII text occurs in the bytes (a class file keeps a string constant as plain modified UTF-8). */
    public static boolean containsAscii(byte[] data, String text) {
        int length = text.length();
        outer:
        for (int i = 0; i + length <= data.length; i++) {
            for (int j = 0; j < length; j++) if (data[i + j] != (byte) text.charAt(j)) continue outer;
            return true;
        }
        return false;
    }

    private static MethodNode find(ClassNode target, String nameAndDesc) {
        if (target == null || target.methods == null) return null;
        for (MethodNode node : target.methods) if (nameAndDesc.equals(node.name + node.desc)) return node;
        return null;
    }

    /** A MixinMerged mark of a mixin that is not ours: another mod overwrote or added this method. QuadSortGate uses it too. */
    static boolean foreign(List<AnnotationNode> annotations) {
        if (annotations == null) return false;
        for (AnnotationNode annotation : annotations) {
            if (!MERGED.equals(annotation.desc)) continue;
            Object mixin = null;
            List<Object> values = annotation.values;
            if (values != null) for (int i = 0; i + 1 < values.size(); i += 2) if ("mixin".equals(values.get(i))) mixin = values.get(i + 1);
            if (!(mixin instanceof String name) || !name.startsWith(OWN)) return true;
        }
        return false;
    }

    private ModelDirectGate() {}
}
