package ru.pasha.pashaboost.client;

/**
 * One-entry memo for OptiFine's LevelRenderer.shouldRenderEntity set lookup (renderInfosEntities.contains(sectionKey)).
 * Entities are iterated in insertion order, so consecutive ones usually share a section. A hit needs the same set object,
 * the same epoch and the same key. The epoch is bumped before every mutation of the set (applyFrustumEntities,
 * clearRenderInfosEntities) and before the field swap (setShadowRenderInfos), always, whatever the feature flag says.
 * Render thread only; plain fields.
 */
public final class EntitySectionMemo {
    private long epoch, memoEpoch, memoKey;
    private Object memoSet;
    private boolean memoValue;

    /** The set is about to change or be replaced: forget the memo. */
    public void bump() { epoch++; }

    /** 1 or 0 when the memo holds the answer for this set and key, -1 otherwise. */
    public int peek(Object set, long key) {
        if (memoSet == set && set != null && memoEpoch == epoch && memoKey == key) return memoValue ? 1 : 0;
        return -1;
    }

    public void store(Object set, long key, boolean value) {
        memoSet = set;
        memoEpoch = epoch;
        memoKey = key;
        memoValue = value;
    }
}
