package ru.pasha.pashaboost.mixin.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.particle.SingleQuadParticle;
import org.joml.Quaternionfc;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import ru.pasha.pashaboost.OptimizationCounters;
import ru.pasha.pashaboost.RuntimeTuning;

/**
 * SingleQuadParticle.render built four new corner vectors for every particle on every frame, a few hundred MB of
 * garbage per minute with smoke and weather particles. The corners only live inside that call, so the render
 * thread reuses four.
 * <p>
 * Since 1.6 (idea from particle_core, MIT): a particle without roll turns its corners by the camera rotation itself,
 * so all such particles of a frame get the same four turned corners. They are turned once per camera rotation.
 */
// Each method has a development and a production name; require = 0 so a conflicting mod only disables this.
@Mixin(value = SingleQuadParticle.class, remap = false)
public abstract class QuadParticleVertexMixin {
    @Unique private static final Vector3f[] pashaboost$corners = {new Vector3f(), new Vector3f(), new Vector3f(), new Vector3f()};
    @Unique private static final float[] pashaboost$baseX = {-1, -1, 1, 1}, pashaboost$baseY = {-1, 1, 1, -1};
    @Unique private static final float[] pashaboost$turned = new float[12];
    @Unique private static final Vector3f pashaboost$turning = new Vector3f();
    @Unique private static float pashaboost$qx = Float.NaN, pashaboost$qy, pashaboost$qz, pashaboost$qw;

    @Redirect(method = {"render(Lcom/mojang/blaze3d/vertex/VertexConsumer;Lnet/minecraft/client/Camera;F)V",
            "m_5744_(Lcom/mojang/blaze3d/vertex/VertexConsumer;Lnet/minecraft/client/Camera;F)V"},
            at = @At(value = "NEW", target = "(FFF)Lorg/joml/Vector3f;", ordinal = 0), require = 0, remap = false)
    private Vector3f pashaboost$corner0(float x, float y, float z) { return pashaboost$corner(0, x, y, z); }

    @Redirect(method = {"render(Lcom/mojang/blaze3d/vertex/VertexConsumer;Lnet/minecraft/client/Camera;F)V",
            "m_5744_(Lcom/mojang/blaze3d/vertex/VertexConsumer;Lnet/minecraft/client/Camera;F)V"},
            at = @At(value = "NEW", target = "(FFF)Lorg/joml/Vector3f;", ordinal = 1), require = 0, remap = false)
    private Vector3f pashaboost$corner1(float x, float y, float z) { return pashaboost$corner(1, x, y, z); }

    @Redirect(method = {"render(Lcom/mojang/blaze3d/vertex/VertexConsumer;Lnet/minecraft/client/Camera;F)V",
            "m_5744_(Lcom/mojang/blaze3d/vertex/VertexConsumer;Lnet/minecraft/client/Camera;F)V"},
            at = @At(value = "NEW", target = "(FFF)Lorg/joml/Vector3f;", ordinal = 2), require = 0, remap = false)
    private Vector3f pashaboost$corner2(float x, float y, float z) { return pashaboost$corner(2, x, y, z); }

    @Redirect(method = {"render(Lcom/mojang/blaze3d/vertex/VertexConsumer;Lnet/minecraft/client/Camera;F)V",
            "m_5744_(Lcom/mojang/blaze3d/vertex/VertexConsumer;Lnet/minecraft/client/Camera;F)V"},
            at = @At(value = "NEW", target = "(FFF)Lorg/joml/Vector3f;", ordinal = 3), require = 0, remap = false)
    private Vector3f pashaboost$corner3(float x, float y, float z) { return pashaboost$corner(3, x, y, z); }

    @Redirect(method = {"render(Lcom/mojang/blaze3d/vertex/VertexConsumer;Lnet/minecraft/client/Camera;F)V",
            "m_5744_(Lcom/mojang/blaze3d/vertex/VertexConsumer;Lnet/minecraft/client/Camera;F)V"},
            at = @At(value = "INVOKE", target = "Lorg/joml/Vector3f;rotate(Lorg/joml/Quaternionfc;)Lorg/joml/Vector3f;", remap = false),
            require = 0, remap = false)
    private Vector3f pashaboost$rotate(Vector3f corner, Quaternionfc rotation) {
        int i = pashaboost$scratchIndex(corner);
        // Only the reused corners, so only the render thread, and only while they still hold vanilla's unit corner.
        if (i < 0 || !RuntimeTuning.PARTICLE_ROTATION || corner.x != pashaboost$baseX[i] || corner.y != pashaboost$baseY[i] || corner.z != 0)
            return corner.rotate(rotation);
        float qx = rotation.x(), qy = rotation.y(), qz = rotation.z(), qw = rotation.w();
        if (qx != pashaboost$qx || qy != pashaboost$qy || qz != pashaboost$qz || qw != pashaboost$qw) {
            // Only the camera's own rotation is kept: a rolled particle would evict it for every unrolled one after it.
            if (rotation != Minecraft.getInstance().gameRenderer.getMainCamera().rotation()) return corner.rotate(rotation);
            for (int c = 0; c < 4; c++) {
                pashaboost$turning.set(pashaboost$baseX[c], pashaboost$baseY[c], 0).rotate(rotation);
                pashaboost$turned[3 * c] = pashaboost$turning.x; pashaboost$turned[3 * c + 1] = pashaboost$turning.y; pashaboost$turned[3 * c + 2] = pashaboost$turning.z;
            }
            pashaboost$qx = qx; pashaboost$qy = qy; pashaboost$qz = qz; pashaboost$qw = qw;
        }
        OptimizationCounters.particleRotationsReused++;
        return corner.set(pashaboost$turned[3 * i], pashaboost$turned[3 * i + 1], pashaboost$turned[3 * i + 2]);
    }

    @Unique
    private static int pashaboost$scratchIndex(Vector3f corner) {
        for (int i = 0; i < 4; i++) if (pashaboost$corners[i] == corner) return i;
        return -1;
    }

    @Unique
    private static Vector3f pashaboost$corner(int index, float x, float y, float z) {
        // Another thread (a mod rendering particles off-thread) gets fresh vectors, as before.
        if (!RuntimeTuning.ACTIVE || !RuntimeTuning.PARTICLE_SCRATCH || !RenderSystem.isOnRenderThread()) return new Vector3f(x, y, z);
        OptimizationCounters.particleVectorsReused++;
        return pashaboost$corners[index].set(x, y, z);
    }
}
