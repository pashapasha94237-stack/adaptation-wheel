package ru.pasha.pashaboost.client;

import java.util.function.BooleanSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntFunction;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

/** Adapt Boost's flat teal look, shared by its settings screen and HUD (the video screen draws the same colours). */
final class BoostUi {
    static final int ACCENT = 0xFF67D9BD, TEXT = 0xFFE5F1ED, MUTED = 0xFFA4B7B0, FAINT = 0xFF6D817B,
            PANEL = 0xF51A2529, CARD = 0xFF213035, CARD_HOVER = 0xFF2C4045, TRACK = 0xFF2C3E43,
            GOOD = 0xFF8EE89A, WARN = 0xFFFFC66E, BAD = 0xFFFF7E6E;

    private BoostUi() {
    }

    static void background(GuiGraphics g, int width, int height) {
        g.fillGradient(0, 0, width, height, 0xF0162023, 0xF0081013);
    }

    static void panel(GuiGraphics g, int x0, int y0, int x1, int y1) {
        g.fill(x0, y0, x1, y1, PANEL);
        g.fill(x0, y0, x1, y0 + 2, ACCENT);
    }

    /** The three-bar logo from the video screen. */
    static void logo(GuiGraphics g, int x, int y) {
        g.fill(x, y, x + 4, y + 16, ACCENT);
        g.fill(x + 7, y + 5, x + 11, y + 16, 0xFF438E7D);
        g.fill(x + 14, y + 10, x + 18, y + 16, 0xFF345E55);
    }

    static int fpsColor(double fps) { return fps >= 60 ? GOOD : fps >= 30 ? WARN : BAD; }

    static void bar(GuiGraphics g, int x, int y, int width, int height, float progress, int color) {
        g.fill(x, y, x + width, y + height, TRACK);
        int filled = Mth.floor(width * Mth.clamp(progress, 0, 1));
        if (filled > 0) g.fill(x, y, x + filled, y + height, color);
    }

    /** Recent frame times as bars, newest on the right; a frame of 50 ms (20 FPS) or more fills the height. */
    static void frameGraph(GuiGraphics g, int x, int y, int width, int height, float[] millis, int next) {
        g.fill(x, y, x + width, y + height, 0x66000000);
        int count = Math.min(width / 2, millis.length);
        for (int i = 0; i < count; i++) {
            float ms = millis[Math.floorMod(next - count + i, millis.length)];
            if (ms <= 0) continue;
            int bar = Math.max(1, Math.min(height, Math.round(height * ms / 50f)));
            int left = x + width - (count - i) * 2;
            g.fill(left, y + height - bar, left + 1, y + height, fpsColor(1000.0 / ms));
        }
        // 60 FPS guide line.
        int guide = y + height - Math.round(height * 16.7f / 50f);
        g.fill(x, guide, x + width, guide + 1, 0x40FFFFFF);
    }

    static String fit(Font font, String text, int width) {
        if (width <= 0) return "";
        if (font.width(text) <= width) return text;
        return font.plainSubstrByWidth(text, Math.max(0, width - font.width("…"))) + "…";
    }

    /** A locked switch keeps its on/off colours, only dimmed, so "always on" still reads as on. */
    static void toggle(GuiGraphics g, int x, int y, boolean on, boolean active) {
        g.fill(x, y, x + 22, y + 10, on ? (active ? 0xFF2F7D69 : 0xFF244E45) : (active ? 0xFF3A4A4E : 0xFF2A3538));
        int knob = on ? x + 12 : x;
        g.fill(knob, y, knob + 10, y + 10, on ? (active ? ACCENT : 0xFF5C9A8A) : (active ? 0xFF93A5A0 : FAINT));
        if (!active) g.fill(knob + 4, y + 3, knob + 6, y + 7, 0xFF1A2529);
    }

    /** Flat button; accent buttons are teal, a selected one (current tab or preset) stays lit. */
    static class Flat extends Button {
        boolean accent, selected;

        Flat(int x, int y, int width, int height, Component message, OnPress press) {
            super(x, y, width, height, message, press, DEFAULT_NARRATION);
        }

        Flat accent() {
            accent = true;
            return this;
        }

        @Override
        protected void renderWidget(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
            boolean hot = active && isHoveredOrFocused();
            int background = selected ? 0xFF28594F : accent ? (hot ? 0xFF367663 : 0xFF2B6155) : hot ? 0xFF3A4C51 : 0xFF29363B;
            g.fill(getX(), getY(), getX() + width, getY() + height, background);
            g.fill(getX(), getY() + height - 1, getX() + width, getY() + height, selected || accent ? ACCENT : 0xFF51645F);
            renderScrollingString(g, Minecraft.getInstance().font, 3, !active && !selected ? FAINT : selected || accent ? 0xFFD8FFF0 : TEXT);
        }
    }

    /** Labelled on/off switch; a forced switch shows its effective state and cannot be pressed. */
    static class Switch extends Button {
        private final BooleanSupplier on;

        Switch(int x, int y, int width, Component label, BooleanSupplier on, OnPress press) {
            super(x, y, width, 18, label, press, DEFAULT_NARRATION);
            this.on = on;
        }

        @Override
        protected void renderWidget(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
            Font font = Minecraft.getInstance().font;
            g.fill(getX(), getY(), getX() + width, getY() + height, active && isHoveredOrFocused() ? CARD_HOVER : CARD);
            g.drawString(font, fit(font, getMessage().getString(), width - 34), getX() + 5, getY() + 5, active ? TEXT : MUTED, false);
            toggle(g, getX() + width - 26, getY() + 4, on.getAsBoolean(), active);
        }
    }

    /** Integer slider in steps; the label function sees the value the setting will get. */
    static class Slider extends AbstractSliderButton {
        private final int min, max, step;
        private final IntFunction<Component> label;
        private final IntConsumer apply;

        Slider(int x, int y, int width, int value, int min, int max, int step, IntFunction<Component> label, IntConsumer apply) {
            super(x, y, width, 18, Component.empty(), Mth.clamp((value - min) / (double) (max - min), 0, 1));
            this.min = min;
            this.max = max;
            this.step = step;
            this.label = label;
            this.apply = apply;
            updateMessage();
        }

        int current() { return Mth.clamp(min + (int) Math.round(value * (max - min) / step) * step, min, max); }

        @Override protected void updateMessage() { setMessage(label.apply(current())); }

        @Override protected void applyValue() { apply.accept(current()); }

        @Override
        public void renderWidget(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
            Font font = Minecraft.getInstance().font;
            g.fill(getX(), getY(), getX() + width, getY() + height, active && isHoveredOrFocused() ? CARD_HOVER : CARD);
            int trackY = getY() + height - 4, knob = getX() + 4 + (int) Math.round(value * (width - 12));
            g.fill(getX() + 4, trackY, getX() + width - 4, trackY + 2, TRACK);
            g.fill(getX() + 4, trackY, knob + 2, trackY + 2, active ? ACCENT : FAINT);
            g.fill(knob, trackY - 2, knob + 4, trackY + 4, active ? 0xFFD8FFF0 : FAINT);
            g.drawString(font, fit(font, getMessage().getString(), width - 10), getX() + 5, getY() + 4, active ? TEXT : MUTED, false);
        }
    }
}
