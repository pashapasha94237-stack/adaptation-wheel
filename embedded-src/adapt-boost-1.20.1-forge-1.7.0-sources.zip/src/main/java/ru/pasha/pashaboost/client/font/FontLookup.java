package ru.pasha.pashaboost.client.font;

import com.mojang.blaze3d.font.GlyphInfo;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.logging.LogUtils;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.font.CodepointMap;
import net.minecraft.client.gui.font.FontSet;
import net.minecraft.client.gui.font.glyphs.BakedGlyph;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.fml.util.ObfuscationReflectionHelper;
import org.slf4j.Logger;
import ru.pasha.pashaboost.OptimizationCounters;
import ru.pasha.pashaboost.RuntimeTuning;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;

/**
 * FontSet.getGlyphInfo/getGlyph build a bound method reference (this::computeGlyphInfo / computeBakedGlyph) on every
 * call, even for a cached glyph: 6-7 % of render-thread allocation in the sign scene. A hit is read from the same
 * CodepointMap vanilla fills; a miss runs the vanilla method, which computes and stores it as before.
 * Only plain FontSet instances, and only when no other mixin config targets FontSet.
 * Holders never throw from their initialisers; a missing glyph handle only turns the fast path off.
 */
public final class FontLookup {
    private static final Logger LOG = LogUtils.getLogger();
    private static boolean failed;

    private static boolean fast(FontSet set) {
        return RuntimeTuning.ACTIVE && RuntimeTuning.GLYPH_LOOKUP_CACHE && !failed && !FontCompat.foreignFontSetMixins
                && set.getClass() == FontSet.class && GlyphMaps.READY;
    }

    public static GlyphInfo glyphInfo(FontSet set, int codepoint, boolean notFishy) {
        if (fast(set)) {
            try {
                Object filter = ((CodepointMap<?>) GlyphMaps.GLYPH_INFOS.invokeExact(set)).get(codepoint);
                if (filter != null) {
                    if (RenderSystem.isOnRenderThread()) OptimizationCounters.glyphLookupsFast++;
                    return (GlyphInfo) GlyphMaps.SELECT.invokeExact(filter, notFishy);
                }
            } catch (Throwable t) { fail(t); }
        }
        return set.getGlyphInfo(codepoint, notFishy);
    }

    public static BakedGlyph glyph(FontSet set, int codepoint) {
        if (fast(set)) {
            try {
                Object glyph = ((CodepointMap<?>) GlyphMaps.GLYPHS.invokeExact(set)).get(codepoint);
                if (glyph != null) {
                    if (RenderSystem.isOnRenderThread()) OptimizationCounters.glyphLookupsFast++;
                    return (BakedGlyph) glyph;
                }
            } catch (Throwable t) { fail(t); }
        }
        return set.getGlyph(codepoint);
    }

    /** The real, package-private Font.getFontSet, so other mods' hooks on it (Supplementaries, Biomancy) still run. */
    public static FontSet fontSet(Font font, ResourceLocation id) {
        MethodHandle handle = FontSetCall.HANDLE;
        if (handle == null) throw new IllegalStateException("Pasha Boost: Font.getFontSet is not reachable; start with -Dpashaboost.disableGlyphLookupCache=true");
        try { return (FontSet) handle.invokeExact(font, id); }
        catch (RuntimeException | Error e) { throw e; }
        catch (Throwable t) { throw new IllegalStateException(t); }
    }

    private static void fail(Throwable t) {
        if (!failed) LOG.warn("Pasha Boost: fast glyph lookup disabled", t);
        failed = true;
    }

    /** Glyph maps of FontSet; every member may be null, READY says whether the fast path can run. */
    private static final class GlyphMaps {
        static final MethodHandle GLYPH_INFOS = getter("f_95057_");  // FontSet.glyphInfos : CodepointMap<GlyphInfoFilter>
        static final MethodHandle GLYPHS = getter("f_95056_");       // FontSet.glyphs : CodepointMap<BakedGlyph>
        static final MethodHandle SELECT = select();                 // FontSet$GlyphInfoFilter.select(Z) m_243099_
        static final boolean READY = GLYPH_INFOS != null && GLYPHS != null && SELECT != null;

        private static MethodHandle getter(String srgName) {
            try {
                return MethodHandles.lookup().unreflectGetter(ObfuscationReflectionHelper.findField(FontSet.class, srgName))
                        .asType(MethodType.methodType(CodepointMap.class, FontSet.class));
            } catch (Throwable t) { LOG.warn("Pasha Boost: FontSet.{} not found", srgName, t); return null; }
        }

        private static MethodHandle select() {
            try {
                Class<?> filter = Class.forName("net.minecraft.client.gui.font.FontSet$GlyphInfoFilter", false, FontSet.class.getClassLoader());
                Method method = ObfuscationReflectionHelper.findMethod(filter, "m_243099_", boolean.class);
                return MethodHandles.lookup().unreflect(method).asType(MethodType.methodType(GlyphInfo.class, Object.class, boolean.class));
            } catch (Throwable t) { LOG.warn("Pasha Boost: GlyphInfoFilter.select not found", t); return null; }
        }
    }

    /** Font.getFontSet by its literal development and production names, then by signature; never throws here. */
    private static final class FontSetCall {
        static final MethodHandle HANDLE = find();

        private static MethodHandle find() {
            for (String name : new String[]{"getFontSet", "m_92863_"}) {
                try {
                    Method method = Font.class.getDeclaredMethod(name, ResourceLocation.class);
                    if (method.getReturnType() == FontSet.class && !Modifier.isStatic(method.getModifiers())) {
                        method.setAccessible(true);
                        return MethodHandles.lookup().unreflect(method);
                    }
                } catch (Throwable ignored) {}
            }
            // An accessor invoker merged by another mod (Malum, EndingLibrary) has the same signature and calls getFontSet.
            for (Method method : Font.class.getDeclaredMethods()) {
                if (Modifier.isStatic(method.getModifiers()) || method.getReturnType() != FontSet.class
                        || !Arrays.equals(method.getParameterTypes(), new Class<?>[]{ResourceLocation.class})) continue;
                try { method.setAccessible(true); return MethodHandles.lookup().unreflect(method); } catch (Throwable ignored) {}
            }
            LOG.error("Pasha Boost: Font.getFontSet not found; per-draw font memo cannot run");
            return null;
        }
    }

    private FontLookup() {}
}
