package ru.pasha.pashaboost.mixin.client;

import net.minecraft.client.particle.Particle;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockAndTintGetter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import ru.pasha.pashaboost.client.SharedParticleLight;

/**
 * Particle.getLightColor asked the world for the light of the particle's block on every frame: 7.3 % of the OptiFine
 * render thread with smoke and weather particles (JFR), most of it Level.getBlockState. The lookup now goes through
 * the shared table in SharedParticleLight. This also serves subclasses that call super (PortalParticle, weather2).
 */
// The method is byte-identical in OptiFine I6's patched Particle and in Forge's (containing -> hasChunkAt -> invokestatic
// m_109541_). Each name has a development and a production form; require = 0 so a conflicting mod only disables this.
@Mixin(value = Particle.class, remap = false)
public abstract class ParticleLightShareMixin {
    @Redirect(method = {"getLightColor(F)I", "m_6355_(F)I"},
            at = @At(value = "INVOKE", remap = false, target =
                    "Lnet/minecraft/client/renderer/LevelRenderer;getLightColor(Lnet/minecraft/world/level/BlockAndTintGetter;Lnet/minecraft/core/BlockPos;)I"),
            require = 0, remap = false)
    private int pashaboost$sharedLightNamed(BlockAndTintGetter level, BlockPos pos) { return SharedParticleLight.light(level, pos); }

    @Redirect(method = {"getLightColor(F)I", "m_6355_(F)I"},
            at = @At(value = "INVOKE", remap = false, target =
                    "Lnet/minecraft/client/renderer/LevelRenderer;m_109541_(Lnet/minecraft/world/level/BlockAndTintGetter;Lnet/minecraft/core/BlockPos;)I"),
            require = 0, remap = false)
    private int pashaboost$sharedLightSrg(BlockAndTintGetter level, BlockPos pos) { return SharedParticleLight.light(level, pos); }
}
