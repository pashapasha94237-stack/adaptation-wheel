package ru.pasha.pashaboost.mixin;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import ru.pasha.pashaboost.core.CloudRainShortcut;

/** Twilight Forest 4.3.2508 coremod cloud.js puts ASMHooks.cloud(result, this, pos) before each of the 4 returns of
 *  Level.isRainingAt. Coremods (ITransformers) run before Mixin's AFTER phase, so the calls are present here. */
@Mixin(value = Level.class, remap = false)
public abstract class TwilightCloudRainMixin {
    @Redirect(method = {"isRainingAt(Lnet/minecraft/core/BlockPos;)Z", "m_46758_(Lnet/minecraft/core/BlockPos;)Z"},
            at = @At(value = "INVOKE",
                    target = "Ltwilightforest/ASMHooks;cloud(ZLnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;)Z",
                    remap = false),
            require = 0, remap = false)
    // Not static: Mixin requires the handler to match the target method (instance isRainingAt), not the static callee.
    private boolean pashaboost$cloudRain(boolean raining, Level level, BlockPos pos) {
        return CloudRainShortcut.cloud(raining, level, pos);
    }
}
