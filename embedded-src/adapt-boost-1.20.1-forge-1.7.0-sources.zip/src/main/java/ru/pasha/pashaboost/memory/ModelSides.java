package ru.pasha.pashaboost.memory;

import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.resources.model.SimpleBakedModel;
import net.minecraft.core.Direction;
import net.minecraftforge.fml.util.ObfuscationReflectionHelper;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * Every simple block or item model kept six growable face lists with spare capacity, mostly empty. They become
 * exact-size immutable lists, empty ones the shared empty list, and a model without side faces shares one map.
 * Adapted from FerriteCore 6.0.1 by malte0811 (MIT, see THIRD-PARTY.md). The fields are protected, which mixin
 * aliases cannot reach, so they are set by reflection with their SRG names.
 */
public final class ModelSides {
    /** Shared by many models, so read-only: a mod changing one model's sides fails loudly instead of changing all. */
    private static final Map<Direction, List<BakedQuad>> NO_SIDES = noSides();
    private static final MethodHandle UNCULLED = getter("f_119480_"), SET_UNCULLED = setter("f_119480_");
    private static final MethodHandle CULLED = getter("f_119481_"), SET_CULLED = setter("f_119481_");
    public static final java.util.concurrent.atomic.AtomicLong QUAD_VERTICES_SHARED = new java.util.concurrent.atomic.AtomicLong();
    /** QA counters: models compacted, quads offered for sharing, quads skipped as subclasses; why sharing is off. */
    public static final java.util.concurrent.atomic.AtomicLong MODELS_COMPACTED = new java.util.concurrent.atomic.AtomicLong(),
            QUADS_SEEN = new java.util.concurrent.atomic.AtomicLong(), QUADS_SUBCLASSED = new java.util.concurrent.atomic.AtomicLong();
    public static volatile String quadDedupOffReason = "";
    /**
     * OptiFine's SmartLeaves.getModelCull runs on every resource reload and is written to add a leaves model's quads to
     * its own side lists and clear its general list. In HD_U_I6 it looks up "<type>_leaves#normal", which 1.20.1 does not
     * register, so it returns early (a pack whose leaves lack cullfaces passed on read-only lists too), but read-only lists
     * would throw in any build where it does run. So with OptiFine the lists stay the same mutable ArrayLists, only without
     * spare capacity; retained heap differed by 19 MB, within run-to-run noise.
     */
    private static final boolean OPTIFINE = optiFine();
    private static final Map<Vertices, Vertices> VERTEX_ARRAYS = new java.util.concurrent.ConcurrentHashMap<>();
    private static volatile boolean quadDedupOff = Boolean.getBoolean("pashaboost.disableQuadDedup") || OPTIFINE;
    // BakedQuad.vertices is final; FerriteCore writes it through a @Mutable accessor, here an accessible field setter.
    private static final MethodHandle VERTICES = quadField(false), SET_VERTICES = quadField(true);

    @SuppressWarnings("unchecked")
    public static void compact(SimpleBakedModel model) throws Throwable {
        MODELS_COMPACTED.incrementAndGet();
        Map<Direction, List<BakedQuad>> sides = (Map<Direction, List<BakedQuad>>) CULLED.invoke(model);
        if (OPTIFINE) {
            trim((List<BakedQuad>) UNCULLED.invoke(model));
            if (sides != null) for (List<BakedQuad> side : sides.values()) trim(side);
            return;
        }
        SET_UNCULLED.invoke(model, compact((List<BakedQuad>) UNCULLED.invoke(model)));
        // Only the builder's own enum map is rewritten; anything else a mod passed in is left alone.
        if (!(sides instanceof EnumMap) || sides.size() != 6) return;
        boolean empty = true;
        for (Map.Entry<Direction, List<BakedQuad>> side : sides.entrySet()) {
            List<BakedQuad> compact = compact(side.getValue());
            side.setValue(compact);
            empty &= compact.isEmpty();
        }
        if (empty) SET_CULLED.invoke(model, NO_SIDES);
    }

    /** Drops the builder's spare capacity in place, so the list stays the one the model and OptiFine hold. */
    private static void trim(List<BakedQuad> quads) {
        if (quads instanceof java.util.ArrayList<BakedQuad> list) list.trimToSize();
    }

    /** An exact-size immutable copy; a list with a null quad (a broken model) is kept as it is. */
    private static List<BakedQuad> compact(List<BakedQuad> quads) {
        if (quads == null) return null;
        // contains(null) would throw on lists that are already immutable.
        for (BakedQuad quad : quads) if (quad == null) return quads;
        for (BakedQuad quad : quads) shareVertices(quad);
        return List.copyOf(quads);
    }

    /**
     * 1.7: equal vertex arrays of plain quads (full-cube faces with the same sprite and UVs, repeated across thousands of
     * models) become one array. Adapted from FerriteCore 6.0.1 bakedQuadDeduplication by malte0811 (MIT, see THIRD-PARTY.md).
     * Subclasses are skipped, and so is OptiFine, whose patched BakedQuad may rewrite vertex data for shaders.
     */
    private static void shareVertices(BakedQuad quad) {
        QUADS_SEEN.incrementAndGet();
        if (quadDedupOff) return;
        if (quad.getClass() != BakedQuad.class) { QUADS_SUBCLASSED.incrementAndGet(); return; }
        try {
            int[] vertices = (int[]) VERTICES.invokeExact(quad);
            if (vertices == null) return;
            Vertices key = new Vertices(vertices), canonical = VERTEX_ARRAYS.putIfAbsent(key, key);
            int[] shared = canonical == null ? vertices : canonical.data();
            if (shared != vertices) {
                SET_VERTICES.invokeExact(quad, shared);
                QUAD_VERTICES_SHARED.incrementAndGet();
            }
        } catch (Throwable t) {
            quadDedupOff = true;
            quadDedupOffReason = "failed: " + t;
            com.mojang.logging.LogUtils.getLogger().warn("Adapt Boost stopped sharing quad vertex arrays", t);
        }
    }

    /** After a resource reload the canonical arrays would only keep the previous models alive. */
    public static void clearVertices() { VERTEX_ARRAYS.clear(); }

    /** Content key; the hash mixes every element so similar arrays do not cluster (FerriteCore issue #129). */
    private record Vertices(int[] data, int hash) {
        Vertices(int[] data) { this(data, hash(data)); }
        private static int hash(int[] data) {
            int h = 1;
            for (int value : data) h = 31 * h + it.unimi.dsi.fastutil.HashCommon.murmurHash3(value);
            return h;
        }
        @Override public int hashCode() { return hash; }
        @Override public boolean equals(Object other) {
            return other instanceof Vertices v && v.hash == hash && java.util.Arrays.equals(v.data, data);
        }
    }

    private static Map<Direction, List<BakedQuad>> noSides() {
        Map<Direction, List<BakedQuad>> map = new EnumMap<>(Direction.class);
        for (Direction side : Direction.values()) map.put(side, List.of());
        return Collections.unmodifiableMap(map);
    }

    private static MethodHandle getter(String srgName) {
        try { return MethodHandles.lookup().unreflectGetter(ObfuscationReflectionHelper.findField(SimpleBakedModel.class, srgName)); }
        catch (IllegalAccessException e) { throw new IllegalStateException(e); }
    }

    private static MethodHandle quadField(boolean write) {
        try {
            var field = ObfuscationReflectionHelper.findField(BakedQuad.class, "f_111292_");
            MethodHandle handle = write ? MethodHandles.lookup().unreflectSetter(field) : MethodHandles.lookup().unreflectGetter(field);
            return handle.asType(write ? java.lang.invoke.MethodType.methodType(void.class, BakedQuad.class, int[].class)
                    : java.lang.invoke.MethodType.methodType(int[].class, BakedQuad.class));
        } catch (Throwable t) {
            quadDedupOff = true;
            quadDedupOffReason = "no field access: " + t;
            com.mojang.logging.LogUtils.getLogger().warn("Adapt Boost cannot share quad vertex arrays", t);
            return null;
        }
    }

    private static boolean optiFine() {
        try { Class.forName("net.optifine.Config", false, ModelSides.class.getClassLoader()); quadDedupOffReason = "OptiFine"; return true; }
        catch (ClassNotFoundException | LinkageError absent) { return false; }
    }

    private static MethodHandle setter(String srgName) {
        try { return MethodHandles.lookup().unreflectSetter(ObfuscationReflectionHelper.findField(SimpleBakedModel.class, srgName)); }
        catch (IllegalAccessException e) { throw new IllegalStateException(e); }
    }

    private ModelSides() {}
}
