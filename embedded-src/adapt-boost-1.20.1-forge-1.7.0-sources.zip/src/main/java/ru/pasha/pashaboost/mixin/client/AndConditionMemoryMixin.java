package ru.pasha.pashaboost.mixin.client;

import net.minecraft.client.renderer.block.model.multipart.AndCondition;
import net.minecraft.client.renderer.block.model.multipart.Condition;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.pasha.pashaboost.memory.ModelDedup;

import java.util.function.Predicate;

/** Shared multipart predicates, see ModelDedup. Launch-time and earned only: see MemoryGate. */
// Both names; require = 0 so a conflicting mod only disables this.
@Mixin(value = AndCondition.class, remap = false)
public abstract class AndConditionMemoryMixin {
    @Shadow(aliases = {"conditions"}, remap = false) @Final private Iterable<? extends Condition> f_111908_;

    @Inject(method = {"getPredicate(Lnet/minecraft/world/level/block/state/StateDefinition;)Ljava/util/function/Predicate;",
            "m_7289_(Lnet/minecraft/world/level/block/state/StateDefinition;)Ljava/util/function/Predicate;"},
            at = @At("HEAD"), cancellable = true, require = 0, remap = false)
    private void pashaboost$shared(StateDefinition<Block, BlockState> definition, CallbackInfoReturnable<Predicate<BlockState>> cir) {
        cir.setReturnValue(ModelDedup.and(f_111908_, definition));
    }
}
