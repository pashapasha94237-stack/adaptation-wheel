/*
 * Derived from ModernFix's compress_unihex_font mixins by embeddedt.
 * Copyright (c) 2022 ModernFix contributors.
 * SPDX-License-Identifier: LGPL-3.0-or-later
 * Pasha Boost changes, 2026-10-20: 24/32-bit support, vanilla local capture,
 * explicit development/production selectors, opt-out and allocation counters.
 */
package ru.pasha.pashaboost.mixin.client;

import it.unimi.dsi.fastutil.bytes.ByteList;
import net.minecraft.client.gui.font.providers.UnihexProvider;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;
import ru.pasha.pashaboost.OptimizationCounters;
import ru.pasha.pashaboost.RuntimeTuning;
import ru.pasha.pashaboost.client.font.CompactGlyphRows;

/** Intercepts after vanilla decoding but before allocating an array-backed record. */
@Mixin(targets = {
        "net.minecraft.client.gui.font.providers.UnihexProvider$ByteContents",
        "net.minecraft.client.gui.font.providers.UnihexProvider$ShortContents",
        "net.minecraft.client.gui.font.providers.UnihexProvider$IntContents"
}, remap = false)
public abstract class UnihexGlyphMixin {
    @Inject(method = {"read", "m_284446_"},
            at = @At(value = "NEW", target = "([B)Lnet/minecraft/client/gui/font/providers/UnihexProvider$ByteContents;", remap = false),
            cancellable = true, locals = LocalCapture.CAPTURE_FAILSOFT, require = 0, remap = false)
    private static void pashaboost$packBytes(int codepoint, ByteList encoded,
                                            CallbackInfoReturnable<UnihexProvider.LineData> cir, byte[] rows) {
        if (!RuntimeTuning.GLYPH_ACTIVE || !RuntimeTuning.GLYPH_COMPACTION || rows.length != 16) return;
        cir.setReturnValue(new CompactGlyphRows.Bytes(rows));
        OptimizationCounters.GLYPHS_COMPACTED.incrementAndGet();
        OptimizationCounters.ESTIMATED_GLYPH_BYTES_SAVED.addAndGet(CompactGlyphRows.estimatedSavedBytes(8));
    }

    @Inject(method = {"read", "m_284334_"},
            at = @At(value = "NEW", target = "([S)Lnet/minecraft/client/gui/font/providers/UnihexProvider$ShortContents;", remap = false),
            cancellable = true, locals = LocalCapture.CAPTURE_FAILSOFT, require = 0, remap = false)
    private static void pashaboost$packShorts(int codepoint, ByteList encoded,
                                             CallbackInfoReturnable<UnihexProvider.LineData> cir, short[] rows) {
        if (!RuntimeTuning.GLYPH_ACTIVE || !RuntimeTuning.GLYPH_COMPACTION || rows.length != 16) return;
        cir.setReturnValue(new CompactGlyphRows.Shorts(rows));
        OptimizationCounters.GLYPHS_COMPACTED.incrementAndGet();
        OptimizationCounters.ESTIMATED_GLYPH_BYTES_SAVED.addAndGet(CompactGlyphRows.estimatedSavedBytes(16));
    }

    @Inject(method = {"read24", "m_284350_"},
            at = @At(value = "NEW", target = "([II)Lnet/minecraft/client/gui/font/providers/UnihexProvider$IntContents;", remap = false),
            cancellable = true, locals = LocalCapture.CAPTURE_FAILSOFT, require = 0, remap = false)
    private static void pashaboost$pack24(int codepoint, ByteList encoded,
                                        CallbackInfoReturnable<UnihexProvider.LineData> cir, int[] rows) {
        if (!RuntimeTuning.GLYPH_ACTIVE || !RuntimeTuning.GLYPH_COMPACTION || rows.length != 16) return;
        cir.setReturnValue(new CompactGlyphRows.Ints(rows, 24));
        OptimizationCounters.GLYPHS_COMPACTED.incrementAndGet();
        OptimizationCounters.ESTIMATED_GLYPH_BYTES_SAVED.addAndGet(CompactGlyphRows.estimatedSavedBytes(24));
    }

    @Inject(method = {"read32", "m_284358_"},
            at = @At(value = "NEW", target = "([II)Lnet/minecraft/client/gui/font/providers/UnihexProvider$IntContents;", remap = false),
            cancellable = true, locals = LocalCapture.CAPTURE_FAILSOFT, require = 0, remap = false)
    private static void pashaboost$pack32(int codepoint, ByteList encoded,
                                        CallbackInfoReturnable<UnihexProvider.LineData> cir, int[] rows) {
        if (!RuntimeTuning.GLYPH_ACTIVE || !RuntimeTuning.GLYPH_COMPACTION || rows.length != 16) return;
        cir.setReturnValue(new CompactGlyphRows.Ints(rows, 32));
        OptimizationCounters.GLYPHS_COMPACTED.incrementAndGet();
        OptimizationCounters.ESTIMATED_GLYPH_BYTES_SAVED.addAndGet(CompactGlyphRows.estimatedSavedBytes(32));
    }
}
