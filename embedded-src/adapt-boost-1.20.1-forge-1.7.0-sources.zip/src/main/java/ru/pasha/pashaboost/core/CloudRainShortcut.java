package ru.pasha.pashaboost.core;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.fml.loading.FMLEnvironment;
import net.minecraftforge.registries.ForgeRegistries;
import ru.pasha.pashaboost.OptimizationCounters;
import ru.pasha.pashaboost.PashaBoost;
import ru.pasha.pashaboost.RuntimeTuning;

import java.util.function.Predicate;

/** Exact answer of twilightforest.ASMHooks.cloud(false, level, pos) where nothing at or above pos blocks motion.
 *  Only reached through TwilightCloudRainMixin, i.e. only when TF's coremod inserted the hook, so TF is loaded. */
public final class CloudRainShortcut {
    private static final boolean VERIFY = Boolean.getBoolean("pashaboost.verifyCloudRain");
    // Client dist only. In a userdev dedicated server RuntimeDistCleaner throws a RuntimeException for @OnlyIn(CLIENT)
    // classes, so catch Throwable; a production server simply lacks the class.
    private static final Class<?> CLIENT_LEVEL = clientLevelClass();
    // 0 unknown, 1 every cloud able to give RAIN blocks motion, -1 not so: off for this session.
    private static volatile int cloudsInHeightmap;
    public static volatile long verifyMismatches;

    public static boolean cloud(boolean raining, Level level, BlockPos pos) {
        if (raining) return true;                       // ASMHooks.cloud: iload_0; ifne 140; ... iload_0; ireturn
        if (RuntimeTuning.ACTIVE && RuntimeTuning.CLOUD_RAIN_SHORTCUT && cloudsInHeightmap() && nothingAbove(level, pos)) {
            if (level.isClientSide) OptimizationCounters.cloudRainWalksSkippedClient++;
            else OptimizationCounters.cloudRainWalksSkipped++;
            if (VERIFY && twilightforest.ASMHooks.cloud(false, level, pos)) { mismatch(level, pos); return true; }
            return false;
        }
        return twilightforest.ASMHooks.cloud(false, level, pos);
    }

    /** True only when Twilight Forest's upward walk from pos can meet no rain cloud. */
    private static boolean nothingAbove(Level level, BlockPos pos) {
        Class<?> type = level.getClass();
        // Exact vanilla levels only (subclasses such as Create's ponder level may answer getBlockState differently).
        if (level.isClientSide ? type != CLIENT_LEVEL : type != ServerLevel.class) return false;
        int y = pos.getY();
        if (y < level.getMinBuildHeight()) return false;   // walk starts in void air below the world: leave to TF
        if (y >= level.getMaxBuildHeight()) return true;   // every step reads VOID_AIR: no cloud, no blocker, false
        int x = pos.getX(), z = pos.getZ();
        // Same LevelChunk Level.getBlockState reads; null off the server thread or when not loaded -> TF decides.
        LevelChunk chunk = level.getChunkSource().getChunkNow(x >> 4, z >> 4);
        // getHeight = highest y passing MOTION_BLOCKING.isOpaque(), the exact test TF's walk stops at.
        return chunk != null && y > chunk.getHeight(Heightmap.Types.MOTION_BLOCKING, x & 15, z & 15);
    }

    private static boolean cloudsInHeightmap() {
        int known = cloudsInHeightmap;
        if (known != 0) return known > 0;
        boolean ok;
        try { ok = Twilight.everyRainCloudBlocksMotion(); }
        catch (Throwable t) { ok = false; PashaBoost.LOGGER.warn("Twilight Forest cloud check failed; cloud rain shortcut off", t); }
        if (!ok) PashaBoost.LOGGER.info("A Twilight Forest cloud that can rain does not block motion; cloud rain shortcut off");
        cloudsInHeightmap = ok ? 1 : -1;
        return ok;
    }

    private static void mismatch(Level level, BlockPos pos) {
        long n = ++verifyMismatches; // statistics only
        if (n <= 20 || n % 1000 == 0)
            PashaBoost.LOGGER.warn("Cloud rain shortcut disagrees with Twilight Forest at {} in {} ({} so far)",
                    pos, level.dimension().location(), n);
    }

    /** The only code naming Twilight Forest block classes; runs once, in game, after state caches are built. */
    private static final class Twilight {
        static boolean everyRainCloudBlocksMotion() {
            Predicate<BlockState> blocksMotion = Heightmap.Types.MOTION_BLOCKING.isOpaque();
            for (Block block : ForgeRegistries.BLOCKS.getValues()) {
                if (!(block instanceof twilightforest.block.CloudBlock cloud)) continue;
                // 4.3.2508: getCurrentPrecipitation returns getPrecipitation() whenever non-null; WispyCloudBlock overrides
                // neither. Any other subclass is held to the strict rule.
                String name = block.getClass().getName();
                boolean known = name.equals("twilightforest.block.CloudBlock") || name.equals("twilightforest.block.WispyCloudBlock");
                Biome.Precipitation own = known ? cloud.getPrecipitation() : null;
                if (own != null && own != Biome.Precipitation.RAIN) continue;       // wispy NONE, snowy SNOW
                for (BlockState state : block.getStateDefinition().getPossibleStates())
                    if (!blocksMotion.test(state)) return false;                    // rainy (RAIN), fluffy (null) must block
            }
            return true;
        }
    }

    private static Class<?> clientLevelClass() {
        if (!FMLEnvironment.dist.isClient()) return null;
        try { return Class.forName("net.minecraft.client.multiplayer.ClientLevel", false, Level.class.getClassLoader()); }
        catch (Throwable absent) { return null; }
    }
    private CloudRainShortcut() {}
}
