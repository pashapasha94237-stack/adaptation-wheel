package ru.pasha.pashaboost.mixin.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexBuffer;
import net.minecraft.client.renderer.ShaderInstance;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import ru.pasha.pashaboost.OptimizationCounters;
import ru.pasha.pashaboost.RuntimeTuning;

/**
 * VertexBuffer._drawWithShader binds the twelve shader texture slots by name before every draw:
 * {@code for (i = 0; i < 12; i++) shader.setSampler("Sampler" + i, RenderSystem.getShaderTexture(i))}.
 * Each name is a new String with a new byte[], and the sampler HashMap then hashes that fresh string.
 * JFR, base427 scenes without OptiFine: 10.7 % (24 mods) to 36 % (vanilla) of all render-thread allocation,
 * StringLatin1.hashCode 1.4-1.8 % self.
 * <p>
 * The loop reads its bound (the constant 12, the only one in the method) before every pass. At the first read this
 * makes the same calls in the same order with the same keys and values, but with constant names whose hash is cached,
 * and answers 0, so vanilla's own loop body never runs. Same idea as Embeddium's VertexBufferMixin (LGPL-3.0); own code.
 */
// Both names; require = 0 so a conflicting mod only disables this. The plugin skips it with OptiFine (it patches
// VertexBuffer, ShaderInstance and RenderSystem) and next to Embeddium/Oculus, which do the same.
@Mixin(value = VertexBuffer.class, remap = false)
public abstract class SamplerNameMixin {
    @Unique private static String[] pashaboost$names = pashaboost$names(16);

    @ModifyConstant(method = {"_drawWithShader(Lorg/joml/Matrix4f;Lorg/joml/Matrix4f;Lnet/minecraft/client/renderer/ShaderInstance;)V",
            "m_166876_(Lorg/joml/Matrix4f;Lorg/joml/Matrix4f;Lnet/minecraft/client/renderer/ShaderInstance;)V"},
            constant = @Constant(intValue = 12), require = 0, remap = false)
    private int pashaboost$bindSamplers(int slots, Matrix4f modelView, Matrix4f projection, ShaderInstance shader) {
        // The method only runs on the render thread (it draws); the check keeps the shared name table single-threaded anyway.
        if (!RuntimeTuning.ACTIVE || !RuntimeTuning.SAMPLER_NAME_CACHE || !RenderSystem.isOnRenderThread()) return slots;
        String[] names = pashaboost$names;
        if (names.length < slots) pashaboost$names = names = pashaboost$names(slots); // another mod raised the slot count
        for (int i = 0; i < slots; i++) {
            int texture = RenderSystem.getShaderTexture(i);
            shader.setSampler(names[i], texture); // boxed by Integer.valueOf, exactly as vanilla
        }
        OptimizationCounters.samplerNamesReused += slots;
        return 0; // i (0) < 0 is false: vanilla's loop is done
    }

    @Unique
    private static String[] pashaboost$names(int count) {
        String[] names = new String[count];
        for (int i = 0; i < count; i++) names[i] = ("Sampler" + i).intern();
        return names;
    }
}
