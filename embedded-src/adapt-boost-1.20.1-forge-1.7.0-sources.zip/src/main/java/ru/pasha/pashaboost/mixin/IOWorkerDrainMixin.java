package ru.pasha.pashaboost.mixin;

import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.world.level.chunk.storage.IOWorker;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.pasha.pashaboost.OptimizationCounters;
import ru.pasha.pashaboost.RuntimeTuning;
import ru.pasha.pashaboost.core.WriteDrainBudget;

/** Helps an overloaded vanilla I/O mailbox release pending NBT without crossing threads. */
@Mixin(value = IOWorker.class, remap = false)
public abstract class IOWorkerDrainMixin {
    @Shadow(aliases = {"pendingWrites"}, remap = false)
    @Final
    private Map<?, ?> f_63519_;

    @Shadow(aliases = {"shutdownRequested"}, remap = false)
    @Final
    private AtomicBoolean f_63516_;

    @Shadow(aliases = {"m_63553_"}, remap = false)
    private void storePendingChunk() {
        throw new AssertionError("Mixin shadow");
    }

    @Unique
    private final WriteDrainBudget pashaBoost$writeDrainBudget = new WriteDrainBudget();

    @Unique
    private boolean pashaBoost$drainingWrites;

    @Inject(method = {"tellStorePending()V", "m_63561_()V"}, at = @At("HEAD"), remap = false, require = 1)
    private void pashaBoost$drainBacklog(CallbackInfo callback) {
        // Both vanilla call sites run inside the mailbox: the foreground submitTask closure
        // and the background storePendingChunk task. Draining here also prevents a stream
        // of foreground tasks from indefinitely starving background writes.
        if (pashaBoost$drainingWrites || !RuntimeTuning.ACTIVE || !RuntimeTuning.WRITE_BACKPRESSURE || f_63516_.get()
                || f_63519_.size() <= RuntimeTuning.WRITE_THRESHOLD) {
            return;
        }
        pashaBoost$writeDrainBudget.begin(RuntimeTuning.WRITE_THRESHOLD, RuntimeTuning.WRITE_BURST,
                RuntimeTuning.WRITE_BUDGET_NANOS, System.nanoTime());
        pashaBoost$drainingWrites = true;
        try {
            while (RuntimeTuning.ACTIVE && RuntimeTuning.WRITE_BACKPRESSURE && !f_63516_.get()
                    && pashaBoost$writeDrainBudget.tryAcquire(f_63519_.size(), System.nanoTime())) {
                // Preserve vanilla ordering, last-write coalescing, completion futures and error handling.
                // Its nested tellStorePending returns immediately from this hook via the guard.
                storePendingChunk();
                OptimizationCounters.EXTRA_NBT_WRITES.incrementAndGet();
            }
        } finally {
            pashaBoost$drainingWrites = false;
        }
    }
}
