package ru.pasha.pashaboost.mixin.client;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.SpriteCoordinateExpander;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import ru.pasha.pashaboost.client.OfSpriteExpander;

/**
 * Lets the OptiFine cube fast path see through a SpriteCoordinateExpander (chests, banners, other Material-based models).
 * OptiFine I6's own addVertexFast here only maps u and v through the sprite and forwards the rest to the delegate.
 */
// Gated with the other OptiFine I6 mixins: the plugin's audit of this class looks at OptiFine-only methods. Both fields are
// private, so the development name works as an alias.
@Mixin(value = SpriteCoordinateExpander.class, remap = false)
public abstract class OfSpriteExpanderMixin implements OfSpriteExpander {
    @Shadow(aliases = {"delegate"}, remap = false) @Final private VertexConsumer f_110795_;
    @Shadow(aliases = {"sprite"}, remap = false) @Final private TextureAtlasSprite f_110796_;

    @Override public VertexConsumer pashaboost$delegate() { return this.f_110795_; }
    @Override public TextureAtlasSprite pashaboost$sprite() { return this.f_110796_; }
}
