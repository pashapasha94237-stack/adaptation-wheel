package ru.pasha.pashaboost.core;

import com.google.common.primitives.Floats;
import com.mojang.blaze3d.vertex.VertexSorting;
import it.unimi.dsi.fastutil.ints.IntArrays;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import org.joml.Vector3f;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import ru.pasha.pashaboost.client.QuadSort;
import ru.pasha.pashaboost.client.QuadSortGate;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.Arrays;
import java.util.Random;

/**
 * The quad sort against vanilla's own classes: the real VertexSorting.DISTANCE_TO_ORIGIN / ORTHOGRAPHIC_Z (fastutil
 * IntArrays.mergeSort with Floats.compare(key[b], key[a])), a statement-for-statement copy of makeQuadSortingPoints and of
 * putSortedQuadIndices' IntConsumer writes, on random data full of ties, NaN, -0.0 / +0.0 and infinities.
 */
public final class QuadSortTest {
    private static final float[] SPECIAL = {0.0F, -0.0F, 1.0F, -1.0F, 0.5F, -0.5F, 2.0F, 3.0F, Float.POSITIVE_INFINITY, Float.NEGATIVE_INFINITY,
            Float.NaN, Float.MIN_VALUE, -Float.MIN_VALUE, Float.MAX_VALUE, -Float.MAX_VALUE, 1.0E-20F, -1.0E-20F, 100.0F, -100.0F, 16.0F};

    public static void main(String[] args) {
        packOrderMatchesFloatCompare();
        permutationMatchesVanilla();
        referenceSortIsVanillasSort();
        centroidsAreVanillasPoints();
        indicesAreVanillasBytes();
        materializedPointsAreVanillasPoints();
        installCheckMatchesMergedHandlerNames();
        spritesResolverReadsPrivateField();
        foreignInjectorsCloseTheFastPath();
        System.out.println("QuadSortTest: 9 scenarios passed");
    }

    private static void check(boolean ok, String what) { if (!ok) throw new AssertionError(what); }

    /** pack(): longs ascending == Float.compare descending, then index ascending, for every pair of special and random values. */
    private static void packOrderMatchesFloatCompare() {
        Random r = new Random(11);
        float[] values = new float[SPECIAL.length + 400];
        System.arraycopy(SPECIAL, 0, values, 0, SPECIAL.length);
        for (int i = SPECIAL.length; i < values.length; i++)
            values[i] = r.nextInt(4) == 0 ? Float.intBitsToFloat(r.nextInt()) : (r.nextFloat() - 0.5F) * (1 << r.nextInt(12));
        for (float a : values)
            for (float b : values) {
                int vanilla = Floats.compare(b, a); // the comparator's value for ordering a before b: a goes first when key a is larger
                long la = QuadSort.pack(a, 5), lb = QuadSort.pack(b, 9);
                int expect = vanilla != 0 ? vanilla : Integer.compare(5, 9);
                check(Integer.signum(Long.compare(la, lb)) == Integer.signum(expect), "pack order for " + a + " vs " + b);
            }
        // Equal keys order by index, including NaNs of different bit patterns and both zeros.
        check(QuadSort.pack(Float.intBitsToFloat(0x7fc00001), 3) < QuadSort.pack(Float.NaN, 4), "NaN payloads are one key");
        check(QuadSort.pack(-0.0F, 7) > QuadSort.pack(0.0F, 7), "-0.0 sorts after +0.0 in descending order");
    }

    /** One vertex buffer: j ints per vertex, 4 vertices per quad, positions from the pool, the rest arbitrary bits. */
    private static FloatBuffer vertices(Random r, int quads, int base, int j, int pool, boolean wild) {
        ByteBuffer bytes = ByteBuffer.allocateDirect((base + quads * 4 * j + 3) * 4).order(ByteOrder.nativeOrder());
        FloatBuffer fb = bytes.asFloatBuffer();
        for (int i = 0; i < fb.capacity(); i++) fb.put(i, Float.intBitsToFloat(r.nextInt()));
        for (int q = 0; q < quads; q++)
            for (int v = 0; v < 4; v++)
                for (int c = 0; c < 3; c++) {
                    float x;
                    if (wild && r.nextInt(3) == 0) x = SPECIAL[r.nextInt(SPECIAL.length)];
                    else x = pool > 0 ? (r.nextInt(pool) - pool / 2) * 0.25F : (r.nextFloat() - 0.5F) * 64.0F;
                    fb.put(base + (q * 4 + v) * j + c, x);
                }
        return fb;
    }

    /** makeQuadSortingPoints, as javap shows it in both OptiFine's and Forge's BufferBuilder. */
    private static Vector3f[] vanillaPoints(FloatBuffer fb, int i, int j, int vertices) {
        int primitiveStride = 4;
        int k = j * primitiveStride;
        int n = vertices / primitiveStride;
        Vector3f[] points = new Vector3f[n];
        for (int l = 0; l < n; l++) {
            float f = fb.get(i + l * k + 0), f1 = fb.get(i + l * k + 1), f2 = fb.get(i + l * k + 2);
            float f3 = fb.get(i + l * k + j * 2 + 0), f4 = fb.get(i + l * k + j * 2 + 1), f5 = fb.get(i + l * k + j * 2 + 2);
            points[l] = new Vector3f((f + f3) / 2.0F, (f1 + f4) / 2.0F, (f2 + f5) / 2.0F);
        }
        return points;
    }

    private static int[] fastOrder(FloatBuffer fb, int base, int j, int quads, boolean distance) {
        float[] c = new float[quads * 3 + 5];
        QuadSort.centroids(fb, base, j, 4, quads, c);
        long[] keys = new long[quads + 2];
        QuadSort.keys(c, quads, distance, keys, new Vector3f());
        QuadSort.sort(keys, quads);
        int[] order = new int[quads];
        for (int t = 0; t < quads; t++) order[t] = (int) keys[t];
        return order;
    }

    private static void permutationMatchesVanilla() {
        Random r = new Random(1234);
        int[] sizes = {0, 1, 2, 3, 5, 7, 16, 31, 32, 33, 64, 100, 257, 1000, 4095, 4096, 4097, 5000, 20000};
        int cases = 0;
        for (int round = 0; round < 6; round++)
            for (int n : sizes) {
                int j = new int[]{3, 4, 6, 7, 8, 9, 12}[r.nextInt(7)];
                int base = r.nextInt(3) == 0 ? 0 : r.nextInt(40);
                int pool = round % 3 == 0 ? 3 : round % 3 == 1 ? 40 : 0; // heavy ties, some ties, none
                FloatBuffer fb = vertices(r, n, base, j, pool, round >= 3);
                Vector3f[] points = vanillaPoints(fb, base, j, n * 4);
                for (boolean distance : new boolean[]{true, false}) {
                    VertexSorting sorting = distance ? VertexSorting.DISTANCE_TO_ORIGIN : VertexSorting.ORTHOGRAPHIC_Z;
                    int[] vanilla = sorting.sort(points);
                    int[] fast = fastOrder(fb, base, j, n, distance);
                    check(Arrays.equals(vanilla, fast), "permutation n=" + n + " j=" + j + " base=" + base + " pool=" + pool + " round=" + round + (distance ? " distance" : " ortho"));
                    cases++;
                }
            }
        check(cases == 6 * sizes.length * 2, "case count");
    }

    /** The stability argument itself: vanilla's result is keys descending under Float.compare with ties by index. */
    private static void referenceSortIsVanillasSort() {
        Random r = new Random(77);
        for (int round = 0; round < 200; round++) {
            int n = r.nextInt(300);
            FloatBuffer fb = vertices(r, n, 0, 8, round % 2 == 0 ? 3 : 0, true);
            Vector3f[] points = vanillaPoints(fb, 0, 8, n * 4);
            float[] keys = new float[n];
            int[] ref = new int[n];
            Vector3f origin = new Vector3f(0.0F, 0.0F, 0.0F);
            for (int i = 0; i < n; i++) { keys[i] = origin.distanceSquared(points[i]); ref[i] = i; }
            final float[] k = keys;
            IntArrays.mergeSort(ref, (a, b) -> Floats.compare(k[b], k[a]));
            check(Arrays.equals(ref, VertexSorting.DISTANCE_TO_ORIGIN.sort(points)), "reference merge sort = vanilla distance sort, round " + round);
            Integer[] boxed = new Integer[n];
            for (int i = 0; i < n; i++) boxed[i] = i;
            Arrays.sort(boxed, (a, b) -> { int c = Floats.compare(k[b], k[a]); return c != 0 ? c : Integer.compare(a, b); });
            for (int i = 0; i < n; i++) check(boxed[i] == ref[i], "descending keys with ties by index, round " + round);
        }
    }

    private static void centroidsAreVanillasPoints() {
        Random r = new Random(5);
        for (int round = 0; round < 60; round++) {
            int n = r.nextInt(80), j = 3 + r.nextInt(10), base = r.nextInt(50);
            FloatBuffer fb = vertices(r, n, base, j, 0, true);
            Vector3f[] points = vanillaPoints(fb, base, j, n * 4);
            float[] c = new float[n * 3];
            QuadSort.centroids(fb, base, j, 4, n, c);
            for (int q = 0; q < n; q++) {
                check(Float.floatToRawIntBits(c[q * 3]) == Float.floatToRawIntBits(points[q].x), "centroid x " + q);
                check(Float.floatToRawIntBits(c[q * 3 + 1]) == Float.floatToRawIntBits(points[q].y), "centroid y " + q);
                check(Float.floatToRawIntBits(c[q * 3 + 2]) == Float.floatToRawIntBits(points[q].z), "centroid z " + q);
            }
        }
        // A buffer that is too short fails like vanilla's reads do (the mixin then leaves the batch to vanilla).
        FloatBuffer small = FloatBuffer.allocate(20);
        boolean threw = false;
        try { QuadSort.centroids(small, 0, 8, 4, 2, new float[6]); } catch (RuntimeException e) { threw = true; }
        check(threw, "out-of-range read throws");
    }

    /** putSortedQuadIndices' write loop through IntConsumer-style absolute puts. */
    private static void vanillaWrite(ByteBuffer buffer, int offset, int[] order, boolean shortIndices) {
        int[] off = {offset};
        int stride = 4;
        for (int idx : order) {
            for (int add : new int[]{0, 1, 2, 2, 3, 0}) {
                int value = idx * stride + add;
                if (shortIndices) { buffer.putShort(off[0], (short) value); off[0] += 2; }
                else { buffer.putInt(off[0], value); off[0] += 4; }
            }
        }
    }

    private static void indicesAreVanillasBytes() {
        Random r = new Random(99);
        for (int round = 0; round < 80; round++) {
            int n = round < 10 ? round : r.nextInt(3000);
            if (round == 79) n = 20000; // above the short range: (short) narrowing must match
            int j = 7 + r.nextInt(3), base = r.nextInt(20);
            FloatBuffer fb = vertices(r, n, base, j, round % 2 == 0 ? 5 : 0, true);
            int[] order = fastOrder(fb, base, j, n, round % 3 != 0);
            for (boolean shortIndices : new boolean[]{true, false}) {
                int offset = r.nextInt(64) * 2, size = offset + n * 24 + 16;
                byte[] fill = new byte[size];
                r.nextBytes(fill);
                ByteBuffer a = ByteBuffer.allocateDirect(size).order(ByteOrder.nativeOrder()), b = ByteBuffer.allocateDirect(size).order(ByteOrder.nativeOrder());
                a.put(0, fill); b.put(0, fill);
                vanillaWrite(a, offset, order, shortIndices);
                long[] keys = new long[n];
                for (int t = 0; t < n; t++) keys[t] = order[t];
                QuadSort.write(b, offset, keys, n, 4, shortIndices);
                check(a.equals(b), "index bytes round " + round + (shortIndices ? " short" : " int"));
                // The pattern per quad is vanilla's {0,1,2,2,3,0} + 4 * index.
                if (n > 0 && !shortIndices) check(b.getInt(offset + 12) == b.getInt(offset + 8) && b.getInt(offset + 20) == b.getInt(offset), "quad pattern");
            }
        }
        // 20000 quads address vertices past 65535: the short wraps exactly as vanilla's (short) cast does.
        long[] keys = {19999};
        ByteBuffer wrap = ByteBuffer.allocateDirect(12).order(ByteOrder.nativeOrder());
        QuadSort.write(wrap, 0, keys, 1, 4, true);
        check(wrap.getShort(0) == (short) (19999 * 4) && wrap.getShort(8) == (short) (19999 * 4 + 3), "short narrowing");
    }

    private static void materializedPointsAreVanillasPoints() {
        Random r = new Random(3);
        FloatBuffer fb = vertices(r, 50, 4, 8, 0, true);
        Vector3f[] points = vanillaPoints(fb, 4, 8, 200);
        float[] c = new float[150];
        QuadSort.centroids(fb, 4, 8, 4, 50, c);
        Vector3f[] made = QuadSort.materialize(c, 50);
        check(made.length == 50, "length");
        for (int q = 0; q < 50; q++)
            check(Float.floatToRawIntBits(made[q].x) == Float.floatToRawIntBits(points[q].x) && Float.floatToRawIntBits(made[q].y) == Float.floatToRawIntBits(points[q].y)
                    && Float.floatToRawIntBits(made[q].z) == Float.floatToRawIntBits(points[q].z), "materialized point " + q);
        check(QuadSort.materialize(null, 0).length == 0, "empty");
    }

    private static MethodNode method(ClassNode owner, String name, String... calls) {
        MethodNode m = new MethodNode(Opcodes.ACC_PUBLIC, name, "()V", null, null);
        for (String call : calls) m.instructions.add(new MethodInsnNode(Opcodes.INVOKESPECIAL, owner.name, call, "()V", false));
        owner.methods.add(m);
        return m;
    }

    /** Mixin 0.8.5 names a merged handler handler$<class uid><method uid>$<source name>; the plugin must find all three. */
    private static void installCheckMatchesMergedHandlerNames() {
        ClassNode full = new ClassNode();
        full.name = "com/mojang/blaze3d/vertex/BufferBuilder";
        method(full, "m_277127_", "handler$zzf000$pashaboost$quadSortBegin");
        method(full, "m_166770_", "handler$zzf001$pashaboost$quadSortState");
        method(full, "m_166786_", "handler$zzf002$pashaboost$quadSortWrite");
        method(full, "m_231177_", "m_166786_");
        check(QuadSortGate.installed(full), "all three merged, SRG names");

        ClassNode dev = new ClassNode();
        dev.name = full.name;
        method(dev, "setQuadSorting", "handler$abc123$pashaboost$quadSortBegin");
        method(dev, "getSortState", "handler$abc124$pashaboost$quadSortState");
        method(dev, "putSortedQuadIndices", "pashaboost$quadSortWrite");
        check(QuadSortGate.installed(dev), "development names, unrenamed source name");

        ClassNode missing = new ClassNode();
        missing.name = full.name;
        method(missing, "m_277127_", "handler$zzf000$pashaboost$quadSortBegin");
        method(missing, "m_166786_", "handler$zzf002$pashaboost$quadSortWrite");
        check(!QuadSortGate.installed(missing), "getSortState handler missing");

        ClassNode wrongMethod = new ClassNode();
        wrongMethod.name = full.name;
        method(wrongMethod, "m_277127_", "handler$zzf000$pashaboost$quadSortBegin", "handler$zzf001$pashaboost$quadSortState");
        method(wrongMethod, "m_166786_", "handler$zzf002$pashaboost$quadSortWrite");
        check(!QuadSortGate.installed(wrongMethod), "a handler called from the wrong method does not count");

        ClassNode otherName = new ClassNode();
        otherName.name = full.name;
        method(otherName, "m_277127_", "handler$zzf000$other$quadSortBegin");
        method(otherName, "m_166770_", "handler$zzf001$pashaboost$quadSortState");
        method(otherName, "m_166786_", "handler$zzf002$pashaboost$quadSortWrite");
        check(!QuadSortGate.installed(otherName), "another mod's handler with a similar name does not count");

        check(!QuadSortGate.installed(new ClassNode()) && !QuadSortGate.READY, "empty class, flag untouched");
    }

    /** OptiFine's shape: a private TextureAtlasSprite[] quadSprites; the resolver must read it from another class. */
    private static final class WithSprites {
        private TextureAtlasSprite[] quadSprites;
    }

    private static final class WithoutSprites {
        private int other;
    }

    private static final class WrongType {
        private Object[] quadSprites = new Object[0];
    }

    private static final class StaticField {
        private static TextureAtlasSprite[] quadSprites = new TextureAtlasSprite[0];
    }

    /** Both sides of QuadSort.Sprites on fixtures, so a private field cannot silently turn the feature off again. */
    private static void spritesResolverReadsPrivateField() {
        QuadSort.Sprites.Getter with = QuadSort.Sprites.Getter.resolve(WithSprites.class);
        check(with.ok(), "private quadSprites resolves (getter form honours setAccessible)");
        WithSprites b = new WithSprites();
        check(!with.present(b), "null quadSprites is not present");
        b.quadSprites = new TextureAtlasSprite[2];
        check(with.present(b), "non-null quadSprites is present");
        b.quadSprites = new TextureAtlasSprite[0];
        check(with.present(b), "empty non-null array is present");
        b.quadSprites = null;
        check(!with.present(b), "null again");
        check(with.present(new Object()), "an unreadable receiver means fall back");

        QuadSort.Sprites.Getter none = QuadSort.Sprites.Getter.resolve(WithoutSprites.class);
        check(none.ok() && !none.present(new WithoutSprites()), "plain Forge: no field, ok, never present");

        check(!QuadSort.Sprites.Getter.resolve(WrongType.class).ok(), "field of another type is not ok");
        check(!QuadSort.Sprites.Getter.resolve(StaticField.class).ok(), "static field is not ok");
        QuadSort.Sprites.Getter bad = QuadSort.Sprites.Getter.resolve(WrongType.class);
        check(bad.present(new WrongType()), "not ok means present (fallback)");

        // The loaded dev BufferBuilder has no quadSprites: the real holder must be ok.
        check(QuadSort.Sprites.OK, "BufferBuilder without OptiFine is ok");
    }

    /** Another mod's merged injector on the bypassed code keeps the fast path closed. */
    private static void foreignInjectorsCloseTheFastPath() {
        ClassNode base = new ClassNode();
        base.name = "com/mojang/blaze3d/vertex/BufferBuilder";
        method(base, "m_277127_", "handler$zzf000$pashaboost$quadSortBegin");
        method(base, "m_166770_", "handler$zzf001$pashaboost$quadSortState");
        method(base, "m_166786_", "handler$zzf002$pashaboost$quadSortWrite");
        check(QuadSortGate.installed(base), "baseline");
        for (String foreign : new String[] {"handler$abc123$othermod$onSort", "redirect$abc123$othermod$x", "modifyArg$abc123$othermod$y",
                "wrapOperation$abc123$othermod$z", "localvar$abc123$othermod$v", "constant$abc123$othermod$c", "args$abc123$othermod$a"}) {
            for (String where : new String[] {"m_277127_", "m_166794_", "m_166786_", "putSortedQuadIndices", "m_231158_", "lambda$getIntConsumer$0"}) {
                ClassNode c = new ClassNode();
                c.name = base.name;
                method(c, "m_277127_", "handler$zzf000$pashaboost$quadSortBegin");
                method(c, "m_166770_", "handler$zzf001$pashaboost$quadSortState");
                method(c, "m_166786_", "handler$zzf002$pashaboost$quadSortWrite");
                method(c, where, foreign);
                check(!QuadSortGate.installed(c), foreign + " on " + where);
            }
        }
        ClassNode elsewhere = new ClassNode();
        elsewhere.name = base.name;
        method(elsewhere, "m_277127_", "handler$zzf000$pashaboost$quadSortBegin");
        method(elsewhere, "m_166770_", "handler$zzf001$pashaboost$quadSortState", "handler$abc$othermod$onState");
        method(elsewhere, "m_166786_", "handler$zzf002$pashaboost$quadSortWrite", "lambda$x$0");
        check(QuadSortGate.installed(elsewhere), "a foreign hook on getSortState or a lambda call does not matter");
        // An @Overwrite leaves only Mixin's MixinMerged mark on the method; ours may carry one.
        for (String mixin : new String[] {"com.example.mixin.BufferBuilderMixin", "ru.pasha.pashaboost.mixin.client.QuadSortMixin"}) {
            ClassNode overwritten = new ClassNode();
            overwritten.name = base.name;
            method(overwritten, "m_277127_", "handler$zzf000$pashaboost$quadSortBegin");
            method(overwritten, "m_166770_", "handler$zzf001$pashaboost$quadSortState");
            method(overwritten, "m_166786_", "handler$zzf002$pashaboost$quadSortWrite");
            org.objectweb.asm.tree.AnnotationNode merged = new org.objectweb.asm.tree.AnnotationNode("Lorg/spongepowered/asm/mixin/transformer/meta/MixinMerged;");
            merged.values = new java.util.ArrayList<>(java.util.List.of("mixin", mixin, "priority", 1000));
            method(overwritten, "m_166794_").visibleAnnotations = new java.util.ArrayList<>(java.util.List.of(merged));
            check(QuadSortGate.installed(overwritten) == mixin.startsWith("ru.pasha.pashaboost."), "overwrite by " + mixin);
        }
    }

    private QuadSortTest() {}
}
