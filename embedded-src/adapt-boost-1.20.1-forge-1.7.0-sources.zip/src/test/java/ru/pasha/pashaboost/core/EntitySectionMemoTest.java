package ru.pasha.pashaboost.core;

import ru.pasha.pashaboost.client.EntitySectionMemo;

public final class EntitySectionMemoTest {
    public static void main(String[] args) {
        EntitySectionMemo m = new EntitySectionMemo();
        Object a = new Object(), b = new Object();
        assert m.peek(a, 5) == -1 : "empty";
        assert m.peek(null, 0) == -1 : "null set never hits";
        m.store(a, 5, true);
        assert m.peek(a, 5) == 1;
        assert m.peek(a, 6) == -1 : "other key";
        assert m.peek(b, 5) == -1 : "other set identity";
        m.store(a, 5, false);
        assert m.peek(a, 5) == 0 : "false is memoised";
        m.bump();
        assert m.peek(a, 5) == -1 : "epoch bump";
        m.store(a, 5, true);
        m.bump(); m.bump();
        m.store(b, 5, false);
        assert m.peek(a, 5) == -1 && m.peek(b, 5) == 0 : "one entry only";
        System.out.println("EntitySectionMemo: 9 checks passed");
    }
}
