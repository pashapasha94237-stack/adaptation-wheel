package ru.pasha.pashaboost.core;

public final class VisibilityCacheTest {
    public static void main(String[] args) {
        VisibilityCache c=new VisibilityCache(2);
        assert c.get(1,1,0,0,0,0,0,0,0)==null;
        c.put(1,10,10,5,0,0,0,1,1,1,true);
        assert c.get(1,10,11,0,0,0,1,1,1)==Boolean.TRUE;
        assert c.get(1,10,15,0,0,0,1,1,1)==null : "expiry";
        assert c.get(1,10,9,0,0,0,1,1,1)==null : "world time rollback";
        assert c.get(1,11,11,0,0,0,1,1,1)==null : "entity ID reused";
        assert c.get(1,10,11,1,0,0,1,1,1)==null : "camera moved";
        assert c.get(1,10,11,0,0,0,2,1,1)==null : "entity moved";
        c.put(3,30,10,5,0,0,0,1,1,1,false);
        assert c.get(1,10,11,0,0,0,1,1,1)==null : "collision is a safe miss";
        assert c.get(3,30,11,0,0,0,1,1,1)==Boolean.FALSE;
        c.clear();
        assert c.get(3,30,11,0,0,0,1,1,1)==null;
        assert c.capacity()==2;
        System.out.println("VisibilityCache: 11 checks passed");
    }
}
