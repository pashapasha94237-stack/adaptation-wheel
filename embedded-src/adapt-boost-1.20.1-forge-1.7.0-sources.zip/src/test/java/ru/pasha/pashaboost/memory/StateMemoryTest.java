package ru.pasha.pashaboost.memory;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Table;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.state.properties.AttachFace;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.properties.Property;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Builds states the way StateDefinition does and checks the FastMap views against vanilla's tables. */
public final class StateMemoryTest {
    public static void main(String[] args) {
        // Bool and int fast paths, the six-way vanilla facing order, a horizontal facing (generic indexer) and an enum.
        List<Property<?>> properties = List.of(BooleanProperty.create("lit"), IntegerProperty.create("age", 0, 5),
                DirectionProperty.create("facing", Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST, Direction.UP, Direction.DOWN),
                DirectionProperty.create("horizontal", Direction.Plane.HORIZONTAL), EnumProperty.create("face", AttachFace.class));
        Map<Map<Property<?>, Comparable<?>>, Holder> states = build(properties);
        for (Holder state : states.values()) StateMemory.populateNeighbours(states, state);
        check(states.size() == 2 * 6 * 6 * 4 * 3, "state count");
        check(states.values().iterator().next().values.getClass().getSimpleName().equals("FastPropertyMap"), "property maps were not replaced");
        for (Map.Entry<Map<Property<?>, Comparable<?>>, Holder> entry : states.entrySet()) {
            Map<Property<?>, Comparable<?>> expected = entry.getKey();
            Holder state = entry.getValue();
            ImmutableMap<Property<?>, Comparable<?>> values = state.values;
            check(values.equals(expected) && expected.equals(values) && values.hashCode() == expected.hashCode(), "values differ");
            check(new ArrayList<>(values.keySet()).equals(new ArrayList<>(expected.keySet())), "property order differs");
            check(new ArrayList<>(values.values()).equals(new ArrayList<>(expected.values())), "value order differs");
            for (Map.Entry<Property<?>, Comparable<?>> e : expected.entrySet()) check(values.entrySet().contains(e) && values.get(e.getKey()) == e.getValue(), "lookup");
            // Properties are equal by name and values, as in vanilla's map.
            check(values.get(BooleanProperty.create("lit")) == expected.get(BooleanProperty.create("lit")), "an equal property must match like vanilla");
            Table<Property<?>, Comparable<?>, Holder> table = state.neighbours;
            int neighbours = 0;
            for (Property<?> property : properties) for (Comparable<?> value : property.getPossibleValues()) {
                if (value.equals(expected.get(property))) continue;
                Map<Property<?>, Comparable<?>> changed = new LinkedHashMap<>(expected);
                changed.put(property, value);
                check(table.get(property, value) == states.get(changed), "neighbour " + property.getName() + "=" + value);
                check(table.contains(property, value), "contains");
                neighbours++;
            }
            check(table.size() == neighbours && table.cellSet().size() == neighbours, "neighbour count");
            check(table.get(properties.get(1), 6) == null && table.get(properties.get(1), "x") == null, "out-of-range value must give null");
        }
        Map<Map<Property<?>, Comparable<?>>, Holder> single = build(List.of());
        Holder only = single.values().iterator().next();
        StateMemory.populateNeighbours(single, only);
        check(only.neighbours.isEmpty() && only.map == null, "single state");

        check(MemoryGate.earned(List.of("enabled = true", "packedGlyphsEarned = true")), "1.5 config earns");
        check(!MemoryGate.earned(List.of("enabled = false", "packedGlyphsEarned = true")), "disabled Boost");
        check(!MemoryGate.earned(List.of("packedGlyphsEarned = true", "startupMemoryEarned = false")), "new key wins");
        check(MemoryGate.earned(List.of("#enabled = false", "startupMemoryEarned = true", "[entities]", "enabled = false")), "section keys ignored");
        check(!MemoryGate.earned(List.of()), "missing config");
        System.out.println("StateMemoryTest passed: " + states.size() + " states");
    }

    private static Map<Map<Property<?>, Comparable<?>>, Holder> build(List<Property<?>> properties) {
        List<Map<Property<?>, Comparable<?>>> combinations = new ArrayList<>();
        combinations.add(new LinkedHashMap<>());
        for (Property<?> property : properties) {
            List<Map<Property<?>, Comparable<?>>> next = new ArrayList<>();
            for (Map<Property<?>, Comparable<?>> partial : combinations) for (Comparable<?> value : property.getPossibleValues()) {
                Map<Property<?>, Comparable<?>> map = new LinkedHashMap<>(partial);
                map.put(property, value);
                next.add(map);
            }
            combinations = next;
        }
        Map<Map<Property<?>, Comparable<?>>, Holder> states = new LinkedHashMap<>();
        for (Map<Property<?>, Comparable<?>> combination : combinations) {
            ImmutableMap<Property<?>, Comparable<?>> values = ImmutableMap.copyOf(combination);
            states.put(values, new Holder(values));
        }
        return states;
    }

    private static void check(boolean condition, String message) { if (!condition) throw new AssertionError(message); }

    private static final class Holder implements FastMapStateHolder<Holder> {
        ImmutableMap<Property<?>, Comparable<?>> values;
        Table<Property<?>, Comparable<?>, Holder> neighbours;
        FastMap<Holder> map;
        int index;
        Holder(ImmutableMap<Property<?>, Comparable<?>> values) { this.values = values; }
        @Override public FastMap<Holder> pashaboost$stateMap() { return map; }
        @Override public void pashaboost$setStateMap(FastMap<Holder> map) { this.map = map; }
        @Override public int pashaboost$stateIndex() { return index; }
        @Override public void pashaboost$setStateIndex(int index) { this.index = index; }
        @Override public ImmutableMap<Property<?>, Comparable<?>> pashaboost$vanillaValues() { return values; }
        @Override public void pashaboost$replaceValues(ImmutableMap<Property<?>, Comparable<?>> values) { this.values = values; }
        @Override public Table<Property<?>, Comparable<?>, Holder> pashaboost$neighbours() { return neighbours; }
        @Override public void pashaboost$setNeighbours(Table<Property<?>, Comparable<?>, Holder> table) { neighbours = table; }
    }
}
