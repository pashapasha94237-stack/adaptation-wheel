package ru.pasha.pashaboost.core;

public final class ParticleBudgetTest {
    public static void run() {
        ParticleBudget budget = new ParticleBudget();
        budget.beginTick(8, 10, 4);
        check(budget.tryAcquire(25, 25), "Distance boundary must remain visible");
        check(budget.tryAcquire(0, 25), "Second available allocation");
        check(!budget.tryAcquire(0, 25), "Active count must include allocations earlier in the tick");
        budget.beginTick(0, 100, 2);
        check(budget.tryAcquire(0, 25), "Fresh tick allocation");
        budget.releaseReservation();
        check(budget.tryAcquire(0, 25), "Null provider must return allocation reservation");
        check(budget.tryAcquire(0, 25), "Second per-tick allocation");
        check(!budget.tryAcquire(0, 25), "Per-tick limit must reject bursts before construction");
        budget.beginTick(1, 3, 8);
        budget.observeUnfilteredAllocation();
        check(budget.tryAcquire(0, 25), "Important particles consume space but stay exempt");
        check(!budget.tryAcquire(0, 25), "Important allocations must reduce remaining decorative capacity");
        budget.beginTick(0, 100, 100);
        check(!budget.tryAcquire(26, 25), "Distant particle must be rejected");
        check(!budget.tryAcquire(Double.NaN, 25), "Invalid coordinates must not pass budget");
        check(!budget.tryAcquire(Double.POSITIVE_INFINITY, 25), "Infinite coordinates rejected");
        check(budget.rejectedCount() == 6, "Rejected count persists across tick snapshots");
        budget.clear();
        check(budget.rejectedCount() == 0 && budget.estimatedActive() == 0, "World cleanup clears counters");
        budget.beginTick(Integer.MAX_VALUE, Integer.MAX_VALUE, 5);
        budget.observeUnfilteredAllocation();
        check(budget.estimatedActive() == Integer.MAX_VALUE, "Counting must not overflow");
        check(!budget.tryAcquire(0, 25), "Overflow must not reopen budget");
    }

    public static void main(String[] args) { run(); System.out.println("ParticleBudgetTest passed"); }
    private static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
    private ParticleBudgetTest() {}
}
