package ru.pasha.pashaboost.core;

/** Policy tests for the Alex's Mobs pupfish rate limit, with AM's search simulated by a seed counter. */
public final class DeferredSearchTest {
    public static void main(String[] args) {
        offRunsEverything();
        freeTriesRunAtOwnRate();
        overBudgetDefersAndRepaysInOrder();
        repaymentIsBoundedPerTick();
        deadlineHoldsOnlyWhileOwed();
        System.out.println("DeferredSearchTest: 5 scenarios passed");
    }

    /** AM's state as the mixin sees it: pupfishSeedAddition, the seed that finds a chunk, the found flag. */
    private static final class Am {
        final DeferredSearch s = new DeferredSearch();
        final int target, allowance, freeTries;
        int columnsPerTry;
        final boolean optimise;
        int executed, columnsThisTick;
        boolean found;
        Am(int target, int columnsPerTry, int allowance, int freeTries, boolean optimise) {
            this.target = target; this.columnsPerTry = columnsPerTry; this.allowance = allowance; this.freeTries = freeTries; this.optimise = optimise;
        }
        /** searchForPupfishChunk with the HEAD admit injection; true = the try ran. */
        boolean tryOnce(int tick) {
            if (!s.admit(tick, allowance, optimise, executed, freeTries)) return false;
            for (int c = 0; c < columnsPerTry; c++) { s.spend(); columnsThisTick++; }
            if (++executed == target) { found = true; s.settle(); }
            return true;
        }
        /** The repay injection at the end of tickPupfish's guarded body. */
        int repay(int tick) {
            int paid = 0;
            while (!found && s.mayPay(tick, allowance, optimise)) {
                s.pay();
                try { check(tryOnce(tick), "A repayment always runs"); } finally { s.paid(); }
                paid++;
            }
            return paid;
        }
        /** One server tick with `calls` AM tries followed by the repay hook. */
        void tick(int tick, int calls) {
            columnsThisTick = 0;
            for (int i = 0; i < calls && !found; i++) tryOnce(tick);
            repay(tick);
        }
    }

    private static void offRunsEverything() {
        Am am = new Am(1_000, 4, 1, 0, false);
        for (int t = 0; t < 100; t++) am.tick(t, 5);
        check(am.executed == 500 && am.s.owed() == 0, "Without the optimisation every AM try runs at once");
    }

    private static void freeTriesRunAtOwnRate() {
        Am am = new Am(1_000_000, 4, 1, 50, true);
        for (int t = 0; t < 10; t++) am.tick(t, 5);
        check(am.executed == 50 && am.s.owed() == 0, "The first free tries are never deferred");
        am.tick(10, 5);
        check(am.executed == 51 && am.s.owed() == 4, "After the free burst one try per tick runs, the rest are owed");
    }

    private static void overBudgetDefersAndRepaysInOrder() {
        // AM tries in bursts of 8 every 10 ticks; each try costs one column, one column per tick is allowed.
        Am limited = new Am(40, 1, 1, 0, true);
        int t = 0;
        for (; !limited.found && t < 10_000; t++) {
            limited.tick(t, t % 10 == 0 ? 8 : 0);
            check(limited.columnsThisTick <= 1, "Uncached columns stay within the per-tick allowance");
        }
        check(limited.found && limited.executed == 40, "The same seed finds the chunk: deferral never skips a candidate");
        check(limited.s.owed() == 0, "A find settles the debt");
        Am unlimited = new Am(40, 1, 1, 0, false);
        int u = 0;
        for (; !unlimited.found; u++) unlimited.tick(u, u % 10 == 0 ? 8 : 0);
        check(t >= u, "Spreading the work can only delay the find, never hasten it");
        check(t <= u + 10, "Owed tries are repaid in the quiet ticks, so the find is not delayed past the next burst");
    }

    private static void repaymentIsBoundedPerTick() {
        Am am = new Am(1_000_000, 1, 1, 0, true);
        am.tick(0, 1_000);
        int owed = am.s.owed();
        check(owed > DeferredSearch.MAX_STEPS_PER_TICK, "Setup owes more than one tick of steps");
        // From here columns cost nothing (all memoised), so only the step cap limits repayment.
        am.columnsPerTry = 0;
        int paid = am.repay(1);
        check(paid == DeferredSearch.MAX_STEPS_PER_TICK, "No more than MAX_STEPS_PER_TICK repayments in one tick");
    }

    private static void deadlineHoldsOnlyWhileOwed() {
        DeferredSearch s = new DeferredSearch();
        check(!s.holdLimit(), "Nothing owed: AM's own five-minute give-up stands");
        check(s.admit(0, 1, true, 0, 0), "First try of the tick runs");
        s.spend();
        check(!s.admit(0, 1, true, 1, 0) && s.owed() == 1, "Second try is owed");
        check(s.holdLimit(), "Owed tries hold AM's clock");
        check(!s.admit(1, 1, true, 1, 0), "After the deadline no new tries start");
        check(s.mayPay(1, 1, false), "Owed tries still run after the deadline, even with the optimisation switched off");
        s.pay(); s.paid();
        check(s.owed() == 0 && !s.holdLimit(), "Once repaid, the give-up is AM's again");
        s.settle();
        check(s.admit(2, 1, true, 2, 0), "settle reopens the search");
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
