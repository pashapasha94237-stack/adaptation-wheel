package ru.pasha.pashaboost.core;

import org.joml.Vector3f;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.AnnotationNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import ru.pasha.pashaboost.client.CubeShape;
import ru.pasha.pashaboost.client.ModelDirectGate;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** The OptiFine cube fast path's pure parts against OptiFine I6's own arithmetic, transcribed from its bytecode. */
public final class CubeShapeTest {
    public static void main(String[] args) {
        colour();
        normals();
        vertexLayout();
        shapeIdentity();
        audit();
        versionMatch();
        System.out.println("CubeShapeTest: colour, normal transform and packing, vertex layout, shape identity, mixin audit and version match passed.");
    }

    /** Cube.compile 197-253: fload, ldc 255f, fmul, f2i per channel, then a<<24 | b<<16 | g<<8 | r with no masks. */
    private static void colour() {
        check(CubeShape.color(1F, 1F, 1F, 1F) == 0xFFFFFFFF, "white");
        check(CubeShape.color(1F, 0.5F, 0F, 1F) == 0xFF007FFF, "127.5 truncates");
        Random random = new Random(42);
        float[] edge = {0F, 1F, -0.1F, 1.5F, -1F, 2F, Float.NaN, 0.999F, 1E9F, -1E9F};
        for (int n = 0; n < 20000; n++) {
            float r = n < 1000 ? edge[n % edge.length] : random.nextFloat() * 3 - 1, g = n < 1000 ? edge[n / 10 % edge.length] : random.nextFloat() * 3 - 1,
                  b = n < 1000 ? edge[n / 100 % edge.length] : random.nextFloat() * 3 - 1, a = random.nextFloat() * 3 - 1;
            int ri = (int) (r * 255F), gi = (int) (g * 255F), bi = (int) (b * 255F), ai = (int) (a * 255F);
            int expected = ai << 24;
            expected |= bi << 16;
            expected |= gi << 8;
            expected |= ri;
            check(CubeShape.color(r, g, b, a) == expected, "colour " + r + " " + g + " " + b + " " + a);
        }
        // Out-of-range channels are not masked: a negative red sets every high bit, exactly as OptiFine's ior does.
        check(CubeShape.color(-0.1F, 0F, 0F, 0F) == (int) (-0.1F * 255F), "unmasked negative red");
    }

    /** MathUtils.getTransformX: m00*x, m10*y, fadd, m20*z, fadd; then normalIntValue bytes packed by compile 276-302. */
    private static void normals() {
        Random random = new Random(7);
        for (int n = 0; n < 100000; n++) {
            float m0 = random.nextFloat() * 4 - 2, m1 = random.nextFloat() * 4 - 2, m2 = random.nextFloat() * 4 - 2;
            float x = random.nextFloat() * 2 - 1, y = random.nextFloat() * 2 - 1, z = random.nextFloat() * 2 - 1;
            float first = m0 * x;
            float second = m1 * y;
            float sum = first + second;
            float third = m2 * z;
            float expected = sum + third;
            check(Float.floatToRawIntBits(CubeShape.transform(m0, m1, m2, x, y, z)) == Float.floatToRawIntBits(expected), "transform order");
        }
        check(CubeShape.packNormal(normalIntValue(0F), normalIntValue(1F), normalIntValue(0F)) == 0x007F00, "up");
        check(CubeShape.packNormal(normalIntValue(-1F), normalIntValue(0F), normalIntValue(2F)) == 0x7F0081, "clamped, signed bytes masked");
        for (int bits = 0; bits < 1 << 24; bits += 4099) {
            byte bx = (byte) bits, by = (byte) (bits >> 8), bz = (byte) (bits >> 16);
            int expected = (bz & 255) << 16 | (by & 255) << 8 | (bx & 255);
            check(CubeShape.packNormal(bx, by, bz) == expected, "pack " + bits);
        }
    }

    /** BufferVertexConsumer.m_85774_ (not patched by OptiFine): clamp to [-1, 1], times 127, f2i, & 255, i2b. */
    private static byte normalIntValue(float value) {
        float clamped = value < -1F ? -1F : Math.min(value, 1F);
        return (byte) ((int) (clamped * 127F) & 255);
    }

    /** OptiFine addVertexFast: floats at slots 0-2, colour 3, floats 4-5, overlay 6, light 7, normal 8, from nextElementByte / 4. */
    private static void vertexLayout() {
        ByteBuffer fast = ByteBuffer.allocateDirect(36 * 3).order(ByteOrder.nativeOrder());
        ByteBuffer reference = ByteBuffer.allocateDirect(36 * 3).order(ByteOrder.nativeOrder());
        int nextElementByte = 36;
        CubeShape.putVertex(fast.asFloatBuffer(), fast.asIntBuffer(), nextElementByte / 4, 1.5F, -2F, 0.25F, 0xFF00FF7F, 0.125F, 0.75F,
                0x000A0000, 0x00F000F0, 0x007F00);
        reference.putFloat(36, 1.5F).putFloat(40, -2F).putFloat(44, 0.25F).putInt(48, 0xFF00FF7F).putFloat(52, 0.125F).putFloat(56, 0.75F)
                .putInt(60, 0x000A0000).putInt(64, 0x00F000F0).putInt(68, 0x007F00);
        check(fast.equals(reference), "vertex bytes");
        check(fast.getInt(0) == 0 && fast.getInt(72) == 0, "nothing outside the vertex");
    }

    private static void shapeIdentity() {
        Object[] vertsA = {new Object(), new Object(), new Object(), new Object()};
        Object[] vertsB = {new Object(), new Object(), new Object(), new Object()};
        Vector3f normalA = new Vector3f(0, 1, 0), normalB = new Vector3f(1, 0, 0);
        Object polyA = new Object(), polyB = new Object();
        Object[] polygons = {polyA, null, polyB};
        CubeShape.PolygonReader reader = new CubeShape.PolygonReader() {
            @Override public Object[] vertices(Object polygon) {
                if (polygon == null) throw new AssertionError("empty slots are not read");
                return polygon == polyA ? vertsA : polygon == polyB ? vertsB : null;
            }
            @Override public Vector3f normal(Object polygon) { return polygon == polyA ? normalA : polygon == polyB ? normalB : null; }
        };
        CubeShape shape = CubeShape.of(polygons, reader);
        check(shape != CubeShape.FAILED && shape.matches(), "fresh shape matches");
        check(shape.vertices[0] == vertsA && shape.vertices[1] == null && shape.vertices[2] == vertsB, "vertex arrays by slot, empty slot null");
        check(shape.normals[0] == normalA && shape.normals[1] == null && shape.normals[2] == normalB, "normals by slot");
        polygons[1] = polyA;
        check(!shape.matches(), "an empty slot filled is seen");
        polygons[1] = null;
        check(shape.matches(), "and restored");
        polygons[2] = new Object();
        check(!shape.matches(), "a replaced polygon is seen");
        check(CubeShape.of(polygons, reader) == CubeShape.FAILED, "a polygon without fields fails the shape");
        check(!CubeShape.FAILED.matches(), "the failed shape never matches");
        check(CubeShape.of(null, reader) == CubeShape.FAILED, "no array");
        CubeShape.PolygonReader throwing = new CubeShape.PolygonReader() {
            @Override public Object[] vertices(Object polygon) throws ReflectiveOperationException { throw new NoSuchFieldException(); }
            @Override public Vector3f normal(Object polygon) { return normalA; }
        };
        check(CubeShape.of(new Object[]{polyA}, throwing) == CubeShape.FAILED, "reflection failure");
        check(CubeShape.of(new Object[0], reader).matches(), "a cube without polygons is fine");
    }

    private static void audit() {
        String add = "addVertexFast", addDesc = "(FFFIFFIII)V";
        check(ModelDirectGate.clean(target(method(add, addDesc, null))), "OptiFine's own method");
        check(!ModelDirectGate.clean(target(method("other", "()V", null)), add + addDesc), "missing method");
        check(!ModelDirectGate.clean(target(method(add, addDesc, "handler$zza000$othermod$hook")), add + addDesc), "foreign handler call");
        check(!ModelDirectGate.clean(target(method(add, addDesc, "wrapOperation$zzb000$othermod$wrap")), add + addDesc), "foreign MixinExtras call");
        check(ModelDirectGate.clean(target(method(add, addDesc, "handler$zza000$pashaboost$direct")), add + addDesc), "own handler call");
        MethodNode overwritten = method(add, addDesc, null);
        AnnotationNode merged = new AnnotationNode("Lorg/spongepowered/asm/mixin/transformer/meta/MixinMerged;");
        merged.values = new ArrayList<>(List.of("mixin", "com.example.mixin.BufferBuilderMixin", "priority", 1000));
        overwritten.visibleAnnotations = new ArrayList<>(List.of(merged));
        check(!ModelDirectGate.clean(target(overwritten), add + addDesc), "foreign overwrite");
        merged.values = new ArrayList<>(List.of("mixin", "ru.pasha.pashaboost.mixin.client.OfCubeWriterMixin", "priority", 1000));
        check(ModelDirectGate.clean(target(overwritten), add + addDesc), "own merge");
    }

    private static ClassNode target(MethodNode method) {
        ClassNode node = new ClassNode();
        node.name = "com/mojang/blaze3d/vertex/BufferBuilder";
        node.methods.add(method);
        return node;
    }

    private static MethodNode method(String name, String desc, String call) {
        MethodNode node = new MethodNode(Opcodes.ACC_PUBLIC, name, desc, null, null);
        node.instructions.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL, "java/nio/FloatBuffer", "put", "(IF)Ljava/nio/FloatBuffer;"));
        if (call != null) node.instructions.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL, "com/mojang/blaze3d/vertex/BufferBuilder", call, "()V"));
        node.instructions.add(new InsnNode(Opcodes.RETURN));
        return node;
    }

    private static void versionMatch() {
        byte[] constantPool = "\u0001\u0000\u00131.20.1_HD_U_I6_pre6\u0001".getBytes(StandardCharsets.ISO_8859_1);
        check(ModelDirectGate.containsAscii(constantPool, "1.20.1_HD_U_I6"), "I6 pre6");
        check(!ModelDirectGate.containsAscii("1.20.1_HD_U_I5".getBytes(StandardCharsets.US_ASCII), "1.20.1_HD_U_I6"), "I5");
        check(!ModelDirectGate.containsAscii("1.20.1_HD_U_I".getBytes(StandardCharsets.US_ASCII), "1.20.1_HD_U_I6"), "truncated");
        check(ModelDirectGate.containsAscii("x1.20.1_HD_U_I6".getBytes(StandardCharsets.US_ASCII), "1.20.1_HD_U_I6"), "at the end");
        // BoostMixinPlugin matches the exact build: a later I6 only switches the cube mixins off.
        check(ModelDirectGate.containsAscii(constantPool, "1.20.1_HD_U_I6_pre6"), "exact pre6");
        check(!ModelDirectGate.containsAscii("\u0001\u0000\u00131.20.1_HD_U_I6_pre7\u0001".getBytes(StandardCharsets.ISO_8859_1), "1.20.1_HD_U_I6_pre6"), "pre7");
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
