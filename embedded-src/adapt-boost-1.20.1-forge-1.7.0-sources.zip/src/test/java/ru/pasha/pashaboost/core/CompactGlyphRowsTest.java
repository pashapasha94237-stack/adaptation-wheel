package ru.pasha.pashaboost.core;

import net.minecraft.client.gui.font.providers.UnihexProvider;
import ru.pasha.pashaboost.client.font.CompactGlyphRows;

import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.Random;

/** Verifies glyph pixels and layout, independently of the implementation's packing. */
public final class CompactGlyphRowsTest {
    public static void main(String[] args) {
        exhaustSmallWidths();
        verifyWideRows();
        verifyNoArrayRetention();
        verifyBoundsAndLengths();
        System.out.println("CompactGlyphRowsTest: exhaustive 8/16-bit rows, 24/32-bit random/sign patterns, immutable primitive layout and bounds passed.");
    }

    private static void exhaustSmallWidths() {
        byte[] bytes = new byte[16];
        short[] shorts = new short[16];
        for (int value = 0; value < 256; value++) {
            Arrays.fill(bytes, (byte) value);
            verify(new CompactGlyphRows.Bytes(bytes), raw(bytes), 8);
        }
        for (int value = 0; value < 65536; value++) {
            Arrays.fill(shorts, (short) value);
            verify(new CompactGlyphRows.Shorts(shorts), raw(shorts), 16);
        }
        for (int row = 0; row < 16; row++) {
            bytes[row] = (byte) (0x80 ^ (row * 13));
            shorts[row] = (short) (0x8000 ^ (row * 3917));
        }
        verify(new CompactGlyphRows.Bytes(bytes), raw(bytes), 8);
        verify(new CompactGlyphRows.Shorts(shorts), raw(shorts), 16);
    }

    private static void verifyWideRows() {
        int[] rows = {0, -1, Integer.MIN_VALUE, Integer.MAX_VALUE, 0x80000001, 0x55555555,
                0xaaaaaaaa, 0x01020304, 0xff000000, 0x00ffffff, 0xffff0000, 0x0000ffff,
                1, 0x01000000, 0x7f800080, 0xdeadbeef};
        verify(new CompactGlyphRows.Ints(rows, 32), rows.clone(), 32);
        Random random = new Random(0x5041534841L);
        for (int iteration = 0; iteration < 5000; iteration++) {
            for (int row = 0; row < 16; row++) rows[row] = random.nextInt();
            verify(new CompactGlyphRows.Ints(rows, 32), rows.clone(), 32);
            for (int row = 0; row < 16; row++) rows[row] &= 0xffffff00;
            verify(new CompactGlyphRows.Ints(rows, 24), rows.clone(), 24);
        }
    }

    private static int[] raw(byte[] rows) {
        int[] result = new int[16];
        for (int row = 0; row < 16; row++) result[row] = rows[row] << 24;
        return result;
    }

    private static int[] raw(short[] rows) {
        int[] result = new int[16];
        for (int row = 0; row < 16; row++) result[row] = rows[row] << 16;
        return result;
    }

    private static void verify(UnihexProvider.LineData compact, int[] expected, int width) {
        check(compact.bitWidth() == width, "Width changed");
        int expectedMask = 0;
        for (int row = 0; row < 16; row++) {
            check(compact.line(row) == expected[row], "Glyph pixels changed at row " + row);
            expectedMask |= expected[row];
        }
        check(compact.mask() == expectedMask, "Combined glyph mask changed");
        UnihexProvider.LineData baseline = new UnihexProvider.LineData() {
            @Override public int line(int row) { return expected[row]; }
            @Override public int bitWidth() { return width; }
        };
        check(compact.calculateWidth() == baseline.calculateWidth(), "Calculated glyph width changed");
    }

    private static void verifyNoArrayRetention() {
        for (Class<?> type : new Class<?>[]{CompactGlyphRows.Bytes.class, CompactGlyphRows.Shorts.class,
                CompactGlyphRows.Ints.class}) {
            for (var field : type.getDeclaredFields()) {
                if (Modifier.isStatic(field.getModifiers())) continue;
                check(field.getType().isPrimitive(), "Retained a non-primitive field: " + field);
                check(Modifier.isFinal(field.getModifiers()), "Mutable packed glyph field: " + field);
            }
        }
        byte[] bytes = new byte[16]; Arrays.fill(bytes, (byte) 0x81);
        short[] shorts = new short[16]; Arrays.fill(shorts, (short) 0x8001);
        int[] ints = new int[16]; Arrays.fill(ints, 0x80000001);
        var packedBytes = new CompactGlyphRows.Bytes(bytes);
        var packedShorts = new CompactGlyphRows.Shorts(shorts);
        var packedInts = new CompactGlyphRows.Ints(ints, 32);
        Arrays.fill(bytes, (byte) 0); Arrays.fill(shorts, (short) 0); Arrays.fill(ints, 0);
        for (int row = 0; row < 16; row++) {
            check(packedBytes.line(row) == 0x81000000, "Input byte array is retained");
            check(packedShorts.line(row) == 0x80010000, "Input short array is retained");
            check(packedInts.line(row) == 0x80000001, "Input int array is retained");
        }
    }

    private static void verifyBoundsAndLengths() {
        for (UnihexProvider.LineData data : new UnihexProvider.LineData[]{
                new CompactGlyphRows.Bytes(new byte[16]), new CompactGlyphRows.Shorts(new short[16]),
                new CompactGlyphRows.Ints(new int[16], 24), new CompactGlyphRows.Ints(new int[16], 32)}) {
            for (int invalid : new int[]{-1, 16, Integer.MIN_VALUE, Integer.MAX_VALUE})
                expect(ArrayIndexOutOfBoundsException.class, () -> data.line(invalid));
        }
        for (int invalidLength : new int[]{0, 15, 17}) {
            expect(IllegalArgumentException.class, () -> new CompactGlyphRows.Bytes(new byte[invalidLength]));
            expect(IllegalArgumentException.class, () -> new CompactGlyphRows.Shorts(new short[invalidLength]));
            expect(IllegalArgumentException.class, () -> new CompactGlyphRows.Ints(new int[invalidLength], 32));
        }
        expect(NullPointerException.class, () -> new CompactGlyphRows.Bytes(null));
        expect(NullPointerException.class, () -> new CompactGlyphRows.Shorts(null));
        expect(NullPointerException.class, () -> new CompactGlyphRows.Ints(null, 32));
        expect(IllegalArgumentException.class, () -> new CompactGlyphRows.Ints(new int[16], 8));
        expect(IllegalArgumentException.class, () -> CompactGlyphRows.estimatedSavedBytes(0));
        check(CompactGlyphRows.estimatedSavedBytes(8) == 16, "Byte estimate changed");
        check(CompactGlyphRows.estimatedSavedBytes(16) == 16, "Short estimate changed");
        check(CompactGlyphRows.estimatedSavedBytes(24) == 24, "24-bit estimate changed");
        check(CompactGlyphRows.estimatedSavedBytes(32) == 24, "32-bit estimate changed");
    }

    private static void expect(Class<? extends Throwable> expected, Runnable action) {
        try { action.run(); }
        catch (Throwable actual) {
            if (expected.isInstance(actual)) return;
            throw new AssertionError("Expected " + expected.getName(), actual);
        }
        throw new AssertionError("Expected " + expected.getName());
    }

    private static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
