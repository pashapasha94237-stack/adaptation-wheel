package ru.pasha.pashaboost.core;

import java.lang.reflect.Field;

public final class LightChunkCacheTest {
    public static void main(String[] args) {
        LightChunkCache<Object> cache = new LightChunkCache<>();
        Object a = new Object(), b = new Object();
        check(!cache.contains(0, 0), "Fresh cache must not claim coordinate zero");
        cache.put(-1, Integer.MIN_VALUE, a);
        check(cache.contains(-1, Integer.MIN_VALUE) && cache.get(-1, Integer.MIN_VALUE) == a,
                "Full signed coordinate range must roundtrip");
        check(!cache.contains(Integer.MAX_VALUE, Integer.MIN_VALUE), "High x bits must distinguish colliding slots");
        cache.put(-1, Integer.MIN_VALUE + 4, b);
        check(cache.getIfPresent(-1,Integer.MIN_VALUE)==a && cache.getIfPresent(-1,Integer.MIN_VALUE+4)==b,
                "Stride-four coordinates must coexist instead of replacing one another");
        cache.put(2, -3, null);
        check(!cache.contains(2, -3), "An unavailable chunk must be queried again while its future can complete");
        cache.put(2, -3, a);
        check(cache.contains(2, -3) && cache.get(2, -3) == a,
                "A chunk becoming available within the same batch must be visible");
        for (int x = -32; x < 32; x++) for (int z = -32; z < 32; z++) cache.put(x, z, a);
        check(cache.size() == LightChunkCache.CAPACITY, "Cache must remain bounded to sixteen slots");
        cache.clear();
        check(cache.size() == 0 && !cache.contains(31, 31), "Batch clear must invalidate every coordinate");
        checkNoReferences(cache);
        compareLightingNeighborhoods();
        compareStrideCollisions();
        System.out.println("LightChunkCacheTest passed");
    }

    private static void compareStrideCollisions(){
        LightChunkCache<Object> cache=new LightChunkCache<>();Object[] chunks={new Object(),new Object(),new Object(),new Object()};
        for(int i=0;i<4;i++)cache.put(i*4,0,chunks[i]);
        for(int pass=0;pass<100;pass++)for(int i=0;i<4;i++)
            check(cache.getIfPresent(i*4,0)==chunks[i],"Four colliding coordinates must retain exact chunk identities");
        check(cache.hits()==400&&cache.misses()==0,"A collision-heavy batch must hit after its initial four loads");
        cache.put(16,0,new Object());check(cache.size()==4,"A fifth colliding chunk evicts within the bounded set");
        cache.put(4,0,null);check(cache.getIfPresent(4,0)==chunks[1],"A null result must not erase an existing chunk");
        cache.clear();checkNoReferences(cache);
    }

    private static void compareLightingNeighborhoods() {
        HotCache vanilla = new HotCache(false), optimized = new HotCache(true);
        for (int batch = 0; batch < 12; batch++) {
            vanilla.clear(); optimized.clear();
            int centerX = batch - 8, centerZ = -batch;
            for (int pass = 0; pass < 40; pass++) {
                for (int x = centerX - 1; x <= centerX + 1; x++) {
                    for (int z = centerZ - 1; z <= centerZ + 1; z++) {
                        long expected = vanilla.get(x, z), actual = optimized.get(x, z);
                        check(expected == actual, "Cached lighting source must return identical chunk identity");
                    }
                }
            }
            check(optimized.extra.size() == 9, "A rolling three-by-three neighborhood has no slot collisions");
        }
        check(optimized.sourceLookups == 12 * 9, "Only nine source lookups are needed per lighting batch");
        check(vanilla.sourceLookups == 12 * 9 * 40, "Two-entry vanilla FIFO thrashes on the test neighborhood");
        check(optimized.sourceLookups * 20 < vanilla.sourceLookups, "Cache must reduce actual simulated source calls");
    }

    /** Reproduces the verified vanilla two-entry FIFO before consulting the new cache. */
    private static final class HotCache {
        private final long[] hotKeys = new long[2];
        private final long[] hotValues = new long[2];
        private int hotCount;
        private final LightChunkCache<Long> extra = new LightChunkCache<>();
        private final boolean enabled;
        private int sourceLookups;
        private HotCache(boolean enabled) { this.enabled = enabled; }
        private long get(int x, int z) {
            long key = (x & 0xffffffffL) | ((z & 0xffffffffL) << 32);
            for (int i = 0; i < hotCount; i++) if (hotKeys[i] == key) return hotValues[i];
            long value;
            if (enabled && extra.contains(x, z)) value = extra.get(x, z);
            else {
                sourceLookups++;
                value = key;
                if (enabled) extra.put(x, z, value);
            }
            hotKeys[1] = hotKeys[0]; hotValues[1] = hotValues[0];
            hotKeys[0] = key; hotValues[0] = value; hotCount = Math.min(2, hotCount + 1);
            return value;
        }
        private void clear() { hotCount = 0; extra.clear(); }
    }

    private static void checkNoReferences(LightChunkCache<?> cache) {
        try {
            Field field = LightChunkCache.class.getDeclaredField("values");
            field.setAccessible(true);
            for (Object value : (Object[]) field.get(cache)) check(value == null, "Clear must release every retained reference");
        } catch (ReflectiveOperationException error) {
            throw new AssertionError(error);
        }
    }
    private static void check(boolean condition, String message) { if (!condition) throw new AssertionError(message); }
    private LightChunkCacheTest() {}
}
