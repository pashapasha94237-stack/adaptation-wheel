package ru.pasha.pashaboost.core;

/** Self-contained tests; run with Java 17 without an external testing dependency. */
public final class FrameStatsTest {
    private FrameStatsTest() {
    }

    public static void main(String[] args) {
        constantFps(60, 16_666_667L);
        constantFps(120, 8_333_333L);
        slowFramesDetermineOnePercentLow();
        onePercentRoundsUp();
        ringEvictsOldFrames();
        invalidFramesAreIgnored();
        clearResetsHistory();
        capacityIsBounded();
        System.out.println("FrameStats tests passed");
    }

    private static void constantFps(double target, long nanos) {
        FrameStats stats = new FrameStats();
        for (int frame = 0; frame < 1000; frame++) {
            stats.addNanos(nanos);
        }
        FrameStats.Snapshot result = stats.snapshot();
        close(target, result.averageFps(), 0.001, "average FPS at " + target);
        close(target, result.onePercentLowFps(), 0.001, "1% low FPS at " + target);
        close(nanos / 1_000_000.0, result.p95Millis(), 0.000001, "p95 constant duration");
        close(nanos / 1_000_000.0, result.maxMillis(), 0.000001, "maximum constant duration");
        close(nanos * 1000.0 / 1_000_000_000.0, result.seconds(), 0.000001, "sample seconds");
        check(result.frames() == 1000 && stats.size() == 1000, "constant sample count");
    }

    private static void slowFramesDetermineOnePercentLow() {
        FrameStats stats = new FrameStats();
        for (int frame = 0; frame < 990; frame++) {
            stats.addNanos(10_000_000L);
        }
        for (int frame = 0; frame < 10; frame++) {
            stats.addNanos(100_000_000L);
        }
        FrameStats.Snapshot result = stats.snapshot();
        close(1000.0 / 10.9, result.averageFps(), 0.000001, "average includes slow frames");
        close(10, result.onePercentLowFps(), 0.000001, "slowest 1% average");
        close(10, result.p95Millis(), 0.000001, "nearest-rank p95");
        close(100, result.maxMillis(), 0.000001, "slowest duration");
    }

    private static void onePercentRoundsUp() {
        FrameStats stats = new FrameStats();
        for (int frame = 0; frame < 99; frame++) {
            stats.addNanos(10_000_000L);
        }
        stats.addNanos(20_000_000L);
        stats.addNanos(100_000_000L);
        close(1_000_000_000.0 / 60_000_000.0, stats.snapshot().onePercentLowFps(),
                0.000001, "101 frames include two slowest frames");
    }

    private static void ringEvictsOldFrames() {
        FrameStats stats = new FrameStats(4);
        stats.addNanos(100_000_000L);
        for (int frame = 0; frame < 8; frame++) {
            stats.addNanos(10_000_000L);
        }
        FrameStats.Snapshot result = stats.snapshot();
        check(stats.size() == 4 && result.frames() == 4, "bounded frame count");
        close(100, result.averageFps(), 0.000001, "old frames evicted after wrapping");
        close(100, result.onePercentLowFps(), 0.000001, "evicted slow frame excluded");
        close(0.04, result.seconds(), 0.000001, "seconds include retained frames only");
    }

    private static void invalidFramesAreIgnored() {
        FrameStats stats = new FrameStats(4);
        stats.addNanos(0);
        stats.addNanos(-1);
        stats.addNanos(Long.MIN_VALUE);
        check(stats.size() == 0, "invalid values ignored");
        check(stats.snapshot().equals(new FrameStats.Snapshot(0, 0, 0, 0, 0, 0)), "empty snapshot");
        stats.addNanos(1_000_000_000L);
        close(1, stats.snapshot().averageFps(), 0, "exactly one second is accepted");
        stats.addNanos(3_000_000_000L);
        close(0.5,stats.snapshot().averageFps(),0,"long freezes must not disappear from measured FPS");
        close(1.0/3,stats.snapshot().onePercentLowFps(),0,"long freezes count in 1% low");
    }

    private static void clearResetsHistory() {
        FrameStats stats = new FrameStats(4);
        for (int frame = 0; frame < 7; frame++) {
            stats.addNanos(100_000_000L);
        }
        FrameStats.Snapshot beforeClear = stats.snapshot();
        stats.clear();
        check(stats.size() == 0 && stats.snapshot().frames() == 0, "clear empties history");
        stats.addNanos(10_000_000L);
        close(100, stats.snapshot().averageFps(), 0.000001, "clear resets ring write position");
        close(10, beforeClear.averageFps(), 0.000001, "snapshots remain immutable");
    }

    private static void capacityIsBounded() {
        expectInvalidCapacity(0);
        expectInvalidCapacity(-1);
        expectInvalidCapacity(FrameStats.MAX_CAPACITY + 1);
        FrameStats stats = new FrameStats(FrameStats.MAX_CAPACITY);
        for (int frame = 0; frame < FrameStats.MAX_CAPACITY + 3; frame++) {
            stats.addNanos(1_000_000_000L);
        }
        check(stats.size() == FrameStats.MAX_CAPACITY, "maximum ring capacity");
        close(FrameStats.MAX_CAPACITY, stats.snapshot().seconds(), 0, "long duration sum is safe");
    }

    private static void expectInvalidCapacity(int capacity) {
        try {
            new FrameStats(capacity);
            throw new AssertionError("Accepted invalid capacity: " + capacity);
        } catch (IllegalArgumentException expected) {
            // Expected validation failure.
        }
    }

    private static void close(double expected, double actual, double tolerance, String description) {
        check(Double.isFinite(actual) && Math.abs(expected - actual) <= tolerance,
                description + ": expected " + expected + ", got " + actual);
    }

    private static void check(boolean condition, String description) {
        if (!condition) {
            throw new AssertionError(description);
        }
    }
}
