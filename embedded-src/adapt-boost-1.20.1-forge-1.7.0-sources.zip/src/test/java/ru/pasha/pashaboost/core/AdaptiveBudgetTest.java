package ru.pasha.pashaboost.core;

public final class AdaptiveBudgetTest {
    public static void main(String[] args) {
        AdaptiveBudget b=new AdaptiveBudget();
        assert b.update(30,.5,120)==1 : "one spike must not lower quality";
        assert Math.abs(b.update(30,.5,120)-.9)<.00001;
        for(int i=0;i<100;i++) b.update(30,.5,120);
        assert Math.abs(b.scale()-.5)<.00001;
        for(int i=0;i<4;i++) b.update(3,.4,120);
        assert Math.abs(b.scale()-.5)<.00001 : "slow recovery";
        b.update(3,.4,120);
        assert Math.abs(b.scale()-.55)<.00001;
        b.reset();
        b.update(3,.9,120); b.update(3,.9,120);
        assert Math.abs(b.scale()-.9)<.00001 : "heap pressure must lower decorative load";
        assert b.update(Double.NaN,.9,120)==b.scale();
        assert AdaptiveBudget.distance(48,24,1.0)==48 : "full quality keeps the configured mob distance";
        assert AdaptiveBudget.distance(48,24,.75)==36;
        assert AdaptiveBudget.distance(48,24,.5)==24 : "the lowest scale halves the distance";
        assert AdaptiveBudget.distance(48,40,.5)==40 : "never closer than the protected radius";
        assert AdaptiveBudget.distance(32,40,.5)==32 : "a configured distance below the radius is kept";
        assert AdaptiveBudget.distance(48,24,Double.NaN)==48;
        System.out.println("AdaptiveBudget: 13 checks passed");
    }
}
