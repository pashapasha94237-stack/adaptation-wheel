package ru.pasha.pashaboost.core;

import java.util.HashSet;
import java.util.Set;

import static ru.pasha.pashaboost.core.ParticleLightShare.*;

public final class ParticleLightShareTest {
    public static void main(String[] args) {
        keys();
        table();
        passes();
        triState();
        hookBits();
        System.out.println("ParticleLightShareTest passed");
    }

    // BlockPos.asLong with 1.20.1's widths (x, z 26 bits; y 12 bits), written out so the test needs no Minecraft classes.
    private static long asLong(int x, int y, int z) {
        long l = 0L;
        l |= ((long) x & (1L << 26) - 1L) << 38;
        l |= (long) y & (1L << 12) - 1L;
        l |= ((long) z & (1L << 26) - 1L) << 12;
        return l;
    }

    private static void keys() {
        int[] xs = {0, 1, -1, 12345, -12345, 29_999_999, -30_000_000, (1 << 25) - 1, -(1 << 25)};
        int[] ys = {0, 1, -1, -64, 319, 2047, -2048, 1000, -1000};
        Set<Long> seen = new HashSet<>();
        for (int x : xs) for (int y : ys) for (int z : xs) {
            check(inRange(x, y, z), "World coordinates must be in range: " + x + "," + y + "," + z);
            long key = pack(x, y, z);
            check(key == asLong(x, y, z), "Key must equal BlockPos.asLong for " + x + "," + y + "," + z);
            check(seen.add(key), "Keys must be unique inside the range");
        }
        // y wraps every 4096 in BlockPos.asLong: these are the collisions the range check keeps out of the table.
        check(pack(5, 2048 + 3, 7) == pack(5, -2048 + 3, 7), "The 12-bit y field wraps at 4096");
        check(!inRange(0, 2048, 0) && !inRange(0, -2049, 0) && inRange(0, 2047, 0) && inRange(0, -2048, 0),
                "Only -2048..2047 is a valid y");
        check(!inRange(1 << 25, 0, 0) && !inRange(0, 0, -(1 << 25) - 1) && !inRange(Integer.MIN_VALUE, 0, 0),
                "x and z outside 26 bits are out of range");
        check(pack(-1, -1, -1) != pack(1, 1, 1) && pack(-1, 0, 0) != pack(0, 0, -1), "Negative coordinates must not alias");
    }

    private static void table() {
        Table table = new Table();
        long a = pack(-3, -64, 9), b = pack(-3, -63, 9);
        check(table.find(a, 1) < 0, "A fresh table holds nothing, not even key 0");
        check(table.find(pack(0, 0, 0), 0) < 0, "Zero key and zero revision must not match an empty slot");
        table.put(a, 7, 3, AIR, 0xF000F0);
        int slot = table.find(a, 7);
        check(slot >= 0 && table.value(slot) == 0xF000F0 && table.kind(slot) == AIR && table.pass(slot) == 3, "Stored entry must round-trip");
        check(table.find(a, 8) < 0, "A new revision invalidates every entry");
        check(table.find(b, 7) < 0, "A neighbouring block is a different key");
        table.put(a, 8, 0, OTHER, -1);
        slot = table.find(a, 8);
        check(slot >= 0 && table.value(slot) == -1 && table.kind(slot) == OTHER, "Any int value, including -1, must round-trip");
        check(table.find(a, 7) < 0, "Rewriting a key replaces the older revision");
        // Collisions replace, they never answer for another key.
        Table full = new Table();
        int stored = 0;
        for (int x = -40; x < 40; x++) for (int z = -40; z < 40; z++) { full.put(pack(x, 70, z), 1, 1, AIR, x * 31 + z); stored++; }
        int hits = 0;
        for (int x = -40; x < 40; x++) for (int z = -40; z < 40; z++) {
            int s = full.find(pack(x, 70, z), 1);
            if (s >= 0) { hits++; check(full.value(s) == x * 31 + z, "A hit must return that key's value"); }
        }
        check(hits > 0 && hits <= stored && hits <= Table.SLOTS, "Direct-mapped table keeps at most one entry per slot");
    }

    private static void passes() {
        check(nextPass(0) == 1 && nextPass(41) == 42, "Passes count up from 1");
        check(nextPass(-1) == 1, "A wrap skips 0, which means outside any pass");
        check(nextPass(Integer.MAX_VALUE) == Integer.MIN_VALUE, "Negative pass numbers are valid passes");
        endPass();
        check(currentPass == 0, "endPass leaves no pass open");
        beginPass();
        int first = currentPass;
        check(first != 0, "beginPass opens a non-zero pass");
        endPass();
        beginPass();
        check(currentPass != first && currentPass != 0, "Each pass gets a new number");
        endPass();
        // Reuse rule: same non-zero pass for any kind; across passes only air, and only if the cross-frame check holds.
        check(reuse(OTHER, 5, 5) == REUSE_YES && reuse(AIR, 5, 5) == REUSE_YES && reuse(UNLOADED, 5, 5) == REUSE_YES,
                "Same pass reuses every kind without the cross-frame check");
        check(reuse(AIR, -7, -7) == REUSE_YES, "A wrapped negative pass is a real pass");
        check(reuse(OTHER, 5, 6) == REUSE_NO && reuse(UNLOADED, 5, 6) == REUSE_NO, "Non-air never crosses passes");
        check(reuse(OTHER, 0, 0) == REUSE_NO && reuse(UNLOADED, 0, 0) == REUSE_NO, "Outside a pass non-air is never reused, even from pass 0");
        check(reuse(AIR, 5, 6) == REUSE_IF_CROSS_AIR && reuse(AIR, 0, 0) == REUSE_IF_CROSS_AIR && reuse(AIR, 5, 0) == REUSE_IF_CROSS_AIR
                && reuse(AIR, 0, 6) == REUSE_IF_CROSS_AIR, "Air from another pass or outside any pass needs the cross-frame check");
        // Store rule, used by both tables: air always, other known kinds only inside a pass, NONE never.
        check(storable(AIR, 0) && storable(AIR, 3), "Air is stored in and outside a pass");
        check(storable(OTHER, 3) && storable(UNLOADED, 3) && storable(OTHER, -3), "Other kinds are stored inside a pass");
        check(!storable(OTHER, 0) && !storable(UNLOADED, 0), "Outside a pass non-air is not stored");
        check(!storable(NONE, 0) && !storable(NONE, 3), "NONE is never stored");
        // Classification: air computed with OptiFine dynamic lights on carries their light and must stay in its pass.
        check(lightKind(true, false) == AIR, "Air without dynamic lights is AIR");
        check(lightKind(true, true) == OTHER, "Air with dynamic lights on is OTHER");
        check(lightKind(false, false) == OTHER && lightKind(false, true) == OTHER, "Non-air is OTHER");
        check(!storable(lightKind(true, true), 0) && reuse(lightKind(true, true), 4, 5) == REUSE_NO,
                "A dynamic-lit air value is neither stored outside a pass nor reused across passes");
        // FULL takes its kind from the redirect, so a dynamic-lit air miss stays pass-scoped there too.
        check(fullKind(lightKind(true, true), 240) == OTHER && !storable(fullKind(lightKind(true, true), 240), 0),
                "The call-site table follows the redirect's demotion");
        check(!storable(fullKind(UNKNOWN, 240), 3) && storable(fullKind(UNKNOWN, 0), 3) && !storable(fullKind(UNKNOWN, 0), 0)
                && !storable(fullKind(UNCACHEABLE, 0), 3), "Call-site store decisions per tri-state");
        long before = revision();
        bump();
        check(revision() == before + 1, "bump starts a new revision");
    }

    private static void triState() {
        check(fullKind(UNKNOWN, 0) == UNLOADED, "No redirect and 0: hasChunkAt was false");
        check(fullKind(UNKNOWN, 15728880) == NONE && fullKind(UNKNOWN, -1) == NONE, "No redirect and a light value: do not store");
        check(fullKind(AIR, 0) == AIR && fullKind(AIR, 240) == AIR, "Air reported by the redirect");
        check(fullKind(OTHER, 240) == OTHER, "Other block reported by the redirect");
        check(fullKind(UNCACHEABLE, 0) == NONE && fullKind(UNCACHEABLE, 240) == NONE, "A bypassed redirect stores nothing");
    }

    private static void hookBits() {
        check(hookBit("handler$zza000$pashaboost$lightSwap") == HOOK_LIGHT_SWAP, "Renamed inject handlers are recognised");
        check(hookBit("redirect$zzb000$pashaboost$sharedLightSrg") == HOOK_LOOKUP, "Renamed redirect handlers are recognised");
        check(hookBit("pashaboost$lightPassStart") == HOOK_PASS_START, "Unrenamed handlers are recognised");
        check(hookBit("pashaboost$bumpOnClient") == 0 && hookBit("m_6978_") == 0 && hookBit("handler$x$other$lightSwap") == 0,
                "Other calls carry no hook bit");
        String[] invalidation = {"lightBlockSet", "lightChunkPacket", "lightChunkDrop", "lightChunkReplace", "lightViewCenter",
                "lightViewRadius", "lightSwap", "lightAllChanged", "lightLevelChanged"};
        int bits = 0;
        for (String name : invalidation) {
            check(!invalidationLive(bits), "Invalidation is not live while a hook is missing");
            bits |= hookBit("handler$a$pashaboost$" + name);
        }
        check(invalidationLive(bits) && !passLive(bits), "All nine bumps make invalidation live, passes are separate");
        bits |= hookBit("pashaboost$lightPassStart") | hookBit("pashaboost$lightPassEnd");
        check(!passLive(bits), "A pass without the frame-start reset is not live");
        bits |= hookBit("pashaboost$lightFrameStart");
        check(passLive(bits), "Start, end and frame reset make passes live");
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    private ParticleLightShareTest() {}
}
