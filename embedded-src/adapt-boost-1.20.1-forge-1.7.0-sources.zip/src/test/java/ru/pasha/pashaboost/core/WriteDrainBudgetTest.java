package ru.pasha.pashaboost.core;

/** Pure Java 17 policy tests. Real IOWorker persistence is verified separately by integration tests. */
public final class WriteDrainBudgetTest {
    public static void main(String[] args) {
        run();
        System.out.println("WriteDrainBudgetTest: 7 scenarios passed");
    }

    public static void run() {
        thresholdIsStrict();
        burstCountIsBounded();
        elapsedTimeIsBounded();
        backlogDropStopsBurst();
        newBurstResetsAllowance();
        invalidTuningCannotCreateWork();
        nanoTimeWrapRemainsValid();
    }

    private static void thresholdIsStrict() {
        WriteDrainBudget budget = new WriteDrainBudget();
        budget.begin(512, 4, 2_000_000, 100);
        check(!budget.tryAcquire(511, 101), "Below threshold stays vanilla");
        check(!budget.tryAcquire(512, 101), "Equal to threshold stays vanilla");
        check(budget.tryAcquire(513, 101), "Above threshold grants extra write");
        check(budget.acquired() == 1, "Rejected attempts do not consume allowance");
    }

    private static void burstCountIsBounded() {
        WriteDrainBudget budget = new WriteDrainBudget();
        budget.begin(512, Integer.MAX_VALUE, Long.MAX_VALUE, 100);
        for (int write = 0; write < 4; write++) {
            check(budget.tryAcquire(10_000, 101 + write), "Four extra writes allowed");
        }
        for (int attempt = 0; attempt < 100; attempt++) {
            check(!budget.tryAcquire(10_000, 105 + attempt), "No fifth extra write");
        }
        check(budget.acquired() == 4, "Counter remains bounded");
        budget.begin(512, 2, 2_000_000, 100);
        check(budget.tryAcquire(900, 101) && budget.tryAcquire(900, 102), "Lower configured burst honored");
        check(!budget.tryAcquire(900, 103), "Configured two-write limit honored");
    }

    private static void elapsedTimeIsBounded() {
        WriteDrainBudget budget = new WriteDrainBudget();
        budget.begin(512, 4, Long.MAX_VALUE, 1_000_000);
        check(budget.tryAcquire(900, 1_000_000), "An operation may start immediately");
        check(budget.tryAcquire(900, 2_999_999), "An operation may start before two milliseconds");
        check(!budget.tryAcquire(900, 3_000_000), "No operation starts at the hard time limit");
        check(!budget.tryAcquire(900, 30_000_000), "A slow completed write never grants catch-up work");
        budget.begin(512, 4, 100, 1_000);
        check(budget.tryAcquire(900, 1_099), "Shorter configured budget honored");
        check(!budget.tryAcquire(900, 1_100), "Shorter budget stops exactly at its boundary");
    }

    private static void backlogDropStopsBurst() {
        WriteDrainBudget budget = new WriteDrainBudget();
        budget.begin(512, 4, 2_000_000, 0);
        check(budget.tryAcquire(514, 1), "First write can reduce pressure");
        check(budget.tryAcquire(513, 2), "Second write can reach threshold");
        check(!budget.tryAcquire(512, 3), "Remaining queue is left for vanilla scheduling");
        check(budget.acquired() == 2, "Does not blindly use full configured burst");
    }

    private static void newBurstResetsAllowance() {
        WriteDrainBudget budget = new WriteDrainBudget();
        budget.begin(512, 1, 50, 100);
        check(budget.tryAcquire(900, 101), "First burst grants one write");
        check(!budget.tryAcquire(900, 102), "First burst exhausted");
        budget.begin(800, 2, 100, 1_000);
        check(budget.acquired() == 0, "New burst resets count");
        check(!budget.tryAcquire(800, 1_001), "New threshold replaces old threshold");
        check(budget.tryAcquire(801, 1_001), "New burst starts its own clock");
        check(budget.tryAcquire(801, 1_002), "New burst captures its own count limit");
        check(!budget.tryAcquire(801, 1_003), "New limit still bounded");
    }

    private static void invalidTuningCannotCreateWork() {
        WriteDrainBudget budget = new WriteDrainBudget();
        check(!budget.tryAcquire(900, 0), "Uninitialized budget grants no work");
        for (int limit : new int[]{0, -1, Integer.MIN_VALUE}) {
            budget.begin(512, limit, 2_000_000, 100);
            check(!budget.tryAcquire(900, 101), "Nonpositive burst disables extra work");
        }
        for (long nanos : new long[]{0, -1, Long.MIN_VALUE}) {
            budget.begin(512, 4, nanos, 100);
            check(!budget.tryAcquire(900, 101), "Nonpositive time budget disables extra work");
        }
        budget.begin(-1, 4, 2_000_000, 100);
        check(!budget.tryAcquire(0, 101), "Negative threshold cannot drain an empty queue");
        check(!budget.tryAcquire(900, 99), "Backwards clock grants no write");
    }

    private static void nanoTimeWrapRemainsValid() {
        WriteDrainBudget budget = new WriteDrainBudget();
        budget.begin(512, 4, 100, Long.MAX_VALUE - 10);
        check(budget.tryAcquire(900, Long.MIN_VALUE + 10), "nanoTime wrap preserves small positive elapsed time");
        check(!budget.tryAcquire(900, Long.MIN_VALUE + 100), "Wrapped elapsed time still respects deadline");
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
