package ru.pasha.pashaboost.core;

public final class AllTests {
    public static void main(String[] args) {
        FrameStatsTest.main(args);
        ParticleBudgetTest.main(args);
        AdaptiveBudgetTest.main(args);
        VisibilityCacheTest.main(args);
        LightChunkCacheTest.main(args);
        WriteDrainBudgetTest.run();
        CompactGlyphRowsTest.main(args);
        DeferredSearchTest.main(args);
        ru.pasha.pashaboost.memory.StateMemoryTest.main(args);
        CubeShapeTest.main(args);
        ParticleLightShareTest.main(args);
        QuadSortTest.main(args);
        EntitySectionMemoTest.main(args);
    }
}
