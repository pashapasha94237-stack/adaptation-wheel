# Adapt Boost 1.7.0 (formerly Pasha Boost) — licensing and source

The runtime JAR contains no embedded optimization-mod JARs. Code taken from other
mods is listed below with its license; the top-level MIT license covers the
original Adapt Boost code and does not relicense anything listed here.

## FerriteCore-derived memory savings (MIT)

- Files: `src/main/java/ru/pasha/pashaboost/memory/` (`FastMap`, `PropertyIndexer`,
  `FastMapStateHolder`, `StateMemory`, `NeighbourTableView`, `FastPropertyMap`,
  `GuavaAccess`, `ModelDedup`, `ShapeDedup`, `ModelSides`) and the mixins
  `StateHolderMemoryMixin`, `BlockStateCacheMemoryMixin`,
  `client/AndConditionMemoryMixin`, `client/OrConditionMemoryMixin`,
  `client/KeyValueConditionMemoryMixin`, `client/MultiPartModelMemoryMixin`,
  `client/MultiPartSelectorSyncMixin`, `client/SimpleModelMemoryMixin`; compile-only
  stubs in `src/guavastubs/`.
- Upstream: FerriteCore 6.0.1 (Forge, Minecraft 1.20.1) by malte0811,
  https://github.com/malte0811/FerriteCore. Ported from that release.
- License: **MIT**, copyright (c) 2020 malte0811. Full text in
  `third-party-licenses/FerriteCore-6.0.1-MIT.txt`, packaged as
  `META-INF/licenses/FerriteCore-6.0.1-MIT.txt`.
- Adapt Boost changes: SRG/official dual names and reflection instead of
  refmapped accessors; the neighbour table field always holds a working read-only
  view (FerriteCore's default crashes on direct access); values of the wrong type
  have no neighbour instead of failing a cast; the three Guava access classes are
  generated at runtime instead of shipped as bytes; synchronised shape caches;
  launch-time gating on the earned FPS adaptation. Since 1.7 baked-quad vertex
  arrays are shared too (`ModelSides.shareVertices`), only for plain `BakedQuad`
  instances and never with OptiFine, which patches `BakedQuad`. Not ported: the small threading detector
  (OptiFine patches `PalettedContainer`) and model-location string sharing
  (OptiFine patches `ResourceLocation`).
- Skipped automatically when FerriteCore itself is installed.

## Ideas reimplemented from other MIT mods

No code was copied; these mods are credited for the technique.

- particle_core 0.3.3 by fzzyhmstrs (MIT, `third-party-licenses/particle_core-0.3.3-MIT.txt`):
  turning the four billboard corners once per camera rotation for particles
  without roll (`mixin/client/QuadParticleVertexMixin`).
- Clumps by Jaredlll08 (MIT, https://github.com/jaredlll08/Clumps): merging
  experience orbs (`mixin/XpOrbMergeMixin`; Adapt Boost merges only orbs of the
  same value, so pickup and Mending stay vanilla). Skipped when Clumps is installed.
- Dynamic FPS by juliand665 and LostLuma (MIT, https://github.com/juliand665/Dynamic-FPS):
  a lower frame rate while the window is unfocused or minimised (`client/IdleFrameCap`).

## Ideas reimplemented in 1.7 from LGPL and GPL mods

No code was copied; the implementations are original and these mods are credited for the idea.

- ImmediatelyFast by RK_01 (RaphiMC) (LGPL-3.0, https://github.com/RaphiMC/ImmediatelyFast):
  looking glyphs up in the font tables directly instead of through the per-character
  font-set calls (`client/font/FontLookup`, `mixin/client/FontGlyphLookupMixin`,
  `mixin/client/FontWidthLookupMixin`). Skipped next to ImmediatelyFast, Modern UI,
  Emojiful and OptiFine.
- MoreCulling by FX - PR0CESS (GPL-3.0, https://github.com/fxmorin/moreculling):
  not drawing the text of a sign side that faces away from the camera
  (`client/SignTextCulling`, `mixin/client/SignTextCullMixin`). Skipped next to Oculus and
  Vivecraft. It also runs with OptiFine, whose sign renderer only adds a distance check before the
  point where the cull runs.
- Embeddium by embeddedt (LGPL-3.0, https://github.com/embeddedt/embeddium), from the
  older Sodium by JellySquid: reusing the shader sampler names instead of building
  `"Sampler" + i` strings on every draw (`mixin/client/SamplerNameMixin`) and stepping
  through a vertex format's elements with a plain array instead of the immutable list
  and a modulo (`client/VertexElementArrays`, `mixin/client/VertexElementMixin`).
  Both are skipped next to Embeddium, Rubidium, Sodium, Oculus, Iris and ImmediatelyFast; the
  sampler names also next to OptiFine.
- Lithium by CaffeineMC (LGPL-3.0, https://github.com/CaffeineMC/lithium-fabric),
  `entity.data_tracker.no_locks`: reading synced entity data without the read lock once
  the entry exists (`mixin/EntityDataLockMixin`; Adapt Boost keeps the lock for a missing
  entry and for every write). Skipped next to Lithium, Canary, Radium and OptiFine.
- Sodium by JellySquid and CaffeineMC (LGPL-3.0, https://github.com/CaffeineMC/sodium-fabric):
  - from the 0.5 sorting rework, sorting translucent quads on primitive arrays instead of
    boxed index lists (`client/QuadSort`, `client/QuadSortGate`, `mixin/client/QuadSortMixin`).
    It works with and without OptiFine. It is skipped next to Embeddium, Rubidium, Sodium,
    Magnesium, Xenon, Celeritas, ImmediatelyFast, Oculus and Iris.
  - from its per-frame particle light caching, one light lookup per block and frame shared by
    every particle in that block that needs a new value after Adapt Boost's own per-particle
    same-block, same-tick check (`client/SharedParticleLight`, `core/ParticleLightShare`,
    `mixin/client/ParticleLight*Mixin`). It is skipped next to light engine and dynamic light
    mods (Starlight, ScalableLux, Moonrise, Radon, Phosphor, LambDynamicLights, Dynamic Lights
    Reforged, RyoamicLights, Sodium Dynamic Lights, Lucent, Embeddium++).
- Embeddium (LGPL-3.0): the model cuboid fast path, which writes each face of an entity model
  cube straight into the vertex buffer (`client/ModelCubeDirect`, `client/CubeShape`,
  `client/OfCubeWriter`, `client/OfModelVertex`, `client/OfSpriteExpander`,
  `mixin/client/OfCube*Mixin`, `OfModelVertexMixin`, `OfSpriteExpanderMixin`). Adapt Boost
  builds it on OptiFine's own fast vertex path, so it runs only with OptiFine
  1.20.1_HD_U_I6_pre6, and never next to Embeddium, Rubidium, Sodium, Oculus, Iris or
  ImmediatelyFast. `src/compatstubs/net/optifine/render/` holds compile-only signatures of two
  OptiFine classes, which are not packaged.

## Fixes for other mods

These classes only target other mods' classes (Alex's Mobs 1.22.8/1.22.9,
Twilight Forest 4.3.2508, BrandonsCore 3.2, Mahou Tsukai 1.20.1-v1.34.81) and are
applied only next to those checked versions. No code of those mods is included;
`src/compatstubs/` holds compile-only signatures of two Twilight Forest classes,
which are not packaged.

## ModernFix-derived Unicode glyph packing (LGPL)

- Files: `src/main/java/ru/pasha/pashaboost/client/font/CompactGlyphRows.java` and
  `src/main/java/ru/pasha/pashaboost/mixin/client/UnihexGlyphMixin.java`.
- Upstream authors: embeddedt and ModernFix contributors; the upstream flattened-
  field storage idea is credited to @AnAwesomGuy.
- License: **LGPL-3.0-or-later**. Full LGPL and GPL texts and the upstream notice
  are retained in `third-party-licenses/`, packaged under `META-INF/licenses/`.
- Source commit: `355755b17342ab576cb182c0abbcd699f628797e`, corresponding to
  ModernFix `5.27.89+mc1.20.1`.
- Source: https://github.com/embeddedt/ModernFix/tree/355755b17342ab576cb182c0abbcd699f628797e
- Full upstream archive:
  `third-party-src/ModernFix-5.27.89-355755b17342ab576cb182c0abbcd699f628797e-source.zip`.
- Adapt Boost modifications: lossless 24/32-bit glyphs in addition to 8/16-bit
  glyphs, input and boundary checks, configuration, cumulative counters and runtime
  activation/release through resource reload. Detailed provenance and hashes:
  `third-party-licenses/MODERNFIX-SOURCES.md`.

The source distribution includes the modified classes and Adapt Boost build
scripts. Recipients may modify these classes and rebuild the mod under their
applicable license; there is no signing restriction. FerriteCore and ModernFix
themselves are not bundled or required. Historical reference archives, if present
in the working source tree, do not mean their corresponding binaries ship in this version.
