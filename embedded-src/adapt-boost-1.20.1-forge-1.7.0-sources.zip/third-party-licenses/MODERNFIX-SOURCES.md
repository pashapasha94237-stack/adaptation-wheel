# ModernFix source provenance

Author: embeddedt and the ModernFix contributors. The upstream license notice
starts `Copyright (c) 2022` and grants GNU LGPL version 3 or, at the recipient's
option, any later version. The notice and complete LGPL text are preserved in
`ModernFix-5.27.89-LGPL-3.0.txt`; the complete underlying GPL version 3 text is in
`ModernFix-GPL-3.0.txt`.

The user supplied `modernfix-forge-5.27.89mc1.20.1.jar` as reference material.
Its bytes match the official Modrinth release `5.27.89+mc1.20.1`:

- Project: https://modrinth.com/mod/modernfix
- Official release: https://modrinth.com/mod/modernfix/version/sgbtnCX5
- Official release API: https://api.modrinth.com/v2/version/sgbtnCX5
- Published: 2026-10-19T02:04:28.229122Z.
- Binary size: 1,010,226 bytes.
- Binary SHA-256: `96750ec3e12b581ee7a936ce2b7c2b35251e97b6f729b2db8bc0d5c9a2dc12fa`.
- Binary SHA-512, verified against the official API:
  `4e7d42fa18a0b15a7c38a7ce39291f2c0abc47f06746c10d2f3a8a2360d3df0dd44b2024e83867d3de8f597200b79ac3e899fc5b4a577f2df1cf7e01788b2234`.

The source repository specified by the supplied JAR is:
https://github.com/embeddedt/ModernFix

The exact corresponding source commit is:
`355755b17342ab576cb182c0abbcd699f628797e` on branch `1.20`.

This was verified using the upstream version algorithm in
`buildSrc/src/main/kotlin/GitVersionSource.kt`. At that commit,
`release_line.txt` contains `5.27`, its most recent first-parent modification
is commit `c2191df35948d4548f71f8ad2905976cf935afd8`, and
`git rev-list --count --first-parent c2191df35948d4548f71f8ad2905976cf935afd8..355755b17342ab576cb182c0abbcd699f628797e`
returns `89`. `gradle.properties` specifies Minecraft `1.20.1`. Together these
produce the supplied version `5.27.89+mc1.20.1`.

The complete upstream source, including build scripts, wrapper and notices, is
provided in:
`third-party-src/ModernFix-5.27.89-355755b17342ab576cb182c0abbcd699f628797e-source.zip`.

- Source URL: https://github.com/embeddedt/ModernFix/tree/355755b17342ab576cb182c0abbcd699f628797e
- Archive URL: https://codeload.github.com/embeddedt/ModernFix/zip/355755b17342ab576cb182c0abbcd699f628797e
- Archive SHA-256: `0155920de71a99121bca7d0ce42bf0e33984e390abb3180a66e181404bb689eb`.

`third-party-src/ModernFix-reference-code/` contains unchanged copies of selected
source files for inspection. These are reference copies, not an additional
runtime mod or an assertion that every copied file is enabled in Pasha Boost.

## Modified glyph implementation

The following Pasha Boost files derive from ModernFix's `CompactUnihexContents`
and `compress_unihex_font` mixins and remain LGPL-3.0-or-later:

- `src/main/java/ru/pasha/pashaboost/client/font/CompactGlyphRows.java`
- `src/main/java/ru/pasha/pashaboost/mixin/client/UnihexGlyphMixin.java`

Modifications dated 2026-10-20: add packed 24-bit and 32-bit glyphs alongside the
upstream 8-bit and 16-bit cases; validate constructor input and row bounds; use
standard Mixin local capture instead of a MixinExtras local parameter; include
explicit development and Forge production method selectors; add an opt-out and
cumulative operation counters. Version 1.3.0 adds an inactive startup gate and
resource reloads on FPS-adaptation activation and release. The packing retains all pixel bits and the
original glyph width. The original flattened-field idea is credited to
@AnAwesomGuy, as it is in ModernFix.

`src/test/java/ru/pasha/pashaboost/core/CompactGlyphRowsTest.java` verifies row
equivalence, default mask/width behavior, array independence, primitive-only
storage and boundary checks. The estimated bytes counter describes an assumed
HotSpot object layout and cumulative created glyphs; it is not a measurement
of the game's current heap or a claim of an FPS increase.

Corresponding modified source and Pasha Boost build scripts are distributed
with Pasha Boost. Recipients may modify and rebuild these classes under their
applicable LGPL terms. A standalone ModernFix JAR is not needed for this glyph
implementation.

For a complete upstream rebuild with the exact upstream version, clone the
repository with sufficient first-parent history through the release-line
commit, check out the commit above, use Java 17 and run its Gradle build. A source
ZIP without Git history builds with the upstream fallback patch number `999`;
this affects the reported version rather than the Java source correspondence.

Retrieved and verified on 2026-10-20.
