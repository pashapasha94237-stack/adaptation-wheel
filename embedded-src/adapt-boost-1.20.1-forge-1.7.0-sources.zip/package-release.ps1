$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$rootDirectory = $PSScriptRoot
$distDirectory = Join-Path $rootDirectory 'dist'
New-Item -ItemType Directory -Force -Path $distDirectory | Out-Null
$baseName = 'adapt-boost-1.20.1-forge-1.7.0'
$builtJar = Join-Path $rootDirectory ('build/libs/' + $baseName + '.jar')
if (!(Test-Path -LiteralPath $builtJar)) { throw 'Run the build first.' }
$builtArchive = [IO.Compression.ZipFile]::OpenRead($builtJar)
try {
    if ($builtArchive.Entries.FullName -match '^META-INF/jarjar/' -or $builtArchive.Entries.FullName -match '\.jar$') {
        throw 'Release must not contain always-on embedded engines.'
    }
    foreach ($notice in @('ModernFix-5.27.89-LGPL-3.0.txt','ModernFix-GPL-3.0.txt','MODERNFIX-SOURCES.md','FerriteCore-6.0.1-MIT.txt','particle_core-0.3.3-MIT.txt')) {
        if (!$builtArchive.GetEntry('META-INF/licenses/' + $notice)) { throw "Missing license notice: $notice" }
    }
} finally { $builtArchive.Dispose() }
Copy-Item -LiteralPath $builtJar -Destination (Join-Path $distDirectory ($baseName + '.jar'))
Copy-Item -LiteralPath (Join-Path $rootDirectory 'README.md') -Destination (Join-Path $distDirectory 'README-ru.md')
$sourceZip = Join-Path $distDirectory ($baseName + '-sources.zip')
$sourceStream = [IO.File]::Open($sourceZip,[IO.FileMode]::Create)
$sourceArchive = [IO.Compression.ZipArchive]::new($sourceStream,[IO.Compression.ZipArchiveMode]::Create)
try {
    $includePaths = @('src','gradle')
    $filesToArchive = @()
    foreach ($relativeDirectory in $includePaths) { $filesToArchive += Get-ChildItem -LiteralPath (Join-Path $rootDirectory $relativeDirectory) -File -Recurse }
    foreach ($filename in @('build.gradle','settings.gradle','gradle.properties','gradlew','gradlew.bat','build-local.ps1','smoke-client.ps1','package-release.ps1','package-fps-update.ps1','README.md','FPS-UPDATE.md','VALIDATION-1.3.md','THIRD-PARTY.md','LICENSE','.gitignore')) {
        $filesToArchive += Get-Item -LiteralPath (Join-Path $rootDirectory $filename)
    }
    # Include the source and notices for the derivative actually shipped in this release.
    foreach ($notice in @('ModernFix-5.27.89-LGPL-3.0.txt','ModernFix-GPL-3.0.txt','MODERNFIX-SOURCES.md','FerriteCore-6.0.1-MIT.txt','particle_core-0.3.3-MIT.txt')) {
        $filesToArchive += Get-Item -LiteralPath (Join-Path $rootDirectory ('third-party-licenses/' + $notice))
    }
    $filesToArchive += Get-ChildItem -LiteralPath (Join-Path $rootDirectory 'third-party-src') -File -Filter 'ModernFix-*-source.zip'
    foreach ($sourceFile in $filesToArchive) {
        $entryPath = $sourceFile.FullName.Substring($rootDirectory.Length+1).Replace('\','/')
        [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($sourceArchive,$sourceFile.FullName,$entryPath,[IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }
} finally { $sourceArchive.Dispose(); $sourceStream.Dispose() }
$hashLines = Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $distDirectory ($baseName + '.jar')),$sourceZip | ForEach-Object { $_.Hash.ToLower() + '  ' + [IO.Path]::GetFileName($_.Path) }
[IO.File]::WriteAllLines((Join-Path $distDirectory 'SHA256SUMS.txt'),$hashLines,[Text.UTF8Encoding]::new($false))
Get-ChildItem -LiteralPath $distDirectory | Select-Object Name,Length
