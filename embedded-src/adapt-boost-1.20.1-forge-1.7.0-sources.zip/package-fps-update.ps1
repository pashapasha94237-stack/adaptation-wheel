param([string]$WheelProjectDirectory = 'C:\Users\pasha\OneDrive\Documents\ChatGPT\rsfgd')
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
& (Join-Path $PSScriptRoot 'package-release.ps1')
$wheelJar = Join-Path $WheelProjectDirectory 'dist/adaptation-wheel-1.20.1-4.4.1.jar'
$boostJar = Join-Path $PSScriptRoot 'dist/pasha-boost-1.20.1-forge-1.3.2.jar'
$boostSources = Join-Path $PSScriptRoot 'dist/pasha-boost-1.20.1-forge-1.3.2-sources.zip'
$updateZip = Join-Path $PSScriptRoot 'dist/fps-adaptation-update-1.20.1-1.3.2.zip'
$stream = [IO.File]::Open($updateZip,[IO.FileMode]::Create)
$archive = [IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create)
try {
    $releaseFiles = @(
        @{ Path=$wheelJar; Entry='mods/adaptation-wheel-1.20.1-4.4.1.jar' },
        @{ Path=$boostJar; Entry='mods/pasha-boost-1.20.1-forge-1.3.2.jar' },
        @{ Path=$boostSources; Entry='sources/pasha-boost-1.20.1-forge-1.3.2-sources.zip' },
        @{ Path=(Join-Path $PSScriptRoot 'FPS-UPDATE.md'); Entry='README.md' }
    )
    foreach($releaseFile in $releaseFiles) {
        [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,$releaseFile.Path,$releaseFile.Entry,[IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }
} finally { $archive.Dispose(); $stream.Dispose() }
Get-Item -LiteralPath $updateZip | Select-Object FullName,Length
Get-FileHash -Algorithm SHA256 -LiteralPath $updateZip
