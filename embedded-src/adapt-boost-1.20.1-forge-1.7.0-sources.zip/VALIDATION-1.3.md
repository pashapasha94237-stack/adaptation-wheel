# Pasha Boost 1.3.0 + Wheel 4.4.1 — release checks, 2026-10-20

## Own main menu with OptiFine: Pasha Boost 1.3.2 / combined wheel 4.5.2

Our Screen-based video UI now replaces the ordinary video-settings destination
even with OptiFine. Its advanced-settings button creates an explicitly allowed
native screen. A weak identity reference exempts that same native instance from
replacement when shader/quality child pages return, avoiding navigation loops.

Production OptiFine I6_pre6 / Forge 47.4.13 checks pass with exit 0:

- Own video screen opens with the real OptiFine transformer; direct superclass is Screen.
- World/Quality/Display tabs and Performance -> BoostScreen -> same OwnVideoScreen.
- Advanced -> native VideoSettings -> actual `net.optifine.shaders.gui.GuiShaders`.
- Shader Done -> same native screen -> Done -> same own screen.
- Real 30-FPS qualification, stage-four activation and complete light/NBT/font,
  option-save and unequip restoration checks remain successful.

Plain Forge 47.4.16 menu opening/tab/performance round-trip also passes with exit 0.
The screenshot confirms the own layout plus the advanced button under OptiFine.
The OptiFine JAR remains testing-only and is never packaged for redistribution.

## OptiFine compatibility update: Pasha Boost 1.3.1 / combined wheel 4.5.1

The user's actual report identified `NoSuchFieldError: f_96282_` in
`OwnVideoScreen.init`, an inherited `OptionsSubScreen.options` field removed from
the effective video-screen hierarchy by OptiFine. The own screen now inherits
directly from Screen and stores its own options/parent references. When OptiFine
is present, the native video screen and its shader pages remain intact; an FPS+
button opens the optimization controls and returns to the same native screen.

The compatibility run uses the user's installed I6_pre6 build with Forge 47.4.13
in an isolated directory. It confirms the real transformation service and
`VideoSettingsScreen` superclass `net.optifine.gui.GuiScreenOF`; it does not
simulate OptiFine by setting a mod-list flag. Native opening and FPS+ round-trip,
natural 30-FPS qualification, final-stage activation, NBT/light/glyph hooks,
options-save behavior and restoration after unequipping all pass with exit 0.

OptiFine derives FAST cloud quality during resource reload. Its profile therefore
uses the compatible FAST cloud mode (already-OFF clouds stay off). Managed
temporary settings are reapplied after the resource overlay finishes, using only
values still managed before the reload. A manual render-distance edit to 12 is
preserved through release; the remaining original settings restore normally.

Java 17; compile target Forge 47.4.0; production Forge 47.4.16 / Minecraft 1.20.1.
Tests use an isolated game directory and test world, never a user's save.

Both projects' Gradle `build`/`coreTest` pass. Wheel checks include real frame
timestamp sampling at 1/30/59/60 FPS, duplicate callbacks, menus, loading stalls,
stage durations, persistence, hit acceleration, protection, settings and catalogue
selection. The Boost cache, glyph, particle, frame-time and visual-budget checks
also pass. These are functional tests, not an FPS-gain benchmark.

`smoke-client.ps1 -FpsAdaptation -LowLevel` loads both actual reobfuscated JARs:

- No embedded renderer/memory/AI engines; initial optimization and glyph counters
  are zero. A forced benchmark override cannot bypass the locked state.
- The normal Video Settings entry opens the new screen. Its production screenshot
  shows the graphite/mint layout and functioning vanilla option controls.
- With a freshly equipped and synchronized wheel, the real frame limiter is set
  to 30 FPS. No FPS/work samples are injected during the initial qualification.
  The final run recorded 345 render callbacks, 344 eligible frames, measured and
  vanilla FPS of 30, and 6.071 work seconds after 11.520 wall-clock seconds.
- At that point, optimization remains off: temporary graphics, light cache, NBT
  draining, glyph packing and particle rejection are still inactive.
- Separately, controlled samples check 1/59 inclusion, 60 exclusion, all four
  stages, one completion sound/turn per stage, J toggling and the real API bridge.
  Stage four opens the runtime gates and triggers a real resource reload so
  existing fonts actually change representation.
- Unlocked profile: FAST graphics, no clouds/entity shadows, render distance ≤8;
  112,990 packed glyphs; 192 NBT records survive overwrite/deletion/flush/reopen;
  decorative particles are rejected and distant ordinary entities are culled.
- Saving options while active leaves renderDistance=10, graphicsMode=1 and
  entityShadows=true in options.txt, while the live profile stays applied. A manual
  cloud-setting edit is retained rather than overwritten on release.
- Block light is 14 at a torch and 13 across a chunk border, then zero after
  removal. Production cache metrics confirm the new hook is active.
- Unequipping releases all runtime gates, reloads fonts without compaction and
  restores original video settings. The game exits normally with all PASS markers.

Glyph byte counters estimate cumulative allocation savings from an assumed object
layout; they do not measure current heap savings. Earlier embedded engines were
removed because their startup behavior cannot meet the requested runtime lock.
This release does not claim their renderer, memory or AI performance gains.

Earlier combat GameTests were not rerun for these client FPS/UI changes; current
core checks cover the shared adaptation state and configuration behavior.
