param([string[]]$Tasks = @('build'))
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$toolRoot = 'C:\Users\pasha\OneDrive\Documents\ChatGPT\rsfgd'
$env:JAVA_HOME = Join-Path $toolRoot '.tools/java/jdk-17.0.20.1+1'
$env:GRADLE_USER_HOME = Join-Path $toolRoot '.gradle-user-home'
& "$env:JAVA_HOME/bin/java.exe" '-Xmx3G' '-Dfile.encoding=UTF-8' '-Dorg.gradle.internal.instrumentation.agent=false' '-classpath' 'gradle/wrapper/gradle-wrapper.jar' org.gradle.wrapper.GradleWrapperMain @Tasks --offline --no-daemon '-Dorg.gradle.jvmargs=' --console=plain
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
